import React from 'react';
import { Ticket, Sparkles, CheckCircle2, ArrowRight, ShieldCheck, HelpCircle, MessageSquare } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface PromoBannerProps {
  onClaimVoucher: () => void;
  onOrderNow: () => void;
}

export const PromoBanner: React.FC<PromoBannerProps> = ({
  onClaimVoucher,
  onOrderNow,
}) => {
  const { currentUser } = useAuth();

  return (
    <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white p-6 sm:p-8 lg:p-10 shadow-xl border border-slate-800">
      {/* Decorative Glow Elements */}
      <div className="absolute -top-24 -right-24 w-72 h-72 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-amber-400/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-3xl mx-auto text-center space-y-6">
        
        {/* Top Tagline Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs sm:text-sm font-semibold tracking-wide">
          <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
          <span>PROMO SPESIAL MAHASISWA & SISWA</span>
        </div>

        {/* Big Promo Headline */}
        <div className="space-y-2">
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white font-display uppercase leading-tight">
            BAYAR <span className="text-amber-400 underline decoration-amber-400/50 decoration-wavy">Rp10.000</span>
            <br className="hidden xs:inline" />
            <span className="block text-2xl sm:text-4xl lg:text-5xl mt-2 text-slate-100 font-extrabold">
              DAPAT VOUCHER JASA <span className="text-amber-400 font-black">Rp30.000</span>
            </span>
          </h1>
          <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto font-normal pt-1">
            <span className="font-semibold text-white">„Kirim pekerjaanmu. Kami yang bereskan.”</span> 
            <br />
            Tugas PPT, Word, Excel, Aplikasi, Website, Video, Desain, hingga Jasa Custom kami kerjakan tuntas, rapi, dan tepat waktu.
          </p>
        </div>

        {/* Voucher Calculation Simulator Card */}
        <div className="bg-slate-800/80 backdrop-blur-sm border border-slate-700/80 rounded-2xl p-4 sm:p-5 text-left max-w-xl mx-auto shadow-inner">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 mb-3 uppercase tracking-wider">
            <HelpCircle className="w-4 h-4" />
            <span>Bagaimana Cara Kerja Potongan Vouchernya?</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-700">
              <span className="inline-block px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[11px] mb-1.5">
                Contoh 1: Gratis / Rp0
              </span>
              <p className="text-slate-300 font-medium leading-relaxed">
                Biaya tugas: <strong className="text-white">Rp25.000</strong>
                <br />
                Voucher terpakai: <span className="text-amber-400 font-semibold">Rp25.000</span>
                <br />
                <span className="text-emerald-400 font-bold text-sm block mt-1">Kamu Bayar: Rp0</span>
                <span className="text-slate-400 text-[10px]">(Sisa voucher Rp5.000 tetap tersimpan)</span>
              </p>
            </div>
            <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-700">
              <span className="inline-block px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 font-bold text-[11px] mb-1.5">
                Contoh 2: Bayar Selisih
              </span>
              <p className="text-slate-300 font-medium leading-relaxed">
                Biaya tugas: <strong className="text-white">Rp45.000</strong>
                <br />
                Voucher terpakai: <span className="text-amber-400 font-semibold">Rp30.000 (maks)</span>
                <br />
                <span className="text-amber-400 font-bold text-sm block mt-1">Kamu Bayar: Rp15.000</span>
                <span className="text-slate-400 text-[10px]">(Hemat Rp30.000 langsung via QRIS)</span>
              </p>
            </div>
          </div>
          <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              Voucher bukan uang tunai & tidak dapat dicairkan
            </span>
            <span className="text-amber-300/90 font-medium">1 Kode = 1 Akun Aktif</span>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          {currentUser?.role === 'STUDENT' ? (
            <button
              id="promo-order-now-btn"
              onClick={onOrderNow}
              className="w-full sm:w-auto px-7 py-3.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl text-base shadow-lg shadow-amber-400/20 transition-all flex items-center justify-center gap-2"
            >
              <span>Mulai Buat Pesanan</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              id="promo-claim-voucher-btn"
              onClick={onClaimVoucher}
              className="w-full sm:w-auto px-7 py-3.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl text-base shadow-lg shadow-amber-400/20 transition-all flex items-center justify-center gap-2"
            >
              <Ticket className="w-5 h-5 text-slate-950" />
              <span>Daftar & Klaim Voucher Rp30.000</span>
            </button>
          )}

          <a
            id="promo-whatsapp-admin-btn"
            href="https://wa.me/628136732365?text=Halo%20Admin%20BERESIN,%20saya%20mau%20beli%20kode%20voucher%20promo%20Rp10.000%20(dapat%20Rp30.000)"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-5 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-sm border border-slate-700 transition-colors flex items-center justify-center gap-2"
          >
            <MessageSquare className="w-4 h-4 text-emerald-400" />
            <span>Minta Kode ke Admin (WhatsApp)</span>
          </a>
        </div>

        {/* Trust Badges */}
        <div className="grid grid-cols-3 gap-2 pt-4 border-t border-slate-800/80 text-center max-w-md mx-auto">
          <div>
            <p className="text-base sm:text-lg font-bold text-white">100%</p>
            <p className="text-[11px] text-slate-400">Garansi Revisi</p>
          </div>
          <div className="border-x border-slate-800">
            <p className="text-base sm:text-lg font-bold text-white">Tepat Waktu</p>
            <p className="text-[11px] text-slate-400">Sesuai Deadline</p>
          </div>
          <div>
            <p className="text-base sm:text-lg font-bold text-white">Aman & Privat</p>
            <p className="text-[11px] text-slate-400">Storage Terjaga</p>
          </div>
        </div>

      </div>
    </section>
  );
};

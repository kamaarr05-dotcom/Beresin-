import React, { useState } from 'react';
import { AdminPaymentConfig } from '../types';
import { BeresinDataStore } from '../lib/supabase';
import { 
  CreditCard, 
  Phone, 
  MessageSquare, 
  Building2, 
  User, 
  QrCode, 
  Save, 
  CheckCircle2, 
  RotateCcw, 
  ExternalLink,
  ShieldCheck,
  FileText,
  Copy,
  Check
} from 'lucide-react';

interface AdminPaymentSettingsProps {
  onSaved?: () => void;
  onClose?: () => void;
}

const COMMON_BANKS = [
  'DANA',
  'Bank Mandiri',
  'BRI',
  'BNI',
  'BSI (Bank Syariah Indonesia)',
  'Bank Jago',
  'SeaBank',
  'CIMB Niaga',
  'Dana / E-Wallet',
  'GoPay / E-Wallet',
];

export const AdminPaymentSettings: React.FC<AdminPaymentSettingsProps> = ({ onSaved, onClose }) => {
  const [config, setConfig] = useState<AdminPaymentConfig>(() => BeresinDataStore.getPaymentConfig());
  const [successMessage, setSuccessMessage] = useState('');
  const [copiedAccount, setCopiedAccount] = useState(false);

  const handleChange = (field: keyof AdminPaymentConfig, value: string) => {
    setConfig((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    BeresinDataStore.savePaymentConfig(config);
    setSuccessMessage('Pengaturan Kartu Bank & Kontak WhatsApp berhasil disimpan!');
    onSaved?.();
    setTimeout(() => {
      setSuccessMessage('');
    }, 3000);
  };

  const handleReset = () => {
    if (window.confirm('Kembalikan ke nomor rekening dan WhatsApp bawaan?')) {
      const defaultConfig: AdminPaymentConfig = {
        whatsapp_number: '628136732365',
        whatsapp_greeting: 'Halo Admin BERESIN, saya ingin tanya mengenai jasa tugas/skripsi.',
        bank_name: 'DANA',
        bank_account_number: '081224405119',
        bank_account_holder: 'BERESIN OFFICIAL',
        qris_merchant_name: 'QRIS BERESIN OFFICIAL',
        qris_nmid: 'ID1020304050',
        payment_instructions: 'Harap sertakan nomor pesanan pada berita transfer dan upload bukti transfer screenshot pada aplikasi.',
      };
      BeresinDataStore.savePaymentConfig(defaultConfig);
      setConfig(defaultConfig);
      setSuccessMessage('Pengaturan berhasil direset ke bawaan.');
      onSaved?.();
      setTimeout(() => setSuccessMessage(''), 3000);
    }
  };

  const handleCopyTest = () => {
    navigator.clipboard.writeText(config.bank_account_number);
    setCopiedAccount(true);
    setTimeout(() => setCopiedAccount(false), 2000);
  };

  const testWaLink = BeresinDataStore.getWhatsAppLink('Tes pesan dari Admin BERESIN');

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-black uppercase">
              Pengaturan Pembayaran & Kontak
            </span>
            <span className="text-xs text-slate-500 font-medium">Bebas diubah kapan saja</span>
          </div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-500" />
            <span>Kelola Kartu Bank & WhatsApp Admin</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl">
            Semua nomor rekening bank dan kontak WhatsApp yang Anda simpan di sini akan langsung tampil pada pemesan saat membayar pesanan atau menghubungi Admin.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors"
            >
              Kembali
            </button>
          )}
          <button
            type="button"
            onClick={handleReset}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Bawaan</span>
          </button>
        </div>
      </div>

      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl flex items-center gap-3 text-emerald-900 text-xs sm:text-sm font-bold animate-in slide-in-from-top duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Main Grid: Settings Form & Live Visual Card Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Form Controls (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <form onSubmit={handleSave} className="space-y-6">
            
            {/* SECTION 1: KARTU REKENING BANK */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">Informasi Rekening Bank</h3>
                  <p className="text-[11px] text-slate-500">Rekening tujuan transfer untuk pemesan mahasiswa</p>
                </div>
              </div>

              {/* Nama Bank */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  Nama Bank / E-Wallet
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <select
                    value={COMMON_BANKS.includes(config.bank_name) ? config.bank_name : 'OTHER'}
                    onChange={(e) => {
                      if (e.target.value !== 'OTHER') {
                        handleChange('bank_name', e.target.value);
                      }
                    }}
                    className="px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl font-medium outline-none focus:border-amber-500 focus:bg-white"
                  >
                    {COMMON_BANKS.map((bank) => (
                      <option key={bank} value={bank}>{bank}</option>
                    ))}
                    <option value="OTHER">Lainnya (Ketik Manual)</option>
                  </select>
                  
                  <div className="relative flex-1">
                    <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={config.bank_name}
                      onChange={(e) => handleChange('bank_name', e.target.value)}
                      placeholder="Nama Bank, misal: BCA / Bank Mandiri"
                      className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-amber-500 focus:bg-white font-semibold"
                    />
                  </div>
                </div>
              </div>

              {/* Nomor Rekening */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  Nomor Rekening Bank
                </label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    value={config.bank_account_number}
                    onChange={(e) => handleChange('bank_account_number', e.target.value)}
                    placeholder="Contoh: 081224405119"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-amber-500 focus:bg-white tracking-wider"
                  />
                </div>
              </div>

              {/* Atas Nama Pemilik */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  Atas Nama Pemilik Rekening
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    value={config.bank_account_holder}
                    onChange={(e) => handleChange('bank_account_holder', e.target.value.toUpperCase())}
                    placeholder="Contoh: BERESIN OFFICIAL / NAMA ANDA"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm uppercase font-bold bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-amber-500 focus:bg-white"
                  />
                </div>
              </div>
            </div>

            {/* SECTION 2: KONTAK WHATSAPP */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">Kontak WhatsApp Admin</h3>
                  <p className="text-[11px] text-slate-500">Nomor tujuan untuk chat mahasiswa dan konsultasi tugas</p>
                </div>
              </div>

              {/* Nomor WhatsApp */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  Nomor WhatsApp (Diawali 62 atau 08)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-emerald-600 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    required
                    value={config.whatsapp_number}
                    onChange={(e) => handleChange('whatsapp_number', e.target.value)}
                    placeholder="081234567890 atau 628136732365"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm font-bold bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
                <p className="text-[10px] text-slate-400">
                  Format otomatis dikonversi ke format internasional (misal 0812... menjadi 62812...).
                </p>
              </div>

              {/* Pesan Sapaan WhatsApp */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  Template Pesan Pembuka (Default Greeting)
                </label>
                <div className="relative">
                  <MessageSquare className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <textarea
                    rows={2}
                    value={config.whatsapp_greeting}
                    onChange={(e) => handleChange('whatsapp_greeting', e.target.value)}
                    placeholder="Halo Admin BERESIN, saya ingin menanyakan..."
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Test link */}
              <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-2xl flex items-center justify-between">
                <div className="space-y-0.5">
                  <span className="text-xs font-bold text-emerald-950 block">Uji Kontak WhatsApp</span>
                  <span className="text-[11px] text-emerald-700 font-mono">wa.me/{config.whatsapp_number.replace(/^0/, '62')}</span>
                </div>
                <a
                  href={testWaLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Buka Chat</span>
                </a>
              </div>
            </div>

            {/* SECTION 3: QRIS & CATATAN TRANSFER */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div className="p-2 bg-orange-50 text-orange-600 rounded-xl">
                  <QrCode className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">Pengaturan QRIS & Instruksi</h3>
                  <p className="text-[11px] text-slate-500">Detail QRIS dan panduan bayar untuk mahasiswa</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700">
                    Nama Merchant QRIS
                  </label>
                  <input
                    type="text"
                    value={config.qris_merchant_name}
                    onChange={(e) => handleChange('qris_merchant_name', e.target.value)}
                    placeholder="Contoh: QRIS BERESIN PRO"
                    className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-orange-500 focus:bg-white font-bold"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700">
                    NMID QRIS (Opsional)
                  </label>
                  <input
                    type="text"
                    value={config.qris_nmid}
                    onChange={(e) => handleChange('qris_nmid', e.target.value)}
                    placeholder="Contoh: ID1020304050"
                    className="w-full px-3 py-2 text-xs sm:text-sm font-mono bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-orange-500 focus:bg-white"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  Instruksi Pembayaran Tambahan
                </label>
                <textarea
                  rows={2}
                  value={config.payment_instructions || ''}
                  onChange={(e) => handleChange('payment_instructions', e.target.value)}
                  placeholder="Petunjuk khusus saat siswa melakukan transfer bank..."
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-amber-500 focus:bg-white"
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="submit"
                className="flex-1 py-3.5 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs sm:text-sm font-black shadow-lg flex items-center justify-center gap-2 active:scale-98 transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Perubahan Rekening & WhatsApp</span>
              </button>
            </div>

          </form>
        </div>

        {/* Right Column: Visual Debit Card & Live Preview (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Card Label */}
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Pratinjau Kartu Bank (Live Preview)
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
              Tampil di Modal Siswa
            </span>
          </div>

          {/* Realistic ATM / Debit Bank Card Visual */}
          <div className="w-full rounded-3xl p-6 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 text-white shadow-2xl border border-slate-700/80 relative overflow-hidden space-y-6">
            
            {/* Background Decorative Rings */}
            <div className="absolute -right-8 -top-8 w-36 h-36 rounded-full bg-amber-500/10 blur-xl pointer-events-none" />
            <div className="absolute -left-8 -bottom-8 w-36 h-36 rounded-full bg-emerald-500/10 blur-xl pointer-events-none" />

            {/* Top row: Chip and Bank Name */}
            <div className="flex items-center justify-between relative z-10">
              <div className="flex items-center gap-2">
                {/* Gold Chip representation */}
                <div className="w-11 h-8 rounded-lg bg-gradient-to-tr from-amber-400 via-amber-200 to-amber-500 shadow-inner flex flex-col justify-between p-1 border border-amber-300">
                  <div className="h-[1px] bg-amber-600/60 w-full" />
                  <div className="h-[1px] bg-amber-600/60 w-full" />
                </div>
                <span className="text-[10px] font-mono text-slate-400">DEBIT / REKENING</span>
              </div>
              <span className="text-sm font-black tracking-wider text-amber-400 uppercase">
                {config.bank_name || 'BANK'}
              </span>
            </div>

            {/* Card Number */}
            <div className="space-y-1 relative z-10">
              <span className="text-[10px] font-medium text-slate-400 uppercase tracking-widest block">
                Nomor Rekening Tujuan
              </span>
              <div className="flex items-center justify-between gap-2">
                <span className="text-lg sm:text-xl font-mono font-black tracking-widest text-white">
                  {config.bank_account_number || '0000 0000 0000'}
                </span>
                <button
                  type="button"
                  onClick={handleCopyTest}
                  className="p-1.5 bg-slate-800/80 hover:bg-slate-700 text-amber-300 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors border border-slate-700"
                  title="Salin Nomor Rekening"
                >
                  {copiedAccount ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Bottom Row: Card Holder & Security Badge */}
            <div className="flex items-end justify-between border-t border-slate-800 pt-3 relative z-10">
              <div>
                <span className="text-[9px] font-medium text-slate-400 uppercase tracking-wider block">
                  Atas Nama Pemilik
                </span>
                <span className="text-xs sm:text-sm font-black text-slate-200 uppercase truncate max-w-[200px] block">
                  {config.bank_account_holder || 'BERESIN OFFICIAL'}
                </span>
              </div>
              <div className="flex items-center gap-1 text-[10px] font-bold text-amber-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Terverifikasi</span>
              </div>
            </div>

          </div>

          {/* Quick WhatsApp Preview Box */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase block">
              Pratinjau Tombol WhatsApp Siswa
            </span>
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-black text-emerald-950">Admin BERESIN</p>
                  <p className="text-[11px] text-emerald-700 font-mono">{config.whatsapp_number}</p>
                </div>
              </div>
              <a
                href={testWaLink}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-1 bg-white hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-bold border border-emerald-300"
              >
                Chat Sekarang
              </a>
            </div>
          </div>

          {/* Instruction helper */}
          <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl text-xs text-amber-950 space-y-1">
            <p className="font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-amber-600" />
              <span>Privasi & Kebebasan Admin</span>
            </p>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Anda dapat mengganti rekening ini kapan saja dengan rekening bank manapun (BCA, Mandiri, BRI, Bank Jago, SeaBank, atau e-wallet). Begitu disimpan, pemesan langsung melihat nomor yang baru.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};

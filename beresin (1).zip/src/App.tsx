import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { BeresinDataStore } from './lib/supabase';
import { BeresinStorage } from './lib/fileStorage';
import { ServiceItem, OrderItem, VoucherCode, UserProfile } from './types';

// Top Navigation
import { Header } from './components/Header';
import { MobileHeader } from './components/MobileHeader';
import { BottomNavigation, MobileTab } from './components/BottomNavigation';

// Main Views & Tabs
import { MobileHomeView } from './components/MobileHomeView';
import { OrdersTab } from './components/OrdersTab';
import { VoucherTab } from './components/VoucherTab';
import { ProfileTab } from './components/ProfileTab';
import { AdminDashboard } from './components/AdminDashboard';
import { PromoBanner } from './components/PromoBanner';
import { ServiceList } from './components/ServiceList';
import { Footer } from './components/Footer';
import { LandingPage } from './components/LandingPage';

// Modals
import { OrderModal } from './components/OrderModal';
import { AuthModal } from './components/AuthModal';
import { QRISPaymentModal } from './components/QRISPaymentModal';
import { RevisionModal } from './components/RevisionModal';
import { SupabaseModal } from './components/SupabaseModal';
import { X, Eye, Download } from 'lucide-react';

const BeresinMainApp: React.FC = () => {
  const { currentUser, role, switchUser } = useAuth();

  // Navigation State
  const [mobileTab, setMobileTab] = useState<MobileTab>('beranda');
  const [desktopView, setDesktopView] = useState<'home' | 'student-orders' | 'admin-panel'>('home');

  // Data State
  const [services, setServices] = useState<ServiceItem[]>(() => BeresinDataStore.getServices());
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [vouchers, setVouchers] = useState<VoucherCode[]>(() => BeresinDataStore.getVouchers());
  const [users, setUsers] = useState<UserProfile[]>(() => BeresinDataStore.getUsers());

  // Modal States
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [selectedServiceForOrder, setSelectedServiceForOrder] = useState<ServiceItem | null>(null);

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('register');

  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentOrder, setPaymentOrder] = useState<OrderItem | null>(null);

  const [isRevisionModalOpen, setIsRevisionModalOpen] = useState(false);
  const [revisionOrder, setRevisionOrder] = useState<OrderItem | null>(null);

  const [isSupabaseModalOpen, setIsSupabaseModalOpen] = useState(false);

  // Proof Image Preview Modal
  const [proofPreviewUrl, setProofPreviewUrl] = useState<string | null>(null);
  const [proofPreviewName, setProofPreviewName] = useState<string>('');

  // Reload data from store
  const refreshData = () => {
    setServices(BeresinDataStore.getServices());
    setVouchers(BeresinDataStore.getVouchers());
    setUsers(BeresinDataStore.getUsers());

    if (currentUser?.role === 'ADMIN') {
      setOrders(BeresinDataStore.getOrders());
    } else if (currentUser) {
      setOrders(BeresinDataStore.getOrdersByStudent(currentUser.id));
    } else {
      setOrders([]);
    }
  };

  useEffect(() => {
    refreshData();
  }, [currentUser, role]);

  // Sync role switch with default views
  useEffect(() => {
    if (role === 'ADMIN') {
      setDesktopView('admin-panel');
    } else {
      if (desktopView === 'admin-panel') {
        setDesktopView('home');
      }
    }
  }, [role]);

  // Handlers for Order Modal
  const handleOpenOrderModal = (service?: ServiceItem) => {
    if (!currentUser) {
      setAuthModalMode('register');
      setIsAuthModalOpen(true);
      return;
    }
    setSelectedServiceForOrder(service || null);
    setIsOrderModalOpen(true);
  };

  // Handlers for Auth Modal
  const handleOpenAuth = (mode: 'login' | 'register') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  // Handlers for QRIS Payment
  const handleOpenPayment = (order: OrderItem) => {
    setPaymentOrder(order);
    setIsPaymentModalOpen(true);
  };

  // Handlers for Revision
  const handleOpenRevision = (order: OrderItem) => {
    setRevisionOrder(order);
    setIsRevisionModalOpen(true);
  };

  // Handlers for Proof Photo View
  const handleViewProof = async (order: OrderItem) => {
    const proofUrl = order.payment_proof_url;
    setProofPreviewName(order.payment_proof_name || 'Bukti Transfer');
    if (proofUrl) {
      const localUrl = await BeresinStorage.getStoredFileBlobUrl(proofUrl);
      setProofPreviewUrl(localUrl || proofUrl);
    } else {
      setProofPreviewUrl(null);
    }
  };

  // Count active orders for badges
  const activeOrdersCount = orders.filter(
    (o) => o.status !== 'SELESAI' && o.status !== 'DIBATALKAN'
  ).length;

  // 0. PUBLIC LANDING PAGE (If not logged in)
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
        <LandingPage
          services={services}
          onOpenAuth={handleOpenAuth}
          onSelectService={(srv) => {
            setSelectedServiceForOrder(srv);
            handleOpenAuth('register');
          }}
        />

        {/* Global Auth Modal */}
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          initialMode={authModalMode}
        />

        {/* Supabase Modal */}
        <SupabaseModal
          isOpen={isSupabaseModalOpen}
          onClose={() => setIsSupabaseModalOpen(false)}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col antialiased selection:bg-amber-400 selection:text-slate-950 font-sans pb-20 md:pb-0">
      
      {/* 1. Desktop & Tablet Header */}
      <div className="hidden md:block sticky top-0 z-40">
        <Header
          activeView={desktopView}
          setActiveView={(view) => {
            setDesktopView(view);
            if (view === 'home') setMobileTab('beranda');
            else if (view === 'student-orders') setMobileTab('pesanan');
            else if (view === 'admin-panel') setMobileTab('profil');
          }}
          onOpenOrderModal={() => handleOpenOrderModal()}
          onOpenAuth={handleOpenAuth}
          onOpenSupabaseModal={() => setIsSupabaseModalOpen(true)}
        />
      </div>

      {/* 2. Mobile App Header */}
      <div className="block md:hidden sticky top-0 z-40">
        <MobileHeader
          title={
            mobileTab === 'beranda' ? 'BERESIN' :
            mobileTab === 'pesanan' ? 'Pesanan Saya' :
            mobileTab === 'voucher' ? 'Voucher Promo' :
            'Profil Pengguna'
          }
          onBack={mobileTab !== 'beranda' ? () => setMobileTab('beranda') : undefined}
          onOpenAuth={handleOpenAuth}
          onOpenSupabaseModal={() => setIsSupabaseModalOpen(true)}
        />
      </div>

      {/* 3. Main Content Area */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
        
        {/* DESKTOP VIEW RENDERING */}
        <div className="hidden md:block">
          {desktopView === 'home' && (
            <div className="space-y-8">
              {/* Promo Banner */}
              <PromoBanner
                onClaimVoucher={() => {
                  if (!currentUser) {
                    handleOpenAuth('register');
                  } else {
                    setMobileTab('voucher');
                    setDesktopView('student-orders');
                  }
                }}
                onOrderNow={() => handleOpenOrderModal()}
              />

              {/* Service Catalog */}
              <ServiceList
                services={services}
                onSelectService={(srv) => handleOpenOrderModal(srv)}
              />

              {/* Quick Summary of Active Orders if Logged In */}
              {currentUser && orders.length > 0 && (
                <div className="pt-4 border-t border-slate-200">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-black text-slate-900">
                        {role === 'ADMIN' ? 'Pesanan Masuk Terbaru' : 'Pesanan Aktifmu'}
                      </h3>
                      <p className="text-xs text-slate-500">
                        Pantau status penawaran, pengerjaan, dan pengiriman berkas
                      </p>
                    </div>
                    <button
                      onClick={() => setDesktopView(role === 'ADMIN' ? 'admin-panel' : 'student-orders')}
                      className="text-xs font-bold text-amber-700 hover:text-amber-800 hover:underline"
                    >
                      Buka Panel Pesanan ({orders.length}) →
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {orders.slice(0, 2).map((ord) => (
                      <div
                        key={ord.id}
                        onClick={() => setDesktopView(role === 'ADMIN' ? 'admin-panel' : 'student-orders')}
                        className="bg-white rounded-2xl p-4 border border-slate-200 hover:border-amber-400 shadow-xs cursor-pointer flex items-center justify-between transition-all"
                      >
                        <div className="space-y-1">
                          <span className="font-mono text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                            {ord.order_number}
                          </span>
                          <h4 className="text-sm font-bold text-slate-900">{ord.service_name}</h4>
                          <p className="text-xs text-slate-500">
                            Status: <strong className="text-slate-800">{ord.status.replace('_', ' ')}</strong>
                          </p>
                        </div>
                        <span className="text-xs font-bold text-amber-600 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200">
                          Lihat Detail
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {desktopView === 'student-orders' && (
            <OrdersTab
              orders={orders}
              onRefreshData={refreshData}
              onOpenNewOrder={() => handleOpenOrderModal()}
              onOpenQRIS={handleOpenPayment}
              onOpenRevision={handleOpenRevision}
            />
          )}

          {desktopView === 'admin-panel' && (
            <AdminDashboard
              orders={orders}
              services={services}
              vouchers={vouchers}
              onRefreshData={refreshData}
              onSelectOrder={() => {}}
              onViewProof={handleViewProof}
            />
          )}
        </div>

        {/* MOBILE VIEW RENDERING */}
        <div className="block md:hidden">
          {role === 'ADMIN' ? (
            <AdminDashboard
              orders={orders}
              services={services}
              vouchers={vouchers}
              onRefreshData={refreshData}
              onSelectOrder={() => {}}
              onViewProof={handleViewProof}
            />
          ) : (
            <>
              {mobileTab === 'beranda' && (
                <MobileHomeView
                  services={services}
                  orders={orders}
                  onSelectService={(srv) => handleOpenOrderModal(srv)}
                  onOpenOrderModal={() => handleOpenOrderModal()}
                  onOpenVoucherTab={() => setMobileTab('voucher')}
                  onOpenOrdersTab={() => setMobileTab('pesanan')}
                  onOpenAuth={handleOpenAuth}
                />
              )}

              {mobileTab === 'pesanan' && (
                <OrdersTab
                  orders={orders}
                  onRefreshData={refreshData}
                  onOpenNewOrder={() => handleOpenOrderModal()}
                  onOpenQRIS={handleOpenPayment}
                  onOpenRevision={handleOpenRevision}
                />
              )}

              {mobileTab === 'voucher' && (
                <VoucherTab
                  vouchers={vouchers}
                  onRefreshData={refreshData}
                  onOpenOrder={() => handleOpenOrderModal()}
                />
              )}

              {mobileTab === 'profil' && (
                <ProfileTab
                  services={services}
                  users={users}
                  onRefreshData={refreshData}
                  onOpenSupabaseModal={() => setIsSupabaseModalOpen(true)}
                  onOpenAuth={handleOpenAuth}
                />
              )}
            </>
          )}
        </div>

      </main>

      {/* 4. Desktop & Tablet Footer */}
      <div className="hidden md:block">
        <Footer onOpenSupabaseModal={() => setIsSupabaseModalOpen(true)} />
      </div>

      {/* 5. Mobile Bottom Navigation (Only for Students) */}
      {role === 'STUDENT' && (
        <div className="block md:hidden">
          <BottomNavigation
            activeTab={mobileTab}
            onChangeTab={(tab) => setMobileTab(tab)}
            activeOrdersCount={activeOrdersCount}
          />
        </div>
      )}

      {/* ========================================================================= */}
      {/* GLOBAL MODALS */}
      {/* ========================================================================= */}

      {/* 1. ORDER CREATION MODAL */}
      <OrderModal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        services={services}
        selectedService={selectedServiceForOrder}
        onOrderCreated={() => {
          refreshData();
          setMobileTab('pesanan');
          setDesktopView('student-orders');
        }}
        onNeedAuth={() => {
          setIsOrderModalOpen(false);
          handleOpenAuth('register');
        }}
      />

      {/* 2. AUTH MODAL (LOGIN / REGISTER) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => {
          setIsAuthModalOpen(false);
          refreshData();
        }}
        initialMode={authModalMode}
      />

      {/* 3. QRIS PAYMENT MODAL */}
      <QRISPaymentModal
        isOpen={isPaymentModalOpen}
        order={paymentOrder}
        onClose={() => {
          setIsPaymentModalOpen(false);
          setPaymentOrder(null);
        }}
        onSuccess={() => {
          refreshData();
        }}
      />

      {/* 4. REVISION MODAL */}
      <RevisionModal
        isOpen={isRevisionModalOpen}
        order={revisionOrder}
        onClose={() => {
          setIsRevisionModalOpen(false);
          setRevisionOrder(null);
        }}
        onSuccess={() => {
          refreshData();
        }}
      />

      {/* 5. SUPABASE ARCHITECTURE & SECURITY MODAL */}
      <SupabaseModal
        isOpen={isSupabaseModalOpen}
        onClose={() => setIsSupabaseModalOpen(false)}
      />

      {/* 6. PAYMENT PROOF IMAGE PREVIEW MODAL */}
      {proofPreviewUrl && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-amber-600" />
                <span className="font-bold text-xs text-slate-900 truncate max-w-[240px]">
                  {proofPreviewName}
                </span>
              </div>
              <button
                onClick={() => setProofPreviewUrl(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 max-h-[70vh] overflow-auto flex items-center justify-center bg-slate-950">
              <img
                src={proofPreviewUrl}
                alt="Bukti Transfer Pembayaran"
                className="max-h-[65vh] object-contain rounded-xl shadow-md"
              />
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500 text-[11px]">Pratinjau Bukti Pembayaran Siswa</span>
              <button
                onClick={() => BeresinStorage.triggerDownload(proofPreviewUrl, proofPreviewName)}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh Foto</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <BeresinMainApp />
    </AuthProvider>
  );
}

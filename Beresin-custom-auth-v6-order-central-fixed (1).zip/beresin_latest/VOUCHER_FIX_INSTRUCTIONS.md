# VOUCHER CENTRAL FIX

1. Jalankan seluruh `VOUCHER_CENTRAL_FIX.sql` di Supabase SQL Editor.
2. Build/deploy aplikasi dari ZIP terbaru.
3. Buat voucher baru dari menu Admin → Kode Voucher Promo.
4. Voucher yang dibuat sekarang tersimpan di `public.vouchers`, bukan localStorage.
5. User dapat mengklaim voucher yang sama dari HP/browser lain; saldo bertambah di `public.profiles`.
6. Setelah klaim, Admin akan melihat status `Sudah Digunakan` setelah refresh/polling.

**Catatan:** kode voucher lama yang hanya pernah dibuat oleh versi browser/localStorage tidak ada di database pusat. Buat ulang kode tersebut melalui menu Admin setelah SQL dijalankan.

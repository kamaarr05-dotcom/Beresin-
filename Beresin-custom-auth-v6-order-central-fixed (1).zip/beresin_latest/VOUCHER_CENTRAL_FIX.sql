-- BERESIN — VOUCHER CENTRAL FIX v2
-- Jalankan SEKALI di Supabase SQL Editor.
-- Sumber data voucher: public.vouchers (database pusat), bukan localStorage.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.vouchers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT UNIQUE NOT NULL,
    value NUMERIC(10,2) NOT NULL DEFAULT 30000,
    cost_price NUMERIC(10,2) NOT NULL DEFAULT 10000,
    is_used BOOLEAN NOT NULL DEFAULT FALSE,
    used_by_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    used_by_email TEXT,
    used_by_name TEXT,
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.vouchers ADD COLUMN IF NOT EXISTS value NUMERIC(10,2) DEFAULT 30000;
ALTER TABLE public.vouchers ADD COLUMN IF NOT EXISTS cost_price NUMERIC(10,2) DEFAULT 10000;
ALTER TABLE public.vouchers ADD COLUMN IF NOT EXISTS is_used BOOLEAN DEFAULT FALSE;
ALTER TABLE public.vouchers ADD COLUMN IF NOT EXISTS used_by_user_id UUID;
ALTER TABLE public.vouchers ADD COLUMN IF NOT EXISTS used_by_email TEXT;
ALTER TABLE public.vouchers ADD COLUMN IF NOT EXISTS used_by_name TEXT;
ALTER TABLE public.vouchers ADD COLUMN IF NOT EXISTS used_at TIMESTAMPTZ;
ALTER TABLE public.vouchers ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW();

CREATE OR REPLACE FUNCTION public.redeem_voucher_code(
    p_code TEXT,
    p_user_id UUID,
    p_user_email TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
    v_code TEXT := UPPER(TRIM(COALESCE(p_code, '')));
    v_voucher public.vouchers%ROWTYPE;
    v_user public.profiles%ROWTYPE;
BEGIN
    IF v_code = '' THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher wajib diisi.');
    END IF;

    SELECT * INTO v_user
    FROM public.profiles
    WHERE id = p_user_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Pengguna tidak ditemukan.');
    END IF;

    SELECT * INTO v_voucher
    FROM public.vouchers
    WHERE UPPER(TRIM(code)) = v_code
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tidak ditemukan di database pusat.');
    END IF;

    IF COALESCE(v_voucher.is_used, FALSE) THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher sudah pernah digunakan.');
    END IF;

    UPDATE public.vouchers
    SET is_used = TRUE,
        used_by_user_id = v_user.id,
        used_by_email = v_user.email,
        used_by_name = v_user.full_name,
        used_at = NOW()
    WHERE id = v_voucher.id;

    UPDATE public.profiles
    SET voucher_balance = COALESCE(voucher_balance, 0) + COALESCE(v_voucher.value, 0),
        voucher_code_used = v_voucher.code,
        updated_at = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'success', true,
        'message', format(
            'Selamat! Kode %s berhasil diklaim. Saldo bertambah Rp%s.',
            v_voucher.code,
            to_char(v_voucher.value, 'FM999G999G999')
        ),
        'value', v_voucher.value,
        'voucher_code', v_voucher.code
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.custom_get_vouchers(
    p_admin_user_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = p_admin_user_id AND role = 'ADMIN'
    ) THEN
        RETURN '[]'::jsonb;
    END IF;

    RETURN COALESCE((
        SELECT jsonb_agg(
            jsonb_build_object(
                'id', v.id,
                'code', v.code,
                'value', v.value,
                'cost_price', v.cost_price,
                'is_used', COALESCE(v.is_used, FALSE),
                'used_by_user_id', v.used_by_user_id,
                'used_by_email', v.used_by_email,
                'used_by_name', v.used_by_name,
                'used_at', v.used_at,
                'created_at', v.created_at
            ) ORDER BY v.created_at DESC
        ) FROM public.vouchers v
    ), '[]'::jsonb);
END;
$$;

CREATE OR REPLACE FUNCTION public.custom_create_voucher(
    p_admin_user_id UUID,
    p_code TEXT,
    p_value NUMERIC,
    p_cost_price NUMERIC
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
    v_code TEXT := UPPER(TRIM(COALESCE(p_code, '')));
    v_voucher public.vouchers%ROWTYPE;
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = p_admin_user_id AND role = 'ADMIN'
    ) THEN
        RETURN jsonb_build_object('success', false, 'message', 'Akses admin diperlukan.');
    END IF;

    IF v_code = '' THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tidak boleh kosong.');
    END IF;

    IF COALESCE(p_value, 0) <= 0 THEN
        RETURN jsonb_build_object('success', false, 'message', 'Nilai voucher harus lebih dari 0.');
    END IF;

    IF COALESCE(p_cost_price, 0) < 0 THEN
        RETURN jsonb_build_object('success', false, 'message', 'Harga beli voucher tidak valid.');
    END IF;

    IF EXISTS (SELECT 1 FROM public.vouchers WHERE UPPER(TRIM(code)) = v_code) THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tersebut sudah ada di database.');
    END IF;

    INSERT INTO public.vouchers (code, value, cost_price, is_used)
    VALUES (v_code, p_value, p_cost_price, FALSE)
    RETURNING * INTO v_voucher;

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Voucher berhasil dibuat dan tersimpan di database pusat.',
        'voucher', jsonb_build_object(
            'id', v_voucher.id,
            'code', v_voucher.code,
            'value', v_voucher.value,
            'cost_price', v_voucher.cost_price,
            'is_used', v_voucher.is_used,
            'created_at', v_voucher.created_at
        )
    );
EXCEPTION
    WHEN unique_violation THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tersebut sudah ada di database.');
END;
$$;

REVOKE ALL ON FUNCTION public.redeem_voucher_code(TEXT, UUID, TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.custom_get_vouchers(UUID) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.custom_create_voucher(UUID, TEXT, NUMERIC, NUMERIC) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.redeem_voucher_code(TEXT, UUID, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_get_vouchers(UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_create_voucher(UUID, TEXT, NUMERIC, NUMERIC) TO anon, authenticated;

SELECT 'Voucher central fix v2 aktif.' AS status;

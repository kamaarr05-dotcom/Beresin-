import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { 
  UserProfile, 
  ServiceItem, 
  VoucherCode, 
  OrderItem, 
  OrderStatus, 
  NegotiationStatus,
  AdminPaymentConfig
} from '../types';
import { 
  INITIAL_SERVICES, 
  INITIAL_VOUCHERS, 
  INITIAL_USERS, 
  INITIAL_ORDERS 
} from './mockData';

// Supabase Environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const isSupabaseConfigured = Boolean(
  supabaseUrl && 
  supabaseAnonKey && 
  supabaseUrl !== 'https://your-project.supabase.co' &&
  supabaseAnonKey !== 'your-anon-key'
);

let supabaseInstance: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient | null {
  if (!isSupabaseConfigured) {
    return null;
  }
  if (!supabaseInstance) {
    try {
      supabaseInstance = createClient(supabaseUrl!, supabaseAnonKey!);
    } catch (err) {
      console.warn('Gagal inisialisasi Supabase client:', err);
      return null;
    }
  }
  return supabaseInstance;
}

export const DEFAULT_PAYMENT_CONFIG: AdminPaymentConfig = {
  whatsapp_number: '08136732365',
  whatsapp_greeting: 'Halo Admin BERESIN, saya mau tanya pengerjaan tugas & voucher promo',
  bank_name: 'BCA',
  bank_account_number: '887012345678',
  bank_account_holder: 'BERESIN JASA',
  qris_merchant_name: 'BERESIN JASA',
  qris_nmid: 'ID1020304050',
  payment_instructions: 'Scan QRIS atau transfer ke rekening bank di atas sesuai nominal pesanan, lalu upload bukti transfer screenshot.',
};

// Local Storage Keys for offline/demo/resilient persistence
const STORAGE_KEYS = {
  SERVICES: 'beresin_services_v1',
  VOUCHERS: 'beresin_vouchers_v1',
  USERS: 'beresin_users_v1',
  ORDERS: 'beresin_orders_v1',
  PAYMENT_CONFIG: 'beresin_payment_config_v1',
};

// Storage Helpers
function getStored<T>(key: string, defaultVal: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return defaultVal;
    return JSON.parse(item);
  } catch {
    return defaultVal;
  }
}

function setStored<T>(key: string, val: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (err) {
    console.error('LocalStorage write error:', err);
  }
}

// Data Store Layer
export class BeresinDataStore {
  // Services
  static getServices(): ServiceItem[] {
    const stored = getStored<ServiceItem[]>(STORAGE_KEYS.SERVICES, INITIAL_SERVICES);
    const existingIds = new Set(stored.map(s => s.id));
    let modified = false;
    const merged = [...stored];
    for (const initSrv of INITIAL_SERVICES) {
      if (!existingIds.has(initSrv.id)) {
        merged.push(initSrv);
        existingIds.add(initSrv.id);
        modified = true;
      }
    }
    if (modified) {
      this.saveServices(merged);
    }
    return merged;
  }

  static saveServices(services: ServiceItem[]): void {
    setStored(STORAGE_KEYS.SERVICES, services);
  }

  static updateServicePrice(serviceId: string, newPrice: number): ServiceItem[] {
    const services = this.getServices().map(s => {
      if (s.id === serviceId) {
        return {
          ...s,
          base_price: newPrice,
          unit_label: `mulai Rp${newPrice.toLocaleString('id-ID')}`,
        };
      }
      return s;
    });
    this.saveServices(services);
    return services;
  }

  static updateService(serviceOrId: ServiceItem | string, updates?: Partial<ServiceItem>): ServiceItem[] {
    const services = this.getServices().map(s => {
      if (typeof serviceOrId === 'string') {
        if (s.id === serviceOrId) {
          return { ...s, ...updates };
        }
        return s;
      }
      return s.id === serviceOrId.id ? serviceOrId : s;
    });
    this.saveServices(services);
    return services;
  }

  static createService(serviceData: Omit<ServiceItem, 'id'>): ServiceItem {
    const newService: ServiceItem = {
      ...serviceData,
      id: `srv-${Date.now()}`,
    };
    const services = [...this.getServices(), newService];
    this.saveServices(services);
    return newService;
  }

  static deleteService(serviceId: string): ServiceItem[] {
    const services = this.getServices().filter(s => s.id !== serviceId);
    this.saveServices(services);
    return services;
  }

  // Vouchers
  static getVouchers(): VoucherCode[] {
    return getStored<VoucherCode[]>(STORAGE_KEYS.VOUCHERS, INITIAL_VOUCHERS);
  }

  static saveVouchers(vouchers: VoucherCode[]): void {
    setStored(STORAGE_KEYS.VOUCHERS, vouchers);
  }

  // Central voucher APIs. Voucher balances and voucher status must live in
  // Supabase so they stay synchronized across phones/browsers.
  static async getRemoteVouchers(adminUserId?: string): Promise<VoucherCode[]> {
    const supabase = getSupabase();
    if (!supabase) return [];

    if (!adminUserId) return [];

    const { data, error } = await supabase.rpc('custom_get_vouchers', {
      p_admin_user_id: adminUserId,
    });
    if (error) {
      console.warn('Gagal mengambil voucher dari database:', error.message);
      return [];
    }

    // PostgreSQL JSONB RPC returns the array directly. Never fall back to
    // localStorage here, otherwise Admin could see a stale voucher that does
    // not exist centrally and the Student would then get "voucher not found".
    if (!Array.isArray(data)) {
      console.warn('Data voucher dari database bukan array.');
      return [];
    }

    const mapped = data.map((v: any): VoucherCode => ({
      id: String(v.id),
      code: String(v.code),
      value: Number(v.value) || 0,
      cost_price: Number(v.cost_price) || 0,
      is_used: Boolean(v.is_used),
      used_by_email: v.used_by_email || undefined,
      used_by_name: v.used_by_name || undefined,
      used_at: v.used_at || undefined,
      created_at: String(v.created_at || new Date().toISOString()),
    }));

    this.saveVouchers(mapped);
    return mapped;
  }

  static async createRemoteVoucher(
    adminUserId: string,
    data: { code: string; value: number; cost_price: number }
  ): Promise<{ success: boolean; message: string; voucher?: VoucherCode }> {
    const supabase = getSupabase();
    if (!supabase) return { success: false, message: 'Database belum terhubung.' };

    const { data: result, error } = await supabase.rpc('custom_create_voucher', {
      p_admin_user_id: adminUserId,
      p_code: data.code.trim().toUpperCase(),
      p_value: data.value,
      p_cost_price: data.cost_price,
    });

    if (error) return { success: false, message: error.message || 'Gagal membuat voucher.' };
    if (!result?.success) return { success: false, message: result?.message || 'Gagal membuat voucher.' };

    const voucher = result.voucher ? {
      id: String(result.voucher.id),
      code: String(result.voucher.code),
      value: Number(result.voucher.value) || 0,
      cost_price: Number(result.voucher.cost_price) || 0,
      is_used: Boolean(result.voucher.is_used),
      created_at: String(result.voucher.created_at || new Date().toISOString()),
    } : undefined;

    return { success: true, message: result.message || 'Voucher berhasil dibuat.', voucher };
  }

  static async redeemRemoteVoucher(
    userId: string,
    userEmail: string,
    code: string
  ): Promise<{ success: boolean; message: string; value?: number }> {
    const supabase = getSupabase();
    if (!supabase) return { success: false, message: 'Database belum terhubung.' };

    const { data: result, error } = await supabase.rpc('redeem_voucher_code', {
      p_code: code.trim().toUpperCase(),
      p_user_id: userId,
      p_user_email: userEmail,
    });

    if (error) return { success: false, message: error.message || 'Gagal mengklaim voucher.' };
    if (!result?.success) return { success: false, message: result?.message || 'Gagal mengklaim voucher.' };

    return {
      success: true,
      message: result.message || 'Voucher berhasil diklaim!',
      value: Number(result.value) || 0,
    };
  }

  static validateVoucher(code: string): { valid: boolean; message: string; voucher?: VoucherCode } {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) {
      return { valid: false, message: 'Silakan masukkan kode voucher.' };
    }

    const vouchers = this.getVouchers();
    const found = vouchers.find(v => v.code.toUpperCase() === cleanCode);

    if (!found) {
      return { 
        valid: false, 
        message: 'Kode voucher tidak valid atau belum terdaftar. Hubungi Admin untuk klaim kode promo Rp10.000.' 
      };
    }

    if (found.is_used) {
      return { 
        valid: false, 
        message: 'Kode voucher ini sudah pernah digunakan. Setiap kode hanya berlaku satu kali.' 
      };
    }

    return { 
      valid: true, 
      message: `Kode valid! Selamat, kamu berhak atas Saldo Voucher Jasa Rp${found.value.toLocaleString('id-ID')}.`,
      voucher: found 
    };
  }

  static createVoucher(
    codeOrData: string | { code: string; value?: number; cost_price?: number }, 
    value = 30000, 
    cost_price = 10000
  ): { success: boolean; message: string; voucher?: VoucherCode } {
    let finalCode = '';
    let finalValue = value;
    let finalCost = cost_price;

    if (typeof codeOrData === 'object') {
      finalCode = (codeOrData.code || '').trim().toUpperCase();
      finalValue = codeOrData.value ?? value;
      finalCost = codeOrData.cost_price ?? cost_price;
    } else {
      finalCode = (codeOrData || '').trim().toUpperCase();
    }

    if (!finalCode) {
      return { success: false, message: 'Kode voucher tidak boleh kosong.' };
    }

    const vouchers = this.getVouchers();
    if (vouchers.some(v => v.code.toUpperCase() === finalCode)) {
      return { success: false, message: 'Kode voucher tersebut sudah ada di sistem.' };
    }

    const newVoucher: VoucherCode = {
      id: `vch-${Date.now()}`,
      code: finalCode,
      value: finalValue,
      cost_price: finalCost,
      is_used: false,
      created_at: new Date().toISOString(),
    };

    vouchers.unshift(newVoucher);
    this.saveVouchers(vouchers);
    return { success: true, message: 'Voucher berhasil dibuat.', voucher: newVoucher };
  }

  // Users
  static getUsers(): UserProfile[] {
    let users = getStored<UserProfile[]>(STORAGE_KEYS.USERS, INITIAL_USERS);
    // Sole Admin Configuration requested by user
    const SOLE_ADMIN_EMAIL = 'mdqputra@gmail.com';
    
    // Remove legacy admin accounts (e.g. admin@beresin.id)
    const filtered = users.filter(u => u.email.toLowerCase() !== 'admin@beresin.id');
    
    // Ensure NO OTHER user has role 'ADMIN'
    let hadStoredPasswords = false;
    const sanitized = filtered.map(u => {
      const userWithLegacyPassword = u as UserProfile & { password?: string };
      if (userWithLegacyPassword.password) hadStoredPasswords = true;
      const { password: _password, ...safeUser } = userWithLegacyPassword;
      if (safeUser.email.toLowerCase() !== SOLE_ADMIN_EMAIL && safeUser.role === 'ADMIN') {
        return { ...safeUser, role: 'STUDENT' as const };
      }
      return safeUser;
    });

    // Keep the legacy local user list only for non-auth application data.
    // Passwords are deliberately stripped and are never persisted locally.
    const adminIdx = sanitized.findIndex(u => u.email.toLowerCase() === SOLE_ADMIN_EMAIL);
    let changed = sanitized.length !== users.length || hadStoredPasswords;
    if (adminIdx === -1) {
      sanitized.unshift({
        id: 'usr-admin-mdq',
        email: SOLE_ADMIN_EMAIL,
        full_name: 'Admin Utama BERESIN',
        whatsapp: '081234567890',
        role: 'ADMIN',
        voucher_balance: 0,
        created_at: new Date().toISOString(),
      });
      changed = true;
    } else if (sanitized[adminIdx].role !== 'ADMIN') {
      sanitized[adminIdx] = { ...sanitized[adminIdx], role: 'ADMIN' };
      changed = true;
    }

    if (changed) {
      this.saveUsers(sanitized);
    }
    return sanitized;
  }

  static saveUsers(users: UserProfile[]): void {
    setStored(STORAGE_KEYS.USERS, users);
  }

  static getUserById(id: string): UserProfile | undefined {
    return this.getUsers().find(u => u.id === id);
  }

  // Payment & WhatsApp Configuration
  static getPaymentConfig(): AdminPaymentConfig {
    return getStored<AdminPaymentConfig>(STORAGE_KEYS.PAYMENT_CONFIG, DEFAULT_PAYMENT_CONFIG);
  }

  static savePaymentConfig(config: AdminPaymentConfig): void {
    setStored(STORAGE_KEYS.PAYMENT_CONFIG, config);
  }

  static getWhatsAppLink(customText?: string): string {
    const config = this.getPaymentConfig();
    let phone = (config.whatsapp_number || '081234567890').replace(/[^0-9]/g, '');
    if (phone.startsWith('0')) {
      phone = '62' + phone.slice(1);
    }
    const text = customText || config.whatsapp_greeting || 'Halo Admin BERESIN, saya butuh bantuan';
    return `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
  }

  static updateUserBalance(userId: string, newBalance: number): void {
    const users = this.getUsers().map(u => {
      if (u.id === userId) {
        return { ...u, voucher_balance: Math.max(0, newBalance) };
      }
      return u;
    });
    this.saveUsers(users);
  }

  // Orders — central Supabase source of truth. Local storage remains only as an offline cache.
  static getOrders(): OrderItem[] {
    return getStored<OrderItem[]>(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
  }

  static async getRemoteOrders(userId: string, isAdmin: boolean): Promise<OrderItem[]> {
    const supabase = getSupabase();
    if (!supabase || !userId) return [];

    const { data, error } = await supabase.rpc('custom_get_orders', {
      p_user_id: userId,
      p_admin: isAdmin,
    });

    if (error) {
      console.warn('Gagal mengambil pesanan dari database:', error.message);
      return [];
    }
    if (!data?.success || !Array.isArray(data.orders)) {
      console.warn('Data pesanan dari database tidak valid:', data?.message);
      return [];
    }

    const orders = data.orders as OrderItem[];
    this.saveOrders(orders);
    return orders;
  }

  static async createRemoteOrder(orderData: {
    student: UserProfile;
    service: ServiceItem;
    instructions: string;
    deadline: string;
    fileName?: string;
    fileUrl?: string;
    fileSize?: number;
    negotiationRequested: boolean;
    negotiationPrice?: number;
    negotiationReason?: string;
  }): Promise<{ success: boolean; message: string; order?: OrderItem }> {
    const supabase = getSupabase();
    if (!supabase) return { success: false, message: 'Database belum terhubung.' };

    const { data: result, error } = await supabase.rpc('custom_create_order', {
      p_student_id: orderData.student.id,
      p_service_id: orderData.service.id,
      p_instructions: orderData.instructions.trim(),
      p_deadline: orderData.deadline,
      p_file_name: orderData.fileName || null,
      p_file_url: orderData.fileUrl || null,
      p_file_size: orderData.fileSize ?? null,
      p_negotiation_requested: orderData.negotiationRequested,
      p_negotiation_price: orderData.negotiationRequested ? orderData.negotiationPrice ?? null : null,
      p_negotiation_reason: orderData.negotiationRequested ? orderData.negotiationReason?.trim() || null : null,
    });

    if (error) return { success: false, message: error.message || 'Gagal membuat pesanan.' };
    if (!result?.success) return { success: false, message: result?.message || 'Gagal membuat pesanan.' };

    const order = result.order as OrderItem | undefined;
    if (order) {
      const cached = this.getOrders().filter(o => o.id !== order.id);
      this.saveOrders([order, ...cached]);
    }
    return { success: true, message: result.message || 'Pesanan berhasil dibuat.', order };
  }

  static getOrderById(orderId: string): OrderItem | undefined {
    return this.getOrders().find(o => o.id === orderId);
  }

  static saveOrders(orders: OrderItem[]): void {
    setStored(STORAGE_KEYS.ORDERS, orders);
  }

  static redeemVoucherCode(userId: string, code: string): { success: boolean; message: string; voucher?: VoucherCode } {
    const check = this.validateVoucher(code);
    if (!check.valid || !check.voucher) {
      return { success: false, message: check.message };
    }

    const user = this.getUserById(userId);
    if (!user) {
      return { success: false, message: 'Pengguna tidak ditemukan.' };
    }

    this.updateUserBalance(userId, user.voucher_balance + check.voucher.value);

    const vouchers = this.getVouchers().map(v => {
      if (v.id === check.voucher!.id) {
        return {
          ...v,
          is_used: true,
          used_by_email: user.email,
          used_by_name: user.full_name,
          used_at: new Date().toISOString(),
        };
      }
      return v;
    });
    this.saveVouchers(vouchers);

    return {
      success: true,
      message: `Selamat! Kode ${check.voucher.code} berhasil diklaim. Saldo bertambah Rp${check.voucher.value.toLocaleString('id-ID')}.`,
      voucher: check.voucher,
    };
  }

  static createOrder(orderData: {
    student: UserProfile;
    service: ServiceItem;
    instructions: string;
    deadline: string;
    fileName?: string;
    fileUrl?: string;
    fileSize?: number;
    negotiationRequested: boolean;
    negotiationPrice?: number;
    negotiationReason?: string;
  }): OrderItem {
    const orders = this.getOrders();
    const orderNumber = `BRS-${new Date().getFullYear().toString().slice(-2)}${(new Date().getMonth() + 1).toString().padStart(2, '0')}-${(orders.length + 1).toString().padStart(3, '0')}`;

    const newOrder: OrderItem = {
      id: `ord-${Date.now()}`,
      order_number: orderNumber,
      student_id: orderData.student.id,
      student_name: orderData.student.full_name,
      student_email: orderData.student.email,
      student_whatsapp: orderData.student.whatsapp,
      service_id: orderData.service.id,
      service_name: orderData.service.name,
      base_price: orderData.service.base_price,
      // If no negotiation requested, base price is candidate price; Admin will verify and set final price
      final_price: orderData.negotiationRequested ? null : orderData.service.base_price,
      voucher_deduction: 0,
      amount_to_pay: 0,
      status: 'MENUNGGU_HARGA',
      instructions: orderData.instructions,
      deadline: orderData.deadline,
      file_name: orderData.fileName,
      file_url: orderData.fileUrl,
      file_size: orderData.fileSize,
      negotiation_requested: orderData.negotiationRequested,
      negotiation_price: orderData.negotiationRequested ? orderData.negotiationPrice : undefined,
      negotiation_reason: orderData.negotiationRequested ? orderData.negotiationReason : undefined,
      negotiation_status: orderData.negotiationRequested ? 'PENDING' : 'NONE',
      payment_method: 'QRIS',
      payment_confirmed: false,
      revision_requested: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    orders.unshift(newOrder);
    this.saveOrders(orders);
    return newOrder;
  }

  // Admin determines final price and applies voucher calculation logic
  static setOrderFinalPrice(
    orderId: string, 
    finalPrice: number, 
    negotiationAction?: { status: NegotiationStatus; adminNote?: string }
  ): { success: boolean; order?: OrderItem; message: string } {
    const orders = this.getOrders();
    const orderIndex = orders.findIndex(o => o.id === orderId);
    if (orderIndex === -1) {
      return { success: false, message: 'Pesanan tidak ditemukan' };
    }

    const order = orders[orderIndex];
    const student = this.getUserById(order.student_id);
    if (!student) {
      return { success: false, message: 'Siswa pemesan tidak ditemukan' };
    }

    // Voucher logic specified in requirement:
    // Jika harga Rp25.000 dan voucher Rp30.000:
    // -> siswa membayar Rp0
    // -> sisa voucher Rp5.000
    // Jika harga Rp45.000:
    // -> voucher Rp30.000
    // -> siswa membayar Rp15.000
    let voucherDeduction = 0;
    let amountToPay = 0;
    let newVoucherBalance = student.voucher_balance;
    let newStatus: OrderStatus = 'MENUNGGU_PEMBAYARAN';

    if (student.voucher_balance >= finalPrice) {
      voucherDeduction = finalPrice;
      amountToPay = 0;
      newVoucherBalance = student.voucher_balance - finalPrice;
      // Because amount to pay is 0, it directly moves to ANTRIAN
      newStatus = 'ANTRIAN';
    } else {
      voucherDeduction = student.voucher_balance;
      amountToPay = finalPrice - student.voucher_balance;
      newVoucherBalance = 0;
      newStatus = 'MENUNGGU_PEMBAYARAN';
    }

    // Update student's voucher balance
    this.updateUserBalance(student.id, newVoucherBalance);

    const updatedOrder: OrderItem = {
      ...order,
      final_price: finalPrice,
      voucher_deduction: voucherDeduction,
      amount_to_pay: amountToPay,
      status: newStatus,
      payment_method: amountToPay === 0 ? 'VOUCHER_ONLY' : 'QRIS',
      payment_confirmed: amountToPay === 0,
      negotiation_status: negotiationAction ? negotiationAction.status : order.negotiation_status,
      admin_negotiation_note: negotiationAction?.adminNote || order.admin_negotiation_note,
      updated_at: new Date().toISOString(),
    };

    orders[orderIndex] = updatedOrder;
    this.saveOrders(orders);

    return { 
      success: true, 
      order: updatedOrder, 
      message: `Harga berhasil ditetapkan sebesar Rp${finalPrice.toLocaleString('id-ID')}. Potongan voucher: Rp${voucherDeduction.toLocaleString('id-ID')}. Sisa bayar: Rp${amountToPay.toLocaleString('id-ID')}.` 
    };
  }

  static confirmPayment(orderId: string, notes?: string): OrderItem | null {
    const orders = this.getOrders();
    const index = orders.findIndex(o => o.id === orderId);
    if (index === -1) return null;

    const updated: OrderItem = {
      ...orders[index],
      payment_confirmed: true,
      status: 'ANTRIAN',
      payment_notes: notes || orders[index].payment_notes,
      updated_at: new Date().toISOString(),
    };

    orders[index] = updated;
    this.saveOrders(orders);
    return updated;
  }

  static updateOrderStatus(orderId: string, newStatus: OrderStatus): OrderItem | null {
    const orders = this.getOrders();
    const index = orders.findIndex(o => o.id === orderId);
    if (index === -1) return null;

    const updated: OrderItem = {
      ...orders[index],
      status: newStatus,
      updated_at: new Date().toISOString(),
    };

    orders[index] = updated;
    this.saveOrders(orders);
    return updated;
  }

  static uploadResult(orderId: string, resultData: {
    fileName: string;
    fileUrl: string;
    notes?: string;
  }): OrderItem | null {
    const orders = this.getOrders();
    const index = orders.findIndex(o => o.id === orderId);
    if (index === -1) return null;

    const updated: OrderItem = {
      ...orders[index],
      result_file_name: resultData.fileName,
      result_file_url: resultData.fileUrl,
      result_notes: resultData.notes,
      status: 'SELESAI',
      completed_at: new Date().toISOString(),
      revision_requested: false,
      updated_at: new Date().toISOString(),
    };

    orders[index] = updated;
    this.saveOrders(orders);
    return updated;
  }

  static submitRevision(orderId: string, revisionNotes: string): OrderItem | null {
    const orders = this.getOrders();
    const index = orders.findIndex(o => o.id === orderId);
    if (index === -1) return null;

    const updated: OrderItem = {
      ...orders[index],
      revision_requested: true,
      revision_notes: revisionNotes,
      revision_requested_at: new Date().toISOString(),
      status: 'REVISI',
      updated_at: new Date().toISOString(),
    };

    orders[index] = updated;
    this.saveOrders(orders);
    return updated;
  }

  static uploadPaymentProof(orderId: string, proofName: string, proofUrl: string): OrderItem | null {
    const orders = this.getOrders();
    const index = orders.findIndex(o => o.id === orderId);
    if (index === -1) return null;

    const updated: OrderItem = {
      ...orders[index],
      payment_proof_name: proofName,
      payment_proof_url: proofUrl,
      updated_at: new Date().toISOString(),
    };

    orders[index] = updated;
    this.saveOrders(orders);
    return updated;
  }

  static setFinalPriceAndVoucher(
    orderId: string, 
    finalPrice: number, 
    negotiationStatus?: NegotiationStatus, 
    adminNote?: string
  ) {
    return this.setOrderFinalPrice(
      orderId, 
      finalPrice, 
      negotiationStatus ? { status: negotiationStatus, adminNote } : undefined
    );
  }

  static getOrdersByStudent(studentId: string): OrderItem[] {
    return this.getOrders().filter(o => o.student_id === studentId);
  }

  static setFinalPrice(
    orderId: string, 
    finalPrice: number, 
    negotiationStatus?: NegotiationStatus, 
    adminNote?: string
  ) {
    return this.setFinalPriceAndVoucher(orderId, finalPrice, negotiationStatus, adminNote);
  }

  static uploadWorkResult(
    orderId: string, 
    fileName: string, 
    fileUrl: string, 
    notes?: string
  ): OrderItem | null {
    return this.uploadResult(orderId, { fileName, fileUrl, notes });
  }

  static completeOrder(orderId: string, fileName: string, notes?: string, fileUrl?: string): OrderItem | null {
    return this.uploadResult(orderId, { fileName, fileUrl: fileUrl || '', notes });
  }

  static submitPaymentProof(orderId: string, proofName: string, proofUrl: string): OrderItem | null {
    return this.uploadPaymentProof(orderId, proofName, proofUrl);
  }

  static requestRevision(orderId: string, revisionNotes: string): OrderItem | null {
    return this.submitRevision(orderId, revisionNotes);
  }
}

import React, { useState, useRef, useEffect } from 'react';
import { ServiceItem, UserProfile } from '../types';
import { 
  X, 
  UploadCloud, 
  FileCheck, 
  Calendar, 
  Clock, 
  AlertCircle, 
  Sparkles, 
  HelpCircle, 
  DollarSign, 
  File as FileIcon, 
  Check,
  Percent
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { BeresinDataStore } from '../lib/supabase';
import { BeresinStorage } from '../lib/fileStorage';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  services: ServiceItem[];
  selectedService: ServiceItem | null;
  onOrderCreated: () => void;
  onNeedAuth: () => void;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  services,
  selectedService,
  onOrderCreated,
  onNeedAuth,
}) => {
  const { currentUser, refreshUser } = useAuth();
  const [currentServiceId, setCurrentServiceId] = useState<string>('');
  const [instructions, setInstructions] = useState('');
  const [deadlineDate, setDeadlineDate] = useState('');
  const [deadlineTime, setDeadlineTime] = useState('18:00');
  
  // File upload state
  const [file, setFile] = useState<File | null>(null);
  const [fileUrl, setFileUrl] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Negotiation state
  const [negotiationRequested, setNegotiationRequested] = useState(false);
  const [negotiationPrice, setNegotiationPrice] = useState<number | ''>('');
  const [negotiationReason, setNegotiationReason] = useState('');

  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize service when modal opens
  useEffect(() => {
    if (selectedService) {
      setCurrentServiceId(selectedService.id);
    } else if (services.length > 0 && !currentServiceId) {
      setCurrentServiceId(services[0].id);
    }
  }, [selectedService, services]);

  // Set default deadline to tomorrow 18:00
  useEffect(() => {
    if (!deadlineDate) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 2);
      const yyyy = tomorrow.getFullYear();
      const mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
      const dd = String(tomorrow.getDate()).padStart(2, '0');
      setDeadlineDate(`${yyyy}-${mm}-${dd}`);
    }
  }, []);

  if (!isOpen) return null;

  const activeService = services.find(s => s.id === currentServiceId) || services[0];
  const userVoucherBalance = currentUser?.voucher_balance || 0;

  // Pricing calculation preview
  const effectiveBasePrice = negotiationRequested && typeof negotiationPrice === 'number' && negotiationPrice > 0
    ? negotiationPrice
    : (activeService?.base_price || 0);

  const estimatedVoucherDeduction = Math.min(effectiveBasePrice, userVoucherBalance);
  const estimatedAmountToPay = Math.max(0, effectiveBasePrice - estimatedVoucherDeduction);
  const estimatedRemainingVoucher = Math.max(0, userVoucherBalance - estimatedVoucherDeduction);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      setFile(selected);
      setFileUrl('');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const dropped = e.dataTransfer.files[0];
      setFile(dropped);
      setFileUrl('');
    }
  };

  const handleRemoveFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setFile(null);
    setFileUrl('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!currentUser) {
      onNeedAuth();
      return;
    }

    if (!instructions.trim()) {
      setErrorMsg('Harap tuliskan instruksi pengerjaan secara jelas.');
      return;
    }

    if (!deadlineDate) {
      setErrorMsg('Harap tentukan tanggal deadline pekerjaan.');
      return;
    }

    if (negotiationRequested) {
      if (!negotiationPrice || Number(negotiationPrice) <= 0) {
        setErrorMsg('Harap masukkan nominal harga yang diajukan untuk negosiasi.');
        return;
      }
      if (!negotiationReason.trim()) {
        setErrorMsg('Harap tuliskan alasan singkat pengajuan negosiasi harga.');
        return;
      }
    }

    setIsSubmitting(true);

    try {
      let uploadedUrl = fileUrl;
      let uploadedName = file?.name;
      let uploadedSize = file?.size;

      if (file) {
        const uploadResult = await BeresinStorage.uploadFile(file);
        uploadedUrl = uploadResult.fileUrl;
        uploadedName = uploadResult.fileName;
        uploadedSize = uploadResult.fileSize;
      }

      const fullDeadline = new Date(`${deadlineDate}T${deadlineTime}:00`).toISOString();

      const result = await BeresinDataStore.createRemoteOrder({
        student: currentUser,
        service: activeService,
        instructions: instructions.trim(),
        deadline: fullDeadline,
        fileName: uploadedName,
        fileUrl: uploadedUrl || undefined,
        fileSize: uploadedSize,
        negotiationRequested,
        negotiationPrice: negotiationRequested ? Number(negotiationPrice) : undefined,
        negotiationReason: negotiationRequested ? negotiationReason.trim() : undefined,
      });

      if (!result.success) {
        setErrorMsg(result.message);
        setIsSubmitting(false);
        return;
      }

      refreshUser();
      setIsSubmitting(false);
      onOrderCreated();
      onClose();
    } catch (err) {
      console.error(err);
      setErrorMsg('Terjadi kesalahan saat mengunggah berkas atau membuat pesanan.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-lg rounded-t-[32px] sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in slide-in-from-bottom sm:zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Mobile Drag Handle Bar */}
        <div className="pt-2.5 pb-1 sm:hidden flex justify-center">
          <div className="w-12 h-1.5 bg-slate-300 rounded-full" />
        </div>

        {/* Modal Header */}
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-white">
          <div>
            <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <span>Formulir Pesanan Jasa</span>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                BERESIN
              </span>
            </h3>
            <p className="text-[11px] text-slate-500">
              Kirim detail tugasmu, diproses cepat & bergaransi.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full active:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="overflow-y-auto p-5 space-y-4 text-slate-800 flex-1">
          
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* 1. Pilih Layanan & Melihat Harga Dasar */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
              1. Pilih Layanan
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {services.filter(s => s.is_active).map(srv => {
                const isSelected = srv.id === currentServiceId;
                return (
                  <button
                    type="button"
                    key={srv.id}
                    onClick={() => setCurrentServiceId(srv.id)}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'bg-amber-50/80 border-amber-500 ring-2 ring-amber-400/20 shadow-xs'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <p className={`text-xs font-bold leading-tight ${isSelected ? 'text-amber-950' : 'text-slate-800'}`}>
                      {srv.name}
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1 font-medium">
                      Rp{srv.base_price.toLocaleString('id-ID')}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Service Price Banner */}
          {activeService && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-500 block text-[11px]">Harga Dasar Layanan:</span>
                <span className="font-extrabold text-slate-900 text-sm">
                  {activeService.name} • Rp{activeService.base_price.toLocaleString('id-ID')}
                </span>
              </div>
              <span className="text-[11px] text-slate-500 bg-white px-2 py-1 rounded-md border border-slate-200">
                {activeService.unit_label}
              </span>
            </div>
          )}

          {/* 2. Upload File (Supabase Storage Private) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
              2. Upload Berkas / Materi Tugas (Opsional)
            </label>
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-4 text-center cursor-pointer transition-colors ${
                isDragging
                  ? 'border-amber-500 bg-amber-50/50'
                  : file
                  ? 'border-emerald-400 bg-emerald-50/30'
                  : 'border-slate-300 hover:border-amber-400 bg-slate-50/50'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={handleFileChange}
              />

              {file ? (
                <div className="flex items-center justify-between p-2 bg-emerald-50 rounded-xl border border-emerald-200">
                  <div className="flex items-center gap-2 text-emerald-900 text-xs font-semibold truncate">
                    <FileCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                    <span className="truncate">{file.name}</span>
                    <span className="text-emerald-700 font-normal text-[10px] shrink-0">
                      ({(file.size / 1024).toFixed(0)} KB)
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0 ml-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        fileInputRef.current?.click();
                      }}
                      className="px-2 py-1 text-[10px] font-bold text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
                    >
                      Ganti
                    </button>
                    <button
                      type="button"
                      onClick={handleRemoveFile}
                      className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg"
                      title="Hapus berkas"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-1">
                  <UploadCloud className="w-6 h-6 text-slate-400 mx-auto" />
                  <p className="text-xs font-bold text-slate-700">
                    Klik untuk pilih berkas atau seret & lepas ke sini
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Mendukung DOCX, PDF, XLSX, PPTX, MP4, ZIP, PNG, dll. Disimpan aman.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* 3. Instruksi / Detail Pekerjaan */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
              3. Tulis Instruksi & Catatan Pengerjaan
            </label>
            <textarea
              rows={3}
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder="Contoh: Tolong buatkan PPT 10 slide materi bab 3. Warna dominan biru laut, tambahkan visual diagram rapi..."
              className="w-full text-xs sm:text-sm p-3 rounded-xl border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-400/20 outline-none transition-all resize-none"
            />
          </div>

          {/* 4. Tentukan Deadline */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
              4. Tentukan Deadline
            </label>
            <div className="grid grid-cols-2 gap-2">
              <div className="relative">
                <input
                  type="date"
                  value={deadlineDate}
                  onChange={(e) => setDeadlineDate(e.target.value)}
                  className="w-full p-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-400/20 outline-none"
                />
              </div>
              <div className="relative">
                <input
                  type="time"
                  value={deadlineTime}
                  onChange={(e) => setDeadlineTime(e.target.value)}
                  className="w-full p-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-400/20 outline-none"
                />
              </div>
            </div>
          </div>

          {/* 5. Tombol "Ajukan Negosiasi Harga" */}
          <div className="pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center text-amber-800">
                  <Percent className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">Ajukan Negosiasi Harga</p>
                  <p className="text-[11px] text-slate-500">
                    Sesuaikan harga dengan beban tugasmu
                  </p>
                </div>
              </div>
              <button
                type="button"
                id="toggle-negotiation-btn"
                onClick={() => setNegotiationRequested(!negotiationRequested)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  negotiationRequested ? 'bg-amber-500' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    negotiationRequested ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {negotiationRequested && (
              <div className="mt-3 p-3.5 bg-amber-50/60 border border-amber-200 rounded-2xl space-y-3 animate-in fade-in duration-150">
                <div>
                  <label className="block text-[11px] font-bold text-amber-950 mb-1">
                    Harga yang Kamu Ajukan (Rp)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">Rp</span>
                    <input
                      type="number"
                      step="1000"
                      value={negotiationPrice}
                      onChange={(e) => setNegotiationPrice(e.target.value === '' ? '' : Number(e.target.value))}
                      placeholder="Contoh: 18000"
                      className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white rounded-xl border border-amber-300 focus:border-amber-500 outline-none font-bold text-slate-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-amber-950 mb-1">
                    Alasan / Detail Negosiasi
                  </label>
                  <textarea
                    rows={2}
                    value={negotiationReason}
                    onChange={(e) => setNegotiationReason(e.target.value)}
                    placeholder="Contoh: Tugasnya hanya merapikan 5 halaman singkat kak..."
                    className="w-full text-xs p-2.5 bg-white rounded-xl border border-amber-300 focus:border-amber-500 outline-none resize-none text-slate-800"
                  />
                </div>
                <p className="text-[10px] text-amber-800 leading-tight">
                  *Admin akan meninjau tawaranmu. Admin dapat menerima harga ini atau menetapkan harga penyesuaian.
                </p>
              </div>
            )}
          </div>

          {/* 6. Simulasi Perhitungan Voucher & Pembayaran */}
          <div className="p-3.5 rounded-2xl bg-slate-900 text-white space-y-2">
            <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <span className="text-slate-400">Saldo Vouchermu Saat Ini</span>
              <span className="font-bold text-amber-400">
                Rp{userVoucherBalance.toLocaleString('id-ID')}
              </span>
            </div>

            <div className="space-y-1 text-xs pt-1">
              <div className="flex justify-between text-slate-300">
                <span>Harga Layanan {negotiationRequested ? '(Diajukan)' : '(Dasar)'}:</span>
                <span className="font-semibold text-white">Rp{effectiveBasePrice.toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between text-emerald-400">
                <span>Potongan Saldo Voucher:</span>
                <span className="font-bold">-Rp{estimatedVoucherDeduction.toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-slate-800 text-sm">
                <span className="font-bold text-slate-200">Estimasi Yang Harus Dibayar:</span>
                <span className={`font-black text-base ${estimatedAmountToPay === 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {estimatedAmountToPay === 0 ? 'Rp0 (GRATIS)' : `Rp${estimatedAmountToPay.toLocaleString('id-ID')}`}
                </span>
              </div>
            </div>

            <p className="text-[10px] text-slate-400 pt-1 leading-normal">
              {estimatedAmountToPay === 0 
                ? `*Pesanan akan langsung diproses tanpa bayar tambahan. Sisa voucher Rp${estimatedRemainingVoucher.toLocaleString('id-ID')} tetap tersimpan.`
                : `*Jika harga final disetujui, bayar selisih Rp${estimatedAmountToPay.toLocaleString('id-ID')} via QRIS.`
              }
            </p>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-100 bg-white flex items-center justify-between gap-3 pb-6 sm:pb-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-3 min-h-[48px] text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-900 rounded-2xl active:bg-slate-100 transition-colors"
          >
            Batal
          </button>
          <button
            id="submit-order-btn"
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="flex-1 py-3.5 min-h-[48px] bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-black rounded-2xl text-xs sm:text-sm shadow-md active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <span>{isSubmitting ? 'Menyimpan Berkas & Pesanan...' : 'Kirim Pesanan Sekarang'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};

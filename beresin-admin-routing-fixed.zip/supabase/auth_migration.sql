-- BERESIN AUTH MIGRATION
-- Run this once in Supabase SQL Editor.
-- This makes auth.users the source of truth for authentication and creates
-- public.profiles automatically for every new Auth user.

CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_full_name TEXT;
  v_whatsapp TEXT;
  v_voucher_code TEXT;
BEGIN
  v_full_name := COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data ->> 'full_name'), ''), 'Mahasiswa BERESIN');
  v_whatsapp := COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data ->> 'whatsapp'), ''), '');
  v_voucher_code := NULLIF(TRIM(NEW.raw_user_meta_data ->> 'voucher_code'), '');

  INSERT INTO public.profiles (
    id, email, full_name, whatsapp, role, voucher_balance, voucher_code_used,
    created_at, updated_at
  ) VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    v_full_name,
    v_whatsapp,
    'STUDENT'::user_role,
    0,
    NULL,
    COALESCE(NEW.created_at, NOW()),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = EXCLUDED.full_name,
    whatsapp = EXCLUDED.whatsapp,
    updated_at = NOW();

  -- Optional voucher: the database function validates the code before crediting it.
  IF v_voucher_code IS NOT NULL THEN
    PERFORM public.redeem_voucher_code(v_voucher_code, NEW.id, COALESCE(NEW.email, ''));
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.handle_new_auth_user();

ALTER FUNCTION public.redeem_voucher_code(TEXT, UUID, TEXT) SET search_path = public;
ALTER FUNCTION public.apply_voucher_and_finalize_price(UUID, NUMERIC) SET search_path = public;
ALTER FUNCTION public.is_admin() SET search_path = public;

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profile INSERT is intentionally not granted to anon/authenticated clients.
-- The SECURITY DEFINER trigger above creates profiles safely using NEW.id.
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;

-- Make the existing profile policies idempotent and explicit.
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
CREATE POLICY "Users can view own profile"
ON public.profiles FOR SELECT
USING (auth.uid() = id OR public.is_admin());

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile"
ON public.profiles FOR UPDATE
USING (auth.uid() = id OR public.is_admin())
WITH CHECK (auth.uid() = id OR public.is_admin());

-- IMPORTANT:
-- Existing rows in public.profiles are not deleted or modified by this migration.
-- They remain intact. New accounts created through supabase.auth.signUp() will
-- always receive a matching profile UUID through the trigger.

-- -------------------------------------------------------------------------
-- BERESIN MASTER ADMIN ACCOUNT POLICY
-- The only account allowed to have ADMIN role is the designated master admin.
-- IMPORTANT: This does not store or create a password. Supabase Auth remains
-- the only password store. Create the Auth user once via Supabase Dashboard
-- or the provided admin bootstrap script, then this migration promotes it.
-- -------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.enforce_single_master_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.role = 'ADMIN'::user_role THEN
    IF lower(COALESCE(NEW.email, '')) <> 'mdqputra@gmail.com' THEN
      RAISE EXCEPTION 'Only the designated BERESIN master admin can have ADMIN role';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS enforce_single_master_admin ON public.profiles;
CREATE TRIGGER enforce_single_master_admin
BEFORE INSERT OR UPDATE OF role, email ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.enforce_single_master_admin();

-- Promote the designated Auth account if it already exists, and demote any
-- other ADMIN profile. Existing user data is preserved.
UPDATE public.profiles
SET role = CASE
  WHEN lower(email) = 'mdqputra@gmail.com' THEN 'ADMIN'::user_role
  ELSE 'STUDENT'::user_role
END,
updated_at = NOW();

-- Keep the Auth trigger aligned with the single-admin policy.
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_full_name TEXT;
  v_whatsapp TEXT;
  v_voucher_code TEXT;
  v_role user_role;
BEGIN
  v_full_name := COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data ->> 'full_name'), ''), 'Mahasiswa BERESIN');
  v_whatsapp := COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data ->> 'whatsapp'), ''), '');
  v_voucher_code := NULLIF(TRIM(NEW.raw_user_meta_data ->> 'voucher_code'), '');
  v_role := CASE
    WHEN lower(COALESCE(NEW.email, '')) = 'mdqputra@gmail.com' THEN 'ADMIN'::user_role
    ELSE 'STUDENT'::user_role
  END;

  INSERT INTO public.profiles (
    id, email, full_name, whatsapp, role, voucher_balance, voucher_code_used,
    created_at, updated_at
  ) VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    v_full_name,
    v_whatsapp,
    v_role,
    0,
    NULL,
    COALESCE(NEW.created_at, NOW()),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = EXCLUDED.full_name,
    whatsapp = EXCLUDED.whatsapp,
    role = EXCLUDED.role,
    updated_at = NOW();

  IF v_voucher_code IS NOT NULL AND v_role = 'STUDENT'::user_role THEN
    PERFORM public.redeem_voucher_code(v_voucher_code, NEW.id, COALESCE(NEW.email, ''));
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.handle_new_auth_user();

-- Existing Auth users created before this migration must also be promoted.
-- The profile UUID must match auth.users.id.
INSERT INTO public.profiles (id, email, full_name, whatsapp, role, voucher_balance, voucher_code_used, created_at, updated_at)
SELECT
  u.id,
  COALESCE(u.email, ''),
  COALESCE(NULLIF(TRIM(u.raw_user_meta_data ->> 'full_name'), ''), 'Admin Utama BERESIN'),
  COALESCE(NULLIF(TRIM(u.raw_user_meta_data ->> 'whatsapp'), ''), ''),
  'ADMIN'::user_role,
  0,
  NULL,
  COALESCE(u.created_at, NOW()),
  NOW()
FROM auth.users u
WHERE lower(COALESCE(u.email, '')) = 'mdqputra@gmail.com'
ON CONFLICT (id) DO UPDATE SET
  email = EXCLUDED.email,
  role = 'ADMIN'::user_role,
  updated_at = NOW();

-- If the designated Auth user exists, make sure its profile is ADMIN.
UPDATE public.profiles p
SET role = 'ADMIN'::user_role, updated_at = NOW()
FROM auth.users u
WHERE p.id = u.id
  AND lower(u.email) = 'mdqputra@gmail.com';


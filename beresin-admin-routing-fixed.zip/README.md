<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/2918a13b-b4d4-4e18-adbe-a239b7312636

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Master Admin BERESIN

The designated and only ADMIN account is `mdqputra@gmail.com`. Passwords are never stored by the application.

1. Run `supabase/auth_migration.sql` in Supabase SQL Editor.
2. If the Auth user does not already exist, create it with `scripts/create-master-admin.mjs` using a Supabase service-role key supplied only through an environment variable. The script prompts for the password and does not write it to source or storage.
3. After creation, the database migration/trigger assigns ADMIN only to `mdqputra@gmail.com` and demotes any other profile to STUDENT.

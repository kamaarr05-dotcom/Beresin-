import { createClient } from '@supabase/supabase-js';
import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';

const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const email = 'mdqputra@gmail.com';

if (!url || !serviceRoleKey) {
  console.error('Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY first.');
  process.exit(1);
}

const rl = readline.createInterface({ input, output });
const password = await rl.question('Password admin (input is not stored): ', { hideEchoBack: true });
rl.close();

if (!password || password.length < 6) {
  console.error('Password minimal 6 karakter.');
  process.exit(1);
}

const supabase = createClient(url, serviceRoleKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});

const { data: listed, error: listError } = await supabase.auth.admin.listUsers({ perPage: 1000 });
if (listError) throw listError;

const existing = listed.users.find((u) => u.email?.toLowerCase() === email);
let authUser;

if (existing) {
  const { data, error } = await supabase.auth.admin.updateUserById(existing.id, {
    password,
    user_metadata: {
      ...existing.user_metadata,
      full_name: 'Admin Utama BERESIN',
      whatsapp: existing.user_metadata?.whatsapp || '',
    },
  });
  if (error) throw error;
  authUser = data.user;
} else {
  const { data, error } = await supabase.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: {
      full_name: 'Admin Utama BERESIN',
      whatsapp: '',
    },
  });
  if (error) throw error;
  authUser = data.user;
}

const { error: roleError } = await supabase
  .from('profiles')
  .update({ role: 'ADMIN', full_name: 'Admin Utama BERESIN' })
  .eq('id', authUser.id);
if (roleError) throw roleError;

const { error: demoteError } = await supabase
  .from('profiles')
  .update({ role: 'STUDENT' })
  .eq('role', 'ADMIN')
  .neq('id', authUser.id);
if (demoteError) throw demoteError;

console.log(`Master admin ready: ${email}`);
console.log(`Auth UUID: ${authUser.id}`);

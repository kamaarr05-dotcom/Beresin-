import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  CheckCircle2, 
  Ticket, 
  User, 
  LogOut, 
  ShieldAlert, 
  Database, 
  Menu, 
  X,
  FileSpreadsheet,
  Layers
} from 'lucide-react';

interface HeaderProps {
  onOpenAuth: (mode: 'login' | 'register') => void;
  onOpenOrderModal: () => void;
  onOpenSupabaseModal: () => void;
  activeView: 'home' | 'student-orders' | 'admin-panel';
  setActiveView: (view: 'home' | 'student-orders' | 'admin-panel') => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenAuth,
  onOpenOrderModal,
  onOpenSupabaseModal,
  activeView,
  setActiveView,
}) => {
  const { currentUser, role, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 sm:h-18">
          
          {/* Brand Logo & Tagline */}
          <div 
            id="brand-logo"
            onClick={() => setActiveView('home')}
            className="flex items-center gap-2.5 cursor-pointer select-none group"
          >
            <div className="w-9 h-9 rounded-xl bg-slate-900 flex items-center justify-center text-amber-400 font-extrabold text-xl shadow-md shadow-slate-900/10 group-hover:bg-slate-800 transition-colors">
              B
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-extrabold tracking-tight text-slate-900 font-display">
                  BERESIN
                </span>
                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                  PRO
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium hidden xs:block line-clamp-1">
                Kirim pekerjaanmu. Kami yang bereskan.
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 text-sm font-semibold">
            <button
              id="nav-home-btn"
              onClick={() => setActiveView('home')}
              className={`px-3.5 py-2 rounded-lg transition-colors ${
                activeView === 'home'
                  ? 'bg-slate-100 text-slate-950 font-bold'
                  : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
              }`}
            >
              Beranda & Layanan
            </button>

            {currentUser?.role === 'STUDENT' && (
              <button
                id="nav-student-orders-btn"
                onClick={() => setActiveView('student-orders')}
                className={`px-3.5 py-2 rounded-lg transition-colors flex items-center gap-1.5 ${
                  activeView === 'student-orders'
                    ? 'bg-slate-100 text-slate-950 font-bold'
                    : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
                }`}
              >
                <Layers className="w-4 h-4 text-amber-600" />
                Pesanan Saya
              </button>
            )}

            {currentUser?.role === 'ADMIN' && (
              <button
                id="nav-admin-panel-btn"
                onClick={() => setActiveView('admin-panel')}
                className={`px-3.5 py-2 rounded-lg transition-colors flex items-center gap-1.5 ${
                  activeView === 'admin-panel'
                    ? 'bg-amber-100 text-amber-900 font-bold border border-amber-300'
                    : 'text-amber-800 bg-amber-50 hover:bg-amber-100'
                }`}
              >
                <ShieldAlert className="w-4 h-4 text-amber-600" />
                Dashboard Admin
              </button>
            )}

            <button
              id="nav-supabase-status-btn"
              onClick={onOpenSupabaseModal}
              title="Lihat konfigurasi Supabase & Database SQL"
              className="px-2.5 py-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-50 flex items-center gap-1 text-xs"
            >
              <Database className="w-3.5 h-3.5 text-emerald-600" />
              <span>Supabase DB</span>
            </button>
          </nav>

          {/* User Account / Action Buttons */}
          <div className="hidden sm:flex items-center gap-2.5">
            {currentUser ? (
              <div className="flex items-center gap-2">
                {/* Voucher pill for students */}
                {currentUser.role === 'STUDENT' && (
                  <div 
                    id="user-voucher-pill"
                    onClick={() => setActiveView('student-orders')}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 border border-amber-300 rounded-full text-xs font-bold text-amber-900 cursor-pointer hover:bg-amber-100 transition-colors shadow-xs"
                    title="Klik untuk melihat detail voucher"
                  >
                    <Ticket className="w-3.5 h-3.5 text-amber-600" />
                    <span>Voucher: Rp{currentUser.voucher_balance.toLocaleString('id-ID')}</span>
                  </div>
                )}

                {/* Primary CTA */}
                {currentUser.role === 'STUDENT' ? (
                  <button
                    id="header-create-order-btn"
                    onClick={onOpenOrderModal}
                    className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs sm:text-sm font-bold hover:bg-slate-800 shadow-sm transition-all"
                  >
                    + Buat Pesanan
                  </button>
                ) : (
                  <button
                    id="header-admin-quick-btn"
                    onClick={() => setActiveView('admin-panel')}
                    className="px-4 py-2 bg-amber-500 text-slate-950 rounded-xl text-xs sm:text-sm font-bold hover:bg-amber-400 shadow-sm transition-all"
                  >
                    Kelola Pesanan
                  </button>
                )}

                {/* Logout Button */}
                <button
                  id="header-logout-btn"
                  onClick={logout}
                  title="Keluar"
                  className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  id="header-login-btn"
                  onClick={() => onOpenAuth('login')}
                  className="px-3.5 py-1.5 text-sm font-semibold text-slate-700 hover:text-slate-950 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Masuk
                </button>
                <button
                  id="header-register-btn"
                  onClick={() => onOpenAuth('register')}
                  className="px-4 py-2 text-sm font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl shadow-xs transition-all flex items-center gap-1.5"
                >
                  <User className="w-4 h-4 text-slate-950" />
                  <span>Daftar Akun</span>
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu toggle button */}
          <div className="flex items-center gap-1.5 sm:hidden">
            {currentUser?.role === 'STUDENT' && (
              <div 
                onClick={() => setActiveView('student-orders')}
                className="flex items-center gap-1 px-2.5 py-1 bg-amber-100 text-amber-900 rounded-full text-[11px] font-extrabold border border-amber-300"
              >
                <Ticket className="w-3 h-3 text-amber-700" />
                <span>Rp{currentUser.voucher_balance.toLocaleString('id-ID')}</span>
              </div>
            )}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="sm:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-5 space-y-3 animate-in slide-in-from-top duration-150">
          {currentUser ? (
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-medium">Masuk sebagai:</p>
                  <p className="text-sm font-bold text-slate-900">{currentUser.full_name}</p>
                  <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full mt-0.5 ${
                    currentUser.role === 'ADMIN' ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
                  }`}>
                    {currentUser.role === 'ADMIN' ? 'Admin Pengerja' : 'Siswa / Mahasiswa'}
                  </span>
                </div>
                {currentUser.role === 'STUDENT' && (
                  <div className="text-right">
                    <p className="text-[10px] text-slate-500">Saldo Voucher</p>
                    <p className="text-sm font-black text-amber-700">Rp{currentUser.voucher_balance.toLocaleString('id-ID')}</p>
                  </div>
                )}
              </div>
            </div>
          ) : null}

          <div className="grid grid-cols-1 gap-1 text-sm font-medium">
            <button
              onClick={() => {
                setActiveView('home');
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2.5 rounded-lg ${
                activeView === 'home' ? 'bg-slate-100 font-bold text-slate-950' : 'text-slate-700'
              }`}
            >
              Beranda & Layanan
            </button>
            {currentUser?.role === 'STUDENT' && (
              <button
                onClick={() => {
                  setActiveView('student-orders');
                  setMobileMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center justify-between ${
                  activeView === 'student-orders' ? 'bg-slate-100 font-bold text-slate-950' : 'text-slate-700'
                }`}
              >
                <span>Pesanan Saya</span>
                <span className="text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-bold">
                  Rp{currentUser.voucher_balance.toLocaleString('id-ID')}
                </span>
              </button>
            )}
            {currentUser?.role === 'ADMIN' && (
              <button
                onClick={() => {
                  setActiveView('admin-panel');
                  setMobileMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-2.5 rounded-lg flex items-center gap-2 ${
                  activeView === 'admin-panel' ? 'bg-amber-100 font-bold text-amber-950' : 'text-amber-900 bg-amber-50'
                }`}
              >
                <ShieldAlert className="w-4 h-4 text-amber-600" />
                <span>Dashboard Admin</span>
              </button>
            )}
            <button
              onClick={() => {
                onOpenSupabaseModal();
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2.5 rounded-lg text-slate-600 flex items-center gap-2 text-xs"
            >
              <Database className="w-3.5 h-3.5 text-emerald-600" />
              <span>Supabase Status & SQL Schema</span>
            </button>
          </div>

          <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
            {currentUser ? (
              <>
                {currentUser.role === 'STUDENT' && (
                  <button
                    onClick={() => {
                      onOpenOrderModal();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full py-2.5 bg-slate-900 text-white rounded-xl text-sm font-bold shadow-sm"
                  >
                    + Buat Pesanan Baru
                  </button>
                )}
                <button
                  onClick={() => {
                    logout();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2 text-center text-sm font-semibold text-rose-600 hover:bg-rose-50 rounded-xl"
                >
                  Keluar dari Akun
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    onOpenAuth('login');
                    setMobileMenuOpen(false);
                  }}
                  className="py-2.5 text-center text-sm font-semibold bg-slate-100 text-slate-800 rounded-xl"
                >
                  Masuk
                </button>
                <button
                  onClick={() => {
                    onOpenAuth('register');
                    setMobileMenuOpen(false);
                  }}
                  className="py-2.5 text-center text-sm font-bold bg-amber-400 text-slate-950 rounded-xl"
                >
                  Daftar Promo
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

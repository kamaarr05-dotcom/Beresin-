import React, { useState, useEffect } from 'react';
import { OrderItem, AdminPaymentConfig } from '../types';
import { BeresinDataStore } from '../lib/supabase';
import { BeresinStorage } from '../lib/fileStorage';
import { 
  QrCode, 
  X, 
  CheckCircle2, 
  UploadCloud, 
  Copy, 
  Check, 
  ShieldCheck,
  CreditCard,
  MessageSquare
} from 'lucide-react';

interface QRISPaymentModalProps {
  isOpen: boolean;
  order: OrderItem | null;
  onClose: () => void;
  onSuccess: () => void;
}

export const QRISPaymentModal: React.FC<QRISPaymentModalProps> = ({
  isOpen,
  order,
  onClose,
  onSuccess,
}) => {
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [copiedBank, setCopiedBank] = useState(false);
  const [paymentConfig, setPaymentConfig] = useState<AdminPaymentConfig>(() => BeresinDataStore.getPaymentConfig());

  useEffect(() => {
    if (isOpen) {
      setPaymentConfig(BeresinDataStore.getPaymentConfig());
    }
  }, [isOpen]);

  if (!isOpen || !order) return null;

  const handleCopyBank = () => {
    navigator.clipboard.writeText(paymentConfig.bank_account_number);
    setCopiedBank(true);
    setTimeout(() => setCopiedBank(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!proofFile) return;
    setIsSubmitting(true);

    try {
      const uploaded = await BeresinStorage.uploadFile(proofFile);
      // Submit payment proof to DataStore
      BeresinDataStore.submitPaymentProof(
        order.id,
        uploaded.fileName,
        uploaded.fileUrl
      );

      setIsSubmitting(false);
      setSuccessMsg('Bukti pembayaran berhasil dikirim! Admin akan segera memverifikasi.');
      setTimeout(() => {
        onSuccess();
        onClose();
        setSuccessMsg('');
        setProofFile(null);
      }, 1500);
    } catch (err) {
      console.error(err);
      setIsSubmitting(false);
      alert('Gagal mengunggah bukti pembayaran. Silakan coba kembali.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in slide-in-from-bottom sm:zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Drag handle */}
        <div className="pt-2.5 pb-1 sm:hidden flex justify-center">
          <div className="w-12 h-1.5 bg-slate-300 rounded-full" />
        </div>

        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-white">
          <div>
            <h3 className="text-base font-black text-slate-900 flex items-center gap-1.5">
              <QrCode className="w-4 h-4 text-orange-500" />
              <span>Pembayaran QRIS / Transfer</span>
            </h3>
            <p className="text-[11px] text-slate-500">
              Pesanan #{order.order_number} • {order.service_name}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full active:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {successMsg ? (
            <div className="p-6 text-center space-y-2 bg-emerald-50 rounded-2xl border border-emerald-200">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
              <p className="text-sm font-bold text-emerald-950">{successMsg}</p>
              <p className="text-xs text-emerald-700">Status pesanan akan segera berubah ke ANTRIAN.</p>
            </div>
          ) : (
            <>
              {/* Total Selisih Harus Dibayar */}
              <div className="p-4 bg-orange-50/80 rounded-2xl border border-orange-200 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-orange-900 font-semibold block">
                    Total Bayar Selisih:
                  </span>
                  <span className="text-xl font-black text-orange-600">
                    Rp{order.amount_to_pay.toLocaleString('id-ID')}
                  </span>
                </div>
                <span className="text-[10px] font-bold px-2 py-1 bg-white rounded-lg border border-orange-200 text-orange-950">
                  Potongan Voucher: Rp{order.voucher_deduction.toLocaleString('id-ID')}
                </span>
              </div>

              {/* QRIS Code Box */}
              <div className="border border-slate-200 rounded-2xl p-4 text-center space-y-2.5 bg-slate-50">
                <div className="w-48 h-48 bg-white border-2 border-slate-900 rounded-2xl mx-auto p-2 flex flex-col items-center justify-center shadow-xs">
                  <div className="w-full h-full border border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center p-2 bg-slate-950 text-white text-center font-mono">
                    <QrCode className="w-20 h-20 text-white mb-1" />
                    <span className="font-extrabold text-xs text-amber-400 truncate max-w-[150px]">
                      {paymentConfig.qris_merchant_name || 'QRIS BERESIN'}
                    </span>
                    <span className="text-[9px] text-slate-300">
                      NMID: {paymentConfig.qris_nmid || 'ID1020304050'}
                    </span>
                  </div>
                </div>
                <p className="text-xs font-bold text-slate-800">
                  Scan via GoPay, OVO, Dana, ShopeePay, BCA, Livin Mandiri
                </p>

                {/* Bank Card / Rekening Admin */}
                <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1.5 text-left">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 font-bold text-slate-900">
                      <CreditCard className="w-4 h-4 text-amber-600" />
                      <span>{paymentConfig.bank_name || 'Transfer Bank'}</span>
                    </div>
                    <button
                      type="button"
                      onClick={handleCopyBank}
                      className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors"
                    >
                      {copiedBank ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedBank ? 'Tersalin' : 'Salin Rekening'}</span>
                    </button>
                  </div>
                  <div className="flex items-baseline justify-between pt-0.5">
                    <span className="font-mono font-black text-sm text-slate-900 tracking-wider">
                      {paymentConfig.bank_account_number}
                    </span>
                    <span className="text-[11px] text-slate-500 font-semibold truncate max-w-[150px]">
                      a.n. {paymentConfig.bank_account_holder}
                    </span>
                  </div>
                </div>

                {/* WhatsApp Help / Konfirmasi langsung */}
                <div className="pt-1 flex items-center justify-center">
                  <a
                    href={BeresinDataStore.getWhatsAppLink(`Halo Admin, saya ingin konfirmasi pembayaran untuk pesanan #${order.order_number} (${order.service_name}) sebesar Rp${order.amount_to_pay.toLocaleString('id-ID')}`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] text-emerald-700 font-bold hover:underline flex items-center gap-1"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Konfirmasi via WhatsApp Admin</span>
                  </a>
                </div>
              </div>

              {/* Upload Proof */}
              <form onSubmit={handleSubmit} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Upload Bukti Transfer (Screenshot)
                  </label>
                  <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-300 hover:border-amber-400 rounded-2xl cursor-pointer bg-slate-50/50">
                    <input
                      type="file"
                      accept="image/*"
                      required
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          setProofFile(e.target.files[0]);
                        }
                      }}
                    />
                    {proofFile ? (
                      <span className="text-xs font-bold text-emerald-700">
                        ✓ {proofFile.name} ({(proofFile.size / 1024).toFixed(0)} KB)
                      </span>
                    ) : (
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
                        <UploadCloud className="w-4 h-4 text-slate-400" />
                        <span>Pilih Foto Bukti Transfer</span>
                      </div>
                    )}
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting || !proofFile}
                  className="w-full py-3.5 min-h-[48px] bg-slate-950 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-black rounded-2xl transition-all shadow-md active:scale-98"
                >
                  {isSubmitting ? 'Mengirim...' : 'Kirim Bukti Pembayaran ke Admin'}
                </button>
              </form>
            </>
          )}
        </div>

      </div>
    </div>
  );
};

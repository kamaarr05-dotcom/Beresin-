import React from 'react';
import { ServiceItem, OrderItem } from '../types';
import { useAuth } from '../context/AuthContext';
import { 
  Sparkles, 
  ArrowRight, 
  Clock, 
  ShieldCheck, 
  FileText, 
  Table, 
  FileCode, 
  FileCheck, 
  Video, 
  Palette, 
  Headphones, 
  Database,
  CheckCircle2,
  Ticket,
  Layers,
  AlertCircle,
  Presentation,
  Sheet,
  FileSearch,
  Film,
  Smartphone,
  Globe,
  Wrench
} from 'lucide-react';

interface MobileHomeViewProps {
  services: ServiceItem[];
  orders?: OrderItem[];
  onSelectService: (service: ServiceItem) => void;
  onOpenOrderModal: () => void;
  onOpenVoucherTab: () => void;
  onOpenOrdersTab?: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
}

export const MobileHomeView: React.FC<MobileHomeViewProps> = ({
  services,
  orders = [],
  onSelectService,
  onOpenOrderModal,
  onOpenVoucherTab,
  onOpenOrdersTab,
  onOpenAuth,
}) => {
  const { currentUser, role } = useAuth();

  const getServiceIcon = (iconName?: string) => {
    switch (iconName) {
      case 'Presentation': return <Presentation className="w-5 h-5 text-amber-600" />;
      case 'Sheet':
      case 'Table': return <Sheet className="w-5 h-5 text-emerald-600" />;
      case 'FileText': return <FileText className="w-5 h-5 text-blue-600" />;
      case 'FileSearch':
      case 'FileCheck': return <FileSearch className="w-5 h-5 text-rose-600" />;
      case 'Film':
      case 'Video': return <Film className="w-5 h-5 text-purple-600" />;
      case 'Palette': return <Palette className="w-5 h-5 text-pink-600" />;
      case 'Headphones': return <Headphones className="w-5 h-5 text-indigo-600" />;
      case 'Database': return <Database className="w-5 h-5 text-cyan-600" />;
      case 'Smartphone': return <Smartphone className="w-5 h-5 text-violet-600" />;
      case 'Globe': return <Globe className="w-5 h-5 text-sky-600" />;
      case 'Wrench': return <Wrench className="w-5 h-5 text-amber-700" />;
      default: return <FileText className="w-5 h-5 text-slate-600" />;
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-150">
      
      {/* GREETING CARD */}
      <div className="flex items-center justify-between px-1">
        <div>
          <div className="flex items-center gap-1.5">
            <h2 className="text-lg font-black text-slate-900 tracking-tight">
              {currentUser ? `Halo, ${currentUser.full_name.split(' ')[0]} 👋` : 'Halo, Selamat Datang!'}
            </h2>
            {role === 'ADMIN' && (
              <span className="px-1.5 py-0.2 bg-amber-400 text-slate-950 font-black text-[9px] rounded uppercase">
                ADMIN
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 font-medium">
            {role === 'ADMIN' ? 'Panel Operasional & Pengerjaan Tugas Siswa' : 'Kirim pekerjaanmu. Kami yang bereskan.'}
          </p>
        </div>
        {currentUser && (
          <button
            onClick={onOpenVoucherTab}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-950 rounded-2xl text-xs font-black border border-amber-300 active:scale-95 transition-transform"
          >
            <Ticket className="w-3.5 h-3.5 text-amber-700" />
            <span>Rp{(currentUser.voucher_balance / 1000).toFixed(0)}k</span>
          </button>
        )}
      </div>

      {/* ADMIN STATUS SUMMARY CARD */}
      {role === 'ADMIN' && (
        <div className="bg-slate-900 text-white rounded-3xl p-5 shadow-lg border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              <span className="text-[11px] font-black uppercase tracking-wider text-amber-400">
                Ringkasan Pesanan Siswa
              </span>
            </div>
            {onOpenOrdersTab && (
              <button
                onClick={onOpenOrdersTab}
                className="text-xs font-bold text-amber-300 hover:text-amber-200 flex items-center gap-1"
              >
                <span>Kelola Semua</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1">
            <button
              onClick={onOpenOrdersTab}
              className="bg-slate-800/80 hover:bg-slate-800 rounded-2xl p-2.5 text-center border border-slate-700/60 transition-colors"
            >
              <p className="text-lg font-black text-amber-400">
                {orders.filter(o => o.status === 'MENUNGGU_HARGA' || o.status === 'MENUNGGU_PEMBAYARAN' || o.status === 'REVISI').length}
              </p>
              <p className="text-[10px] text-slate-300 font-semibold leading-tight mt-0.5">Perlu Tindakan</p>
            </button>
            <button
              onClick={onOpenOrdersTab}
              className="bg-slate-800/80 hover:bg-slate-800 rounded-2xl p-2.5 text-center border border-slate-700/60 transition-colors"
            >
              <p className="text-lg font-black text-sky-400">
                {orders.filter(o => o.status === 'ANTRIAN' || o.status === 'DIKERJAKAN').length}
              </p>
              <p className="text-[10px] text-slate-300 font-semibold leading-tight mt-0.5">Dikerjakan</p>
            </button>
            <button
              onClick={onOpenOrdersTab}
              className="bg-slate-800/80 hover:bg-slate-800 rounded-2xl p-2.5 text-center border border-slate-700/60 transition-colors"
            >
              <p className="text-lg font-black text-emerald-400">
                {orders.filter(o => o.status === 'SELESAI').length}
              </p>
              <p className="text-[10px] text-slate-300 font-semibold leading-tight mt-0.5">Selesai</p>
            </button>
          </div>
        </div>
      )}

      {/* PROMO CARD: Bayar Rp10.000 -> Voucher Rp30.000 */}
      <div className="relative overflow-hidden bg-gradient-to-br from-amber-400 via-amber-400 to-amber-500 text-slate-950 rounded-3xl p-5 shadow-lg border border-amber-300">
        
        {/* Subtle badge */}
        <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-950 text-amber-300 text-[10px] font-black uppercase tracking-wider mb-2">
          <Sparkles className="w-3 h-3 text-amber-300" />
          <span>PROMO SPESIAL MAHASISWA & SISWA</span>
        </div>

        <h3 className="text-xl sm:text-2xl font-black leading-tight tracking-tight">
          Bayar Rp10.000 <br />
          <span className="text-white drop-shadow-xs">🎉 Dapat Voucher Jasa Rp30.000</span>
        </h3>
        <p className="text-xs text-slate-900/90 font-medium mt-1.5 leading-relaxed">
          Gunakan untuk memotong biaya segala jenis tugas (PPT, Excel, Word, Video, dll). Bayar selisihnya atau Rp0 jika biaya di bawah Rp30.000!
        </p>

        <div className="pt-3.5 flex items-center gap-2">
          <button
            onClick={() => {
              if (!currentUser) {
                onOpenAuth('register');
              } else {
                onOpenVoucherTab();
              }
            }}
            className="flex-1 py-3 bg-slate-950 hover:bg-slate-800 text-white rounded-2xl text-xs font-black shadow-md flex items-center justify-center gap-1.5 active:scale-98 transition-all"
          >
            <span>{currentUser ? 'Lihat Dompet Voucher' : 'Daftar & Klaim Rp30.000'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onOpenOrderModal}
            className="px-4 py-3 bg-white/90 hover:bg-white text-slate-900 rounded-2xl text-xs font-bold shadow-xs active:scale-98 transition-all"
          >
            Pesan
          </button>
        </div>
      </div>

      {/* QUICK SERVICES SECTION */}
      <div className="space-y-2.5 pt-1">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="text-sm font-black text-slate-900 tracking-tight">
              Pilih Layanan & Lihat Harga
            </h3>
            <p className="text-[11px] text-slate-500">
              Harga transparan, bisa ajukan negosiasi harga
            </p>
          </div>
          <button
            onClick={onOpenOrderModal}
            className="text-xs font-bold text-amber-700 hover:text-amber-800"
          >
            Pesan Cepat →
          </button>
        </div>

        {/* 2-Column Mobile Grid for easy thumb tapping */}
        <div className="grid grid-cols-2 gap-2.5">
          {services.map((service) => (
            <div
              key={service.id}
              onClick={() => onSelectService(service)}
              className="bg-white rounded-2xl p-3.5 border border-slate-200/80 shadow-2xs hover:border-amber-400 active:scale-97 transition-all cursor-pointer flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-900 border border-amber-200 flex items-center justify-center">
                  {getServiceIcon(service.icon)}
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900 leading-snug">
                    {service.name}
                  </h4>
                  <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                    {service.description || 'Pengerjaan rapi & tepat waktu'}
                  </p>
                </div>
              </div>

              <div className="pt-2.5 mt-2 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-[9px] text-slate-400 block leading-none">Biaya:</span>
                  <span className="text-xs font-black text-amber-950">
                    Rp{service.base_price.toLocaleString('id-ID')}
                  </span>
                </div>
                <span className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">
                  <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* HOW IT WORKS (Mobile Card) */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
          Alur Pengerjaan Praktis
        </h3>
        <div className="space-y-2.5 text-xs text-slate-700">
          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-950 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
              1
            </span>
            <div>
              <p className="font-bold text-slate-900">Pilih Layanan & Upload File</p>
              <p className="text-[11px] text-slate-500">Unggah berkas tugas dan tulis instruksi deadline.</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-950 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
              2
            </span>
            <div>
              <p className="font-bold text-slate-900">Bisa Nego & Potong Voucher</p>
              <p className="text-[11px] text-slate-500">Saldo voucher Rp30.000 otomatis memotong biaya tugasmu.</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-950 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
              3
            </span>
            <div>
              <p className="font-bold text-slate-900">Terima Hasil & Garansi Revisi</p>
              <p className="text-[11px] text-slate-500">Unduh hasil jadi, bisa minta revisi sampai sesuai.</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

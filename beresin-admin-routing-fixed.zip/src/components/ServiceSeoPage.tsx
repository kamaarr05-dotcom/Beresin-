import React, { useEffect, useState } from 'react';
import { 
  ArrowLeft, 
  Sparkles, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  MessageSquare, 
  UserPlus, 
  LogIn, 
  ArrowRight, 
  ShieldCheck,
  Tag,
  Clock,
  HelpCircle
} from 'lucide-react';
import { SeoServiceDetail, SEO_SERVICES } from '../data/seoServices';
import { ServiceItem } from '../types';

interface ServiceSeoPageProps {
  serviceSlug: string;
  allServices: ServiceItem[];
  onOpenAuth: (mode: 'login' | 'register') => void;
  onNavigateHome: () => void;
  onNavigateService: (slug: string) => void;
  onSelectServiceOrder?: (service: ServiceItem) => void;
}

export const ServiceSeoPage: React.FC<ServiceSeoPageProps> = ({
  serviceSlug,
  allServices,
  onOpenAuth,
  onNavigateHome,
  onNavigateService,
  onSelectServiceOrder,
}) => {
  const WHATSAPP_NUMBER = '08136732365';
  const detail: SeoServiceDetail | undefined = SEO_SERVICES[serviceSlug] || SEO_SERVICES['jasa-ppt'];
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Update Page Title, Canonical, Open Graph, and Structured Data dynamically for SEO
  useEffect(() => {
    if (detail) {
      document.title = detail.metaTitle;
      
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        metaDesc.setAttribute('content', detail.metaDescription);
      }

      const pageUrl = `https://kamaarr05-dotcom.github.io/Beresin-/${detail.slug}/`;

      // Update Canonical Link
      const canonicalLink = document.querySelector('link[rel="canonical"]');
      if (canonicalLink) {
        canonicalLink.setAttribute('href', pageUrl);
      }

      // Update Open Graph Metadata
      const ogUrl = document.querySelector('meta[property="og:url"]');
      if (ogUrl) ogUrl.setAttribute('content', pageUrl);

      const ogTitle = document.querySelector('meta[property="og:title"]');
      if (ogTitle) ogTitle.setAttribute('content', detail.metaTitle);

      const ogDesc = document.querySelector('meta[property="og:description"]');
      if (ogDesc) ogDesc.setAttribute('content', detail.metaDescription);

      const ogImage = document.querySelector('meta[property="og:image"]');
      if (ogImage) ogImage.setAttribute('content', 'https://kamaarr05-dotcom.github.io/Beresin-/favicon.svg');

      // Update Twitter Card Metadata
      const twTitle = document.querySelector('meta[name="twitter:title"]');
      if (twTitle) twTitle.setAttribute('content', detail.metaTitle);

      const twDesc = document.querySelector('meta[name="twitter:description"]');
      if (twDesc) twDesc.setAttribute('content', detail.metaDescription);

      const twImage = document.querySelector('meta[name="twitter:image"]');
      if (twImage) twImage.setAttribute('content', 'https://kamaarr05-dotcom.github.io/Beresin-/favicon.svg');

      // Inject Service-specific Schema.org JSON-LD
      let serviceScript = document.getElementById('seo-service-jsonld') as HTMLScriptElement | null;
      if (!serviceScript) {
        serviceScript = document.createElement('script');
        serviceScript.id = 'seo-service-jsonld';
        serviceScript.type = 'application/ld+json';
        document.head.appendChild(serviceScript);
      }
      serviceScript.textContent = JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'Service',
        '@id': `${pageUrl}#service`,
        'name': detail.h1,
        'description': detail.shortDesc,
        'provider': {
          '@type': 'ProfessionalService',
          '@id': 'https://kamaarr05-dotcom.github.io/Beresin-/#organization',
          'name': 'BERESIN',
          'url': 'https://kamaarr05-dotcom.github.io/Beresin-/'
        },
        'url': pageUrl,
        'offers': {
          '@type': 'Offer',
          'price': String(detail.startingPrice),
          'priceCurrency': 'IDR',
          'url': pageUrl
        }
      });

      window.scrollTo(0, 0);
    }

    return () => {
      // Revert to default BERESIN Home SEO metadata when navigating back
      document.title = 'BERESIN - Jasa PPT, Excel, Word, Edit Video & Desain';
      const canonicalLink = document.querySelector('link[rel="canonical"]');
      if (canonicalLink) {
        canonicalLink.setAttribute('href', 'https://kamaarr05-dotcom.github.io/Beresin-/');
      }
      const ogUrl = document.querySelector('meta[property="og:url"]');
      if (ogUrl) ogUrl.setAttribute('content', 'https://kamaarr05-dotcom.github.io/Beresin-/');

      const ogTitle = document.querySelector('meta[property="og:title"]');
      if (ogTitle) ogTitle.setAttribute('content', 'BERESIN - Jasa PPT, Excel, Word, Edit Video & Desain');

      const ogDesc = document.querySelector('meta[property="og:description"]');
      if (ogDesc) ogDesc.setAttribute('content', 'Layanan pengerjaan tugas & jasa digital profesional mahasiswa: jasa PPT, Excel, Word, edit video, desain, transkripsi. Harga transparan, voucher Rp30.000 & fitur negosiasi harga.');

      const serviceScript = document.getElementById('seo-service-jsonld');
      if (serviceScript) {
        serviceScript.remove();
      }
    };
  }, [detail]);

  if (!detail) {
    return null;
  }

  // Find corresponding ServiceItem from existing system
  const matchedServiceItem = allServices.find(
    s => s.id.toLowerCase().includes(detail.slug.replace('jasa-', '')) || 
         s.name.toLowerCase().includes(detail.slug.replace('jasa-', ''))
  );

  const whatsappMessage = encodeURIComponent(
    `Halo Admin BERESIN, saya mau konsultasi dan order ${detail.h1} (Voucher Rp30.000).`
  );
  const whatsappUrl = `https://wa.me/628136732365?text=${whatsappMessage}`;

  const otherServices = Object.values(SEO_SERVICES).filter(s => s.slug !== detail.slug);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950">
      
      {/* Header / Nav */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          
          <div className="flex items-center gap-3">
            <button
              onClick={onNavigateHome}
              className="p-2 -ml-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors flex items-center gap-1 text-xs font-bold"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Beranda</span>
            </button>

            <div className="h-4 w-px bg-slate-200 hidden sm:block" />

            {/* Logo */}
            <div 
              onClick={onNavigateHome}
              className="flex items-center gap-2 cursor-pointer"
            >
              <div className="w-8 h-8 rounded-lg bg-slate-950 flex items-center justify-center text-amber-400 font-black text-sm">
                B
              </div>
              <span className="font-display font-black text-slate-900 tracking-tight">
                BERESIN
              </span>
            </div>
          </div>

          {/* Quick Action */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenAuth('login')}
              className="px-3 py-1.5 text-xs font-bold text-slate-700 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Login
            </button>
            <button
              onClick={() => onOpenAuth('register')}
              className="px-3.5 py-1.5 text-xs font-black bg-slate-950 hover:bg-slate-800 text-white rounded-xl shadow-xs transition-all flex items-center gap-1.5"
            >
              <UserPlus className="w-3.5 h-3.5 text-amber-400" />
              <span>Daftar</span>
            </button>
          </div>

        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-10">
        
        {/* Breadcrumb Navigation */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-slate-500">
          <button 
            onClick={onNavigateHome} 
            className="hover:text-amber-600 transition-colors font-medium"
          >
            Beranda
          </button>
          <span>/</span>
          <span className="text-slate-900 font-semibold">{detail.title}</span>
        </nav>

        {/* Hero Section of Service */}
        <section className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-sm space-y-6 relative overflow-hidden">
          
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-black uppercase tracking-wider border border-amber-300">
              {detail.badge}
            </span>
            <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold flex items-center gap-1">
              <Tag className="w-3 h-3 text-amber-600" />
              <span>Harga Mulai: <strong>Rp{detail.startingPrice.toLocaleString('id-ID')}</strong></span>
            </span>
            <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-emerald-600" />
              <span>Bisa Pakai Voucher Rp30.000</span>
            </span>
          </div>

          <div className="space-y-3">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight font-display">
              {detail.h1}
            </h1>
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
              {detail.shortDesc}
            </p>
          </div>

          {/* Price Negotiation Highlight */}
          <div className="p-4 bg-amber-50/80 rounded-2xl border border-amber-200 text-xs sm:text-sm text-amber-950 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xl">💬</span>
              <div>
                <strong className="block font-bold">Fitur Negosiasi Harga Fleksibel</strong>
                <span className="text-xs text-amber-800">“Harga dapat dinegosiasikan untuk pekerjaan tertentu sesuai anggaran Anda.”</span>
              </div>
            </div>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="shrink-0 px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl font-bold text-xs shadow-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Tanya Nego via WA</span>
            </a>
          </div>

          {/* Action Callouts */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
            <button
              onClick={() => {
                if (matchedServiceItem && onSelectServiceOrder) {
                  onSelectServiceOrder(matchedServiceItem);
                } else {
                  onOpenAuth('register');
                }
              }}
              className="w-full sm:w-auto px-6 py-3.5 bg-slate-950 hover:bg-slate-800 text-white rounded-2xl text-sm font-black shadow-md active:scale-98 transition-all flex items-center justify-center gap-2"
            >
              <UserPlus className="w-4 h-4 text-amber-400" />
              <span>Pesan Jasa Sekarang (Daftar & Klaim Voucher)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onOpenAuth('login')}
              className="w-full sm:w-auto px-5 py-3.5 bg-white border border-slate-300 hover:border-slate-400 text-slate-800 rounded-2xl text-sm font-bold active:scale-98 transition-all flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4 text-slate-600" />
              <span>Sudah Punya Akun? Login</span>
            </button>
          </div>

        </section>

        {/* Deliverables Section */}
        <section className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-5">
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <span>Apa yang Anda Dapatkan dalam Layanan Ini?</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
            {detail.deliverables.map((item, idx) => (
              <div key={idx} className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs sm:text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Keunggulan BERESIN */}
        <section className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-md space-y-4">
          <h2 className="text-lg sm:text-xl font-black tracking-tight text-amber-400 flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            <span>Keunggulan Layanan BERESIN</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {detail.whyUs.map((w, idx) => (
              <div key={idx} className="p-3.5 bg-slate-800/90 rounded-xl border border-slate-700 text-xs text-slate-200 space-y-1">
                <span className="text-amber-400 font-bold block">✓ Keunggulan {idx + 1}</span>
                <p>{w}</p>
              </div>
            ))}
          </div>
        </section>

        {/* FAQ Section */}
        <section className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
          <div className="space-y-1">
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-amber-600" />
              <span>Pertanyaan yang Sering Ditanyakan ({detail.slug.replace('jasa-', '').toUpperCase()})</span>
            </h2>
            <p className="text-xs text-slate-500">
              Informasi lengkap seputar pemesanan, teknis pengerjaan, dan garansi revisi.
            </p>
          </div>

          <div className="space-y-2.5 pt-2">
            {detail.faqs.map((faq, idx) => (
              <div 
                key={idx} 
                className="border border-slate-200 rounded-2xl overflow-hidden transition-colors"
              >
                <button
                  onClick={() => toggleFaq(idx)}
                  className="w-full text-left p-4 bg-slate-50 hover:bg-slate-100/80 flex items-center justify-between gap-3 text-xs sm:text-sm font-bold text-slate-800 transition-colors"
                >
                  <span>{faq.question}</span>
                  {openFaqIndex === idx ? (
                    <ChevronUp className="w-4 h-4 text-slate-500 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                  )}
                </button>
                {openFaqIndex === idx && (
                  <div className="p-4 bg-white text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Promo Voucher Callout */}
        <section className="bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 rounded-3xl p-6 sm:p-8 text-center space-y-4 shadow-md">
          <span className="px-3 py-1 rounded-full bg-slate-950 text-amber-300 text-xs font-black uppercase tracking-wider inline-block">
            Voucher Promo Mahasiswa
          </span>
          <h2 className="text-2xl sm:text-3xl font-black uppercase">
            Hemat Sampai Rp30.000 untuk Pengerjaan {detail.h1}
          </h2>
          <p className="text-xs sm:text-sm text-slate-950/90 max-w-lg mx-auto">
            Daftar akun sekarang, dapatkan saldo voucher potongan harga jasa Rp30.000 yang langsung dapat digunakan pada pesanan pertamamu.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onOpenAuth('register')}
              className="w-full sm:w-auto px-6 py-3 bg-slate-950 hover:bg-slate-900 text-white font-black rounded-xl text-sm shadow-md transition-all"
            >
              Daftar & Ambil Voucher
            </button>
            <button
              onClick={() => onOpenAuth('login')}
              className="w-full sm:w-auto px-5 py-3 bg-white hover:bg-slate-100 text-slate-900 font-bold rounded-xl text-sm transition-all"
            >
              Login Mahasiswa
            </button>
          </div>
        </section>

        {/* Other Services Internal Linking (Crucial for SEO crawl tree) */}
        <section className="space-y-4 pt-4">
          <div className="space-y-1 text-center">
            <h3 className="text-base sm:text-lg font-bold text-slate-900">
              Layanan Tugas Digital Lainnya di BERESIN
            </h3>
            <p className="text-xs text-slate-500">
              Jelajahi kategori layanan lain untuk menuntaskan kebutuhan akademik dan kantor Anda:
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {otherServices.map((srv) => (
              <a
                key={srv.slug}
                href={`https://kamaarr05-dotcom.github.io/Beresin-/${srv.slug}/`}
                onClick={(e) => {
                  e.preventDefault();
                  onNavigateService(srv.slug);
                }}
                className="p-3 bg-white rounded-xl border border-slate-200 hover:border-amber-400 text-left hover:shadow-xs transition-all group block cursor-pointer"
              >
                <span className="text-[10px] font-bold text-amber-700 block mb-0.5">Mulai Rp{srv.startingPrice.toLocaleString('id-ID')}</span>
                <span className="text-xs font-bold text-slate-800 group-hover:text-amber-800 transition-colors line-clamp-1">
                  {srv.h1}
                </span>
              </a>
            ))}
          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-8 mt-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} <strong>BERESIN</strong>. Layanan pengerjaan tugas & jasa digital profesional.
          </div>
          <div className="flex items-center gap-4">
            <button onClick={onNavigateHome} className="hover:text-amber-600 font-medium">Beranda</button>
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:text-emerald-600 font-bold">
              WhatsApp: {WHATSAPP_NUMBER}
            </a>
          </div>
        </div>
      </footer>

    </div>
  );
};

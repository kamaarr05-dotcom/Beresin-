import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ServiceItem, UserProfile } from '../types';
import { BeresinDataStore, isSupabaseConfigured } from '../lib/supabase';
import { AdminPaymentSettings } from './AdminPaymentSettings';
import { 
  User, 
  Mail, 
  Phone, 
  Database, 
  ShieldCheck, 
  Edit3, 
  MessageSquare, 
  LogOut, 
  ChevronRight, 
  Users, 
  Layers, 
  Sparkles,
  CheckCircle2,
  Check,
  X,
  CreditCard,
  ArrowLeft
} from 'lucide-react';

interface ProfileTabProps {
  services: ServiceItem[];
  users: UserProfile[];
  onRefreshData: () => void;
  onOpenSupabaseModal: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  services,
  users,
  onRefreshData,
  onOpenSupabaseModal,
  onOpenAuth,
}) => {
  const { currentUser, role, logout } = useAuth();
  
  // Admin sub-sheets in profile
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [showStudentsModal, setShowStudentsModal] = useState(false);
  const [showPaymentSettings, setShowPaymentSettings] = useState(false);

  const handleStartEditService = (s: ServiceItem) => {
    setEditingServiceId(s.id);
    setEditPrice(s.base_price);
  };

  const handleSaveServicePrice = (id: string) => {
    BeresinDataStore.updateServicePrice(id, editPrice);
    setEditingServiceId(null);
    onRefreshData();
  };

  if (showPaymentSettings) {
    return (
      <div className="space-y-4 pb-20 animate-in fade-in duration-150">
        <div className="flex items-center gap-2 px-1">
          <button
            onClick={() => setShowPaymentSettings(false)}
            className="p-2 -ml-1 text-slate-700 hover:text-slate-950 active:bg-slate-100 rounded-full transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-base font-black text-slate-900">
            Kartu Bank & WhatsApp Admin
          </h2>
        </div>
        <AdminPaymentSettings 
          onSaved={onRefreshData}
          onClose={() => setShowPaymentSettings(false)}
        />
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-150">
      
      {/* USER CARD */}
      {currentUser ? (
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-amber-400 text-slate-950 font-black text-xl flex items-center justify-center shadow-xs">
              {currentUser.full_name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 overflow-hidden">
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-slate-900 truncate">
                  {currentUser.full_name}
                </h2>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                  role === 'ADMIN' ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-blue-100 text-blue-900'
                }`}>
                  {role}
                </span>
              </div>
              <p className="text-xs text-slate-500 truncate flex items-center gap-1 mt-0.5">
                <Mail className="w-3 h-3" />
                <span>{currentUser.email}</span>
              </p>
              <p className="text-xs text-slate-500 truncate flex items-center gap-1 mt-0.5">
                <Phone className="w-3 h-3" />
                <span>{currentUser.whatsapp}</span>
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs text-center space-y-4">
          <div className="w-16 h-16 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
            <User className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-base font-black text-slate-900">Belum Masuk Akun</h2>
            <p className="text-xs text-slate-500 mt-1">
              Daftar akun sekarang untuk mulai memesan jasa pengerjaan tugas & skripsi!
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onOpenAuth('login')}
              className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold"
            >
              Masuk
            </button>
            <button
              onClick={() => onOpenAuth('register')}
              className="flex-1 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl text-xs shadow-xs"
            >
              Daftar Akun
            </button>
          </div>
        </div>
      )}

      {/* ADMIN EXCLUSIVE SECTION: SERVICE PRICING & STUDENTS */}
      {role === 'ADMIN' && (
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-amber-500" />
              <span>Kelola Harga Layanan</span>
            </h3>
            <span className="text-[10px] text-slate-400">Dapat diubah admin</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Harga ini tampil langsung di halaman Beranda untuk dilihat calon pemesan:
          </p>

          <div className="space-y-2">
            {services.map((s) => (
              <div
                key={s.id}
                className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs"
              >
                <div>
                  <p className="font-bold text-slate-900">{s.name}</p>
                  <p className="text-[11px] text-slate-500">{s.unit_label}</p>
                </div>
                {editingServiceId === s.id ? (
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      value={editPrice}
                      onChange={(e) => setEditPrice(Number(e.target.value))}
                      step="5000"
                      className="w-20 px-2 py-1 bg-white border border-amber-400 rounded-lg text-xs font-bold outline-none"
                    />
                    <button
                      onClick={() => handleSaveServicePrice(s.id)}
                      className="p-1.5 bg-emerald-600 text-white rounded-lg"
                      title="Simpan"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setEditingServiceId(null)}
                      className="p-1.5 bg-slate-200 text-slate-700 rounded-lg"
                      title="Batal"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span className="font-black text-amber-900">
                      Rp{s.base_price.toLocaleString('id-ID')}
                    </span>
                    <button
                      onClick={() => handleStartEditService(s)}
                      className="p-1.5 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 rounded-lg"
                      title="Ubah Harga"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ADMIN: DAFTAR SISWA TERDAFTAR */}
      {role === 'ADMIN' && (
        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-blue-500" />
              <span>Daftar Siswa ({users.filter(u => u.role === 'STUDENT').length})</span>
            </h3>
            <button
              onClick={() => setShowStudentsModal(!showStudentsModal)}
              className="text-xs font-bold text-amber-700"
            >
              {showStudentsModal ? 'Tutup' : 'Lihat'}
            </button>
          </div>

          {showStudentsModal && (
            <div className="space-y-2 pt-2 border-t border-slate-100">
              {users.filter(u => u.role === 'STUDENT').map((u) => (
                <div
                  key={u.id}
                  className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs"
                >
                  <div>
                    <p className="font-bold text-slate-900">{u.full_name}</p>
                    <p className="text-[11px] text-slate-500">{u.email} • Saldo: Rp{u.voucher_balance.toLocaleString('id-ID')}</p>
                  </div>
                  <a
                    href={`https://wa.me/${u.whatsapp.replace(/[^0-9]/g, '')}?text=Halo%20${encodeURIComponent(u.full_name)},%20ini%20Admin%20BERESIN`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 bg-emerald-100 text-emerald-800 rounded-xl"
                    title="WhatsApp Siswa"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                  </a>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* MENU LIST ITEMS (iOS/Android style) */}
      <div className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-xs divide-y divide-slate-100">
        
        {/* Admin Bank & WhatsApp Settings */}
        {role === 'ADMIN' && (
          <button
            onClick={() => setShowPaymentSettings(true)}
            className="w-full p-4 flex items-center justify-between hover:bg-amber-50/60 transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                <CreditCard className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900">Kartu Bank & WhatsApp Admin</p>
                <p className="text-[11px] text-slate-400">Atur nomor rekening, nama bank, dan WhatsApp admin</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        )}

        {/* Supabase status */}
        <button
          onClick={onOpenSupabaseModal}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <span>Database Supabase & PostgreSQL</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
              </p>
              <p className="text-[11px] text-slate-400">
                {isSupabaseConfigured ? 'Terkoneksi Live Cloud' : 'Mode Operasional Standby'}
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* WhatsApp Admin */}
        <a
          href="https://wa.me/6281234567890?text=Halo%20Admin%20BERESIN,%20saya%20butuh%20bantuan"
          target="_blank"
          rel="noopener noreferrer"
          className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900">Hubungi Admin di WhatsApp</p>
              <p className="text-[11px] text-slate-400">Konsultasi tugas & pembelian voucher</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </a>

        {/* Info Privasi & Garansi */}
        <div className="p-4 flex items-center justify-between text-left">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900">Garansi Revisi & Privasi</p>
              <p className="text-[11px] text-slate-400">File privat & jaminan revisi tuntas</p>
            </div>
          </div>
        </div>

        {/* Logout */}
        {currentUser && (
          <button
            onClick={logout}
            className="w-full p-4 flex items-center justify-between hover:bg-rose-50 transition-colors text-left text-rose-600"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center">
                <LogOut className="w-4 h-4" />
              </div>
              <p className="text-xs font-bold">Keluar dari Akun</p>
            </div>
            <ChevronRight className="w-4 h-4 text-rose-400" />
          </button>
        )}
      </div>

      {/* App Info Footer */}
      <div className="text-center text-[11px] text-slate-400 pt-2 space-y-1">
        <p className="font-bold text-slate-600">BERESIN Mobile v2.0</p>
        <p>„Kirim pekerjaanmu. Kami yang bereskan.”</p>
      </div>

    </div>
  );
};

import React, { useState, useRef } from 'react';
import { 
  OrderItem, 
  OrderStatus, 
  ServiceItem, 
  VoucherCode 
} from '../types';
import { 
  ShieldCheck, 
  Package, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Percent, 
  DollarSign, 
  UploadCloud, 
  Download, 
  FileText, 
  FileCheck, 
  Search, 
  Plus, 
  Copy, 
  Check, 
  Ticket, 
  CreditCard, 
  Settings, 
  MessageSquare, 
  RefreshCw,
  Eye,
  X,
  Send,
  Building2,
  Calendar,
  LogOut
} from 'lucide-react';
import { BeresinDataStore } from '../lib/supabase';
import { BeresinStorage } from '../lib/fileStorage';
import { AdminPaymentSettings } from './AdminPaymentSettings';
import { useAuth } from '../context/AuthContext';

interface AdminDashboardProps {
  orders: OrderItem[];
  services: ServiceItem[];
  vouchers: VoucherCode[];
  onRefreshData: () => void;
  onSelectOrder: (order: OrderItem) => void;
  onViewProof: (order: OrderItem) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  orders,
  services,
  vouchers,
  onRefreshData,
  onSelectOrder,
  onViewProof,
}) => {
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'orders' | 'vouchers' | 'services' | 'payment_settings'>('orders');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals inside Admin
  // 1. Set Price & Respond Negotiation Modal
  const [pricingOrder, setPricingOrder] = useState<OrderItem | null>(null);
  const [inputFinalPrice, setInputFinalPrice] = useState<number | ''>('');
  const [negotiationDecision, setNegotiationDecision] = useState<'ACCEPTED' | 'ADJUSTED' | 'REJECTED' | 'NONE' | 'PENDING'>('NONE');
  const [adminNote, setAdminNote] = useState('');

  // 2. Upload Result Modal
  const [uploadResultOrder, setUploadResultOrder] = useState<OrderItem | null>(null);
  const [resultFile, setResultFile] = useState<File | null>(null);
  const [resultNotes, setResultNotes] = useState('');
  const [isUploadingResult, setIsUploadingResult] = useState(false);

  // 3. New Voucher Modal
  const [isGeneratingVoucher, setIsGeneratingVoucher] = useState(false);
  const [newVoucherCode, setNewVoucherCode] = useState('');
  const [newVoucherValue, setNewVoucherValue] = useState(30000);
  const [newVoucherCost, setNewVoucherCost] = useState(10000);
  const [copiedVoucher, setCopiedVoucher] = useState<string | null>(null);

  // 4. Edit Service Modal
  const [editingService, setEditingService] = useState<ServiceItem | null>(null);
  const [editPrice, setEditPrice] = useState<number | ''>('');
  const [editUnitLabel, setEditUnitLabel] = useState('');

  // Filtering orders
  const filteredOrders = orders.filter((order) => {
    const matchesStatus = statusFilter === 'ALL' || order.status === statusFilter;
    const matchesSearch = 
      order.order_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.student_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.student_whatsapp.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.service_name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  // Handlers for Pricing & Negotiation
  const openPricingModal = (order: OrderItem) => {
    setPricingOrder(order);
    setInputFinalPrice(order.final_price || order.negotiation_price || order.base_price);
    if (order.negotiation_requested) {
      setNegotiationDecision(order.negotiation_status || 'ACCEPTED');
    } else {
      setNegotiationDecision('NONE');
    }
    setAdminNote(order.admin_negotiation_note || '');
  };

  const handleSavePrice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pricingOrder || inputFinalPrice === '' || Number(inputFinalPrice) < 0) return;

    BeresinDataStore.setFinalPrice(
      pricingOrder.id,
      Number(inputFinalPrice),
      pricingOrder.negotiation_requested ? (negotiationDecision as any) : undefined,
      adminNote.trim() || undefined
    );

    setPricingOrder(null);
    onRefreshData();
  };

  // Handlers for Payment Confirmation
  const handleConfirmPayment = (orderId: string) => {
    if (window.confirm('Pastikan dana transfer / QRIS sudah masuk ke mutasi rekening Anda. Konfirmasi pesanan ini?')) {
      BeresinDataStore.confirmPayment(orderId);
      onRefreshData();
    }
  };

  // Handlers for Workflow Progression
  const handleStartWorking = (orderId: string) => {
    BeresinDataStore.updateOrderStatus(orderId, 'DIKERJAKAN');
    onRefreshData();
  };

  // Handlers for Uploading Result
  const handleUploadResultSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadResultOrder || !resultFile) return;

    setIsUploadingResult(true);
    try {
      const uploaded = await BeresinStorage.uploadFile(resultFile);
      BeresinDataStore.uploadWorkResult(
        uploadResultOrder.id,
        uploaded.fileName,
        uploaded.fileUrl,
        resultNotes.trim()
      );

      setIsUploadingResult(false);
      setUploadResultOrder(null);
      setResultFile(null);
      setResultNotes('');
      onRefreshData();
    } catch (err) {
      console.error(err);
      setIsUploadingResult(false);
      alert('Gagal mengunggah berkas hasil.');
    }
  };

  // Handlers for Voucher Generation
  const handleGenerateVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    const code = newVoucherCode.trim().toUpperCase() || `BERESIN-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
    BeresinDataStore.createVoucher({
      code,
      value: newVoucherValue,
      cost_price: newVoucherCost,
    });
    setNewVoucherCode('');
    setIsGeneratingVoucher(false);
    onRefreshData();
  };

  const handleCopyVoucher = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedVoucher(code);
    setTimeout(() => setCopiedVoucher(null), 2000);
  };

  // Handlers for Service Editing
  const handleSaveService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingService || editPrice === '') return;

    BeresinDataStore.updateService(editingService.id, {
      base_price: Number(editPrice),
      unit_label: editUnitLabel.trim() || editingService.unit_label,
    });

    setEditingService(null);
    onRefreshData();
  };

  return (
    <div className="space-y-6">
      
      {/* Admin Header Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-6 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-amber-400 text-slate-950 text-[10px] font-black uppercase">
              Admin Workspace
            </span>
            <span className="text-xs text-slate-400 font-medium">Beresin Management Console</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-amber-400" />
            <span>Pusat Kendali Pesanan & Pembayaran</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl">
            Tinjau pesanan mahasiswa, setujui negosiasi harga, verifikasi pembayaran QRIS, dan kirim berkas hasil tugas.
          </p>
        </div>

        {/* Quick Stats Grid & Logout */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="grid grid-cols-3 gap-2 shrink-0 bg-slate-950/80 p-3 rounded-2xl border border-slate-800 text-center">
            <div>
              <span className="text-[10px] text-slate-400 block">Total Pesanan</span>
              <span className="text-lg font-black text-amber-400">{orders.length}</span>
            </div>
            <div className="border-x border-slate-800 px-2">
              <span className="text-[10px] text-slate-400 block">Perlu Dikerjakan</span>
              <span className="text-lg font-black text-white">
                {orders.filter(o => ['ANTRIAN', 'DIKERJAKAN', 'REVISI'].includes(o.status)).length}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Menunggu Bayar</span>
              <span className="text-lg font-black text-orange-400">
                {orders.filter(o => o.status === 'MENUNGGU_PEMBAYARAN').length}
              </span>
            </div>
          </div>

          <button
            onClick={logout}
            className="px-3.5 py-2 rounded-2xl bg-slate-800 hover:bg-rose-950/50 hover:text-rose-200 text-slate-300 text-xs font-bold border border-slate-700 flex items-center justify-center gap-1.5 transition-colors active:scale-95"
            title="Keluar dari panel admin"
          >
            <LogOut className="w-3.5 h-3.5 text-rose-400" />
            <span>Keluar</span>
          </button>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeTab === 'orders'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Daftar Pesanan ({orders.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('vouchers')}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeTab === 'vouchers'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Ticket className="w-4 h-4" />
          <span>Kode Voucher Promo ({vouchers.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('services')}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeTab === 'services'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Layanan & Harga Dasar</span>
        </button>
        <button
          onClick={() => setActiveTab('payment_settings')}
          className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeTab === 'payment_settings'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <CreditCard className="w-4 h-4 text-amber-500" />
          <span>Kartu Rekening & WhatsApp</span>
        </button>
      </div>

      {/* TAB 1: ORDER MANAGEMENT */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          
          {/* Filter Bar & Search */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
            
            {/* Search Box */}
            <div className="relative w-full md:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari order #, nama, atau WA..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-amber-500 focus:bg-white"
              />
            </div>

            {/* Status Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 text-xs">
              {[
                { id: 'ALL', label: 'Semua' },
                { id: 'MENUNGGU_HARGA', label: 'Tinjau Harga' },
                { id: 'MENUNGGU_PEMBAYARAN', label: 'Bayar QRIS' },
                { id: 'ANTRIAN', label: 'Antrian' },
                { id: 'DIKERJAKAN', label: 'Dikerjakan' },
                { id: 'REVISI', label: 'Revisi' },
                { id: 'SELESAI', label: 'Selesai' },
              ].map((st) => (
                <button
                  key={st.id}
                  onClick={() => setStatusFilter(st.id)}
                  className={`px-3 py-1.5 rounded-xl font-bold transition-colors whitespace-nowrap ${
                    statusFilter === st.id
                      ? 'bg-amber-400 text-slate-950 shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>

          </div>

          {/* Orders Table / Cards */}
          {filteredOrders.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-10 text-center space-y-2">
              <Package className="w-10 h-10 text-slate-300 mx-auto" />
              <h4 className="text-sm font-bold text-slate-700">Tidak Ada Pesanan Ditemukan</h4>
              <p className="text-xs text-slate-400">Belum ada pesanan yang sesuai dengan filter atau kata kunci pencarian saat ini.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {filteredOrders.map((order) => (
                <div
                  key={order.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                >
                  {/* Left: Order Details & Student Info */}
                  <div className="space-y-2 max-w-xl">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md">
                        {order.order_number}
                      </span>
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        order.status === 'MENUNGGU_HARGA' ? 'bg-amber-100 text-amber-900 border border-amber-300' :
                        order.status === 'MENUNGGU_PEMBAYARAN' ? 'bg-orange-100 text-orange-900 border border-orange-300' :
                        order.status === 'ANTRIAN' ? 'bg-sky-100 text-sky-900 border border-sky-300' :
                        order.status === 'DIKERJAKAN' ? 'bg-indigo-100 text-indigo-900 border border-indigo-300' :
                        order.status === 'REVISI' ? 'bg-purple-100 text-purple-900 border border-purple-300' :
                        'bg-emerald-100 text-emerald-900 border border-emerald-300'
                      }`}>
                        {order.status.replace('_', ' ')}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {new Date(order.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-slate-900">
                        {order.service_name}
                      </h3>
                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 mt-1">
                        <span>Pemesan: <strong className="text-slate-900">{order.student_name}</strong></span>
                        <span>•</span>
                        <a
                          href={`https://wa.me/${order.student_whatsapp.replace(/[^0-9]/g, '')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-emerald-700 font-bold hover:underline flex items-center gap-1"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>{order.student_whatsapp}</span>
                        </a>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2 bg-slate-50 p-2 rounded-xl">
                      <strong>Instruksi:</strong> {order.instructions}
                    </p>

                    {/* Negotiation Callout if active */}
                    {order.negotiation_requested && (
                      <div className="p-2.5 bg-amber-50/80 border border-amber-200 rounded-xl text-xs flex items-start gap-2">
                        <Percent className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-bold text-amber-950">
                            Negosiasi Diajukan: Rp{order.negotiation_price?.toLocaleString('id-ID')}
                          </p>
                          <p className="text-[11px] text-slate-600 italic">
                            "{order.negotiation_reason}"
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Uploaded File Link if present */}
                    {order.file_name && (
                      <div className="flex items-center gap-2 text-xs">
                        <FileText className="w-3.5 h-3.5 text-slate-400" />
                        <span className="text-slate-600 truncate max-w-xs">{order.file_name}</span>
                        <button
                          onClick={() => BeresinStorage.triggerDownload(order.file_url, order.file_name)}
                          className="text-[11px] font-bold text-amber-600 hover:underline flex items-center gap-0.5"
                        >
                          <Download className="w-3 h-3" />
                          <span>Unduh</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Right: Pricing Summary & Actions */}
                  <div className="flex flex-col sm:items-end justify-between gap-3 border-t lg:border-t-0 lg:border-l border-slate-100 pt-3 lg:pt-0 lg:pl-5 shrink-0">
                    <div className="text-right space-y-1">
                      <div className="text-xs text-slate-500">
                        Harga Final: <strong className="text-slate-900 text-sm">{order.final_price !== null ? `Rp${order.final_price.toLocaleString('id-ID')}` : 'Belum Ditentukan'}</strong>
                      </div>
                      <div className="text-xs text-emerald-600">
                        Potongan Voucher: <strong>-Rp{order.voucher_deduction.toLocaleString('id-ID')}</strong>
                      </div>
                      <div className="text-sm font-black text-slate-950">
                        Harus Dibayar: <span className={order.amount_to_pay === 0 ? 'text-emerald-600' : 'text-amber-600'}>
                          {order.final_price === null ? '-' : order.amount_to_pay === 0 ? 'Rp0 (Lunas)' : `Rp${order.amount_to_pay.toLocaleString('id-ID')}`}
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons for this Order */}
                    <div className="flex flex-wrap items-center gap-2">
                      
                      {/* Step 1: Set Price or Respond Negotiation */}
                      {order.status === 'MENUNGGU_HARGA' && (
                        <button
                          onClick={() => openPricingModal(order)}
                          className="px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl text-xs shadow-xs transition-colors"
                        >
                          Tentukan Harga & Respon
                        </button>
                      )}

                      {/* Step 2: Confirm Payment */}
                      {order.status === 'MENUNGGU_PEMBAYARAN' && (
                        <div className="flex items-center gap-1.5">
                          {(order.payment_proof_name || order.payment_proof_url) && (
                            <button
                              onClick={() => onViewProof(order)}
                              className="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1"
                              title="Lihat Bukti Transfer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>Bukti</span>
                            </button>
                          )}
                          <button
                            onClick={() => handleConfirmPayment(order.id)}
                            className="px-3.5 py-2 bg-orange-500 hover:bg-orange-600 text-white font-black rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Konfirmasi QRIS</span>
                          </button>
                        </div>
                      )}

                      {/* Step 3: Start Working from Queue */}
                      {order.status === 'ANTRIAN' && (
                        <button
                          onClick={() => handleStartWorking(order.id)}
                          className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-xl text-xs shadow-xs transition-colors"
                        >
                          Mulai Dikerjakan
                        </button>
                      )}

                      {/* Step 4: Upload Result (Working or Revision) */}
                      {(order.status === 'DIKERJAKAN' || order.status === 'REVISI') && (
                        <button
                          onClick={() => setUploadResultOrder(order)}
                          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
                        >
                          <UploadCloud className="w-3.5 h-3.5" />
                          <span>Upload Berkas Hasil</span>
                        </button>
                      )}

                      {/* Detail Sheet Opener */}
                      <button
                        onClick={() => onSelectOrder(order)}
                        className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs transition-colors"
                      >
                        Detail Lengkap
                      </button>

                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: VOUCHER CODE MANAGEMENT */}
      {activeTab === 'vouchers' && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
                <Ticket className="w-5 h-5 text-amber-500" />
                <span>Kelola Kode Voucher Promo</span>
              </h3>
              <p className="text-xs text-slate-500 max-w-xl">
                Buat kode voucher promo untuk dijual kepada mahasiswa seharga Rp10.000 dengan nilai potongan jasa Rp30.000 (Single use).
              </p>
            </div>
            <button
              onClick={() => setIsGeneratingVoucher(true)}
              className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-all shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Buat Kode Voucher Baru</span>
            </button>
          </div>

          {/* Voucher List */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {vouchers.map((v) => (
              <div
                key={v.id}
                className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-2.5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[11px] font-bold text-slate-400">
                      Nilai Potongan: <strong className="text-amber-600">Rp{v.value.toLocaleString('id-ID')}</strong>
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      v.is_used ? 'bg-slate-100 text-slate-500' : 'bg-emerald-100 text-emerald-900'
                    }`}>
                      {v.is_used ? 'Sudah Digunakan' : 'Aktif / Belum Dipakai'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                    <span className="font-mono font-black text-sm text-slate-900 tracking-wider">
                      {v.code}
                    </span>
                    <button
                      onClick={() => handleCopyVoucher(v.code)}
                      className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-white"
                      title="Salin Kode"
                    >
                      {copiedVoucher === v.code ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 flex justify-between items-center">
                  <span>Harga Beli: Rp{v.cost_price.toLocaleString('id-ID')}</span>
                  {v.is_used && v.used_by_email && (
                    <span className="truncate max-w-[140px]" title={v.used_by_email}>
                      Oleh: {v.used_by_email}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: SERVICES & BASE PRICING */}
      {activeTab === 'services' && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-1">
            <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <Settings className="w-5 h-5 text-amber-500" />
              <span>Kelola Harga Dasar Layanan</span>
            </h3>
            <p className="text-xs text-slate-500 max-w-xl">
              Ubah harga awal untuk setiap jenis tugas. Siswa dapat melihat harga ini sebelum memesan dan dapat mengajukan tawaran negosiasi.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {services.map((srv) => (
              <div
                key={srv.id}
                className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-slate-400">{srv.category}</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${srv.is_active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                      {srv.is_active ? 'Aktif' : 'Non-aktif'}
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-slate-900">{srv.name}</h4>
                  <p className="text-xs text-slate-500 line-clamp-2 mt-1">{srv.description}</p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Harga Dasar</span>
                    <span className="text-sm font-black text-slate-900">
                      Rp{srv.base_price.toLocaleString('id-ID')}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setEditingService(srv);
                      setEditPrice(srv.base_price);
                      setEditUnitLabel(srv.unit_label);
                    }}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold"
                  >
                    Ubah Harga
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: PAYMENT SETTINGS & BANK CARD */}
      {activeTab === 'payment_settings' && (
        <AdminPaymentSettings onSaved={onRefreshData} />
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: SET FINAL PRICE & RESPOND NEGOTIATION */}
      {/* ========================================================================= */}
      {pricingOrder && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white w-full max-w-lg rounded-t-[32px] sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-150">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-base font-black text-slate-900">
                  Tentukan Harga Pesanan #{pricingOrder.order_number}
                </h3>
                <p className="text-xs text-slate-500">
                  {pricingOrder.service_name} • {pricingOrder.student_name}
                </p>
              </div>
              <button
                onClick={() => setPricingOrder(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePrice} className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
              
              {/* Negotiation Alert if present */}
              {pricingOrder.negotiation_requested && (
                <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 space-y-1.5">
                  <span className="font-bold text-amber-950 block">Pengajuan Negosiasi Mahasiswa</span>
                  <p className="text-slate-700">
                    Harga dasar layanan: <strong>Rp{pricingOrder.base_price.toLocaleString('id-ID')}</strong>
                    <br />
                    Tawaran mahasiswa: <strong className="text-amber-800 text-sm">Rp{pricingOrder.negotiation_price?.toLocaleString('id-ID')}</strong>
                  </p>
                  <p className="text-slate-600 italic">
                    Alasan: "{pricingOrder.negotiation_reason}"
                  </p>

                  <div className="pt-2 border-t border-amber-200">
                    <label className="block font-bold text-amber-950 mb-1">Respon Negosiasi:</label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setNegotiationDecision('ACCEPTED');
                          setInputFinalPrice(pricingOrder.negotiation_price || pricingOrder.base_price);
                        }}
                        className={`flex-1 py-1.5 rounded-xl font-bold transition-colors ${
                          negotiationDecision === 'ACCEPTED' ? 'bg-amber-500 text-slate-950' : 'bg-white text-slate-700 border border-amber-300'
                        }`}
                      >
                        Setujui ({pricingOrder.negotiation_price?.toLocaleString('id-ID')})
                      </button>
                      <button
                        type="button"
                        onClick={() => setNegotiationDecision('ADJUSTED')}
                        className={`flex-1 py-1.5 rounded-xl font-bold transition-colors ${
                          negotiationDecision === 'ADJUSTED' ? 'bg-amber-500 text-slate-950' : 'bg-white text-slate-700 border border-amber-300'
                        }`}
                      >
                        Sesuaikan Harga
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setNegotiationDecision('REJECTED');
                          setInputFinalPrice(pricingOrder.base_price);
                        }}
                        className={`flex-1 py-1.5 rounded-xl font-bold transition-colors ${
                          negotiationDecision === 'REJECTED' ? 'bg-amber-500 text-slate-950' : 'bg-white text-slate-700 border border-amber-300'
                        }`}
                      >
                        Tolak (Harga Dasar)
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Final Price Input */}
              <div className="space-y-1.5">
                <label className="block font-bold text-slate-700">
                  Harga Final Pesanan (Rp)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 font-bold text-slate-400">Rp</span>
                  <input
                    type="number"
                    step="1000"
                    required
                    value={inputFinalPrice}
                    onChange={(e) => setInputFinalPrice(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full pl-9 pr-3 py-2.5 text-sm font-black bg-white rounded-xl border border-slate-300 focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              {/* Voucher Calculation Simulator */}
              <div className="p-3 bg-slate-900 text-white rounded-2xl space-y-1 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Harga Final:</span>
                  <span className="text-white font-semibold">
                    Rp{(Number(inputFinalPrice) || 0).toLocaleString('id-ID')}
                  </span>
                </div>
                <div className="flex justify-between text-emerald-400">
                  <span>Maks Potongan Voucher Siswa:</span>
                  <span>-Rp{Math.min(Number(inputFinalPrice) || 0, 30000).toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between font-black text-amber-400 pt-1 border-t border-slate-800 text-sm">
                  <span>Siswa Akan Bayar:</span>
                  <span>
                    Rp{Math.max(0, (Number(inputFinalPrice) || 0) - Math.min(Number(inputFinalPrice) || 0, 30000)).toLocaleString('id-ID')}
                  </span>
                </div>
              </div>

              {/* Admin Note */}
              <div className="space-y-1">
                <label className="block font-bold text-slate-700">
                  Catatan untuk Mahasiswa (Opsional)
                </label>
                <textarea
                  rows={2}
                  value={adminNote}
                  onChange={(e) => setAdminNote(e.target.value)}
                  placeholder="Contoh: Harga disesuaikan karena terdapat penambahan 4 slide diagram kompleks..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-amber-500 resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPricingOrder(null)}
                  className="px-4 py-2 font-bold text-slate-600 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl shadow-xs"
                >
                  Simpan & Kirim Tagihan ke Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: UPLOAD WORK RESULT FILE & COMPLETE ORDER */}
      {/* ========================================================================= */}
      {uploadResultOrder && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white w-full max-w-lg rounded-t-[32px] sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-150">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-base font-black text-slate-900">
                  Upload Hasil Pekerjaan #{uploadResultOrder.order_number}
                </h3>
                <p className="text-xs text-slate-500">
                  {uploadResultOrder.service_name} • {uploadResultOrder.student_name}
                </p>
              </div>
              <button
                onClick={() => setUploadResultOrder(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUploadResultSubmit} className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
              
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  Pilih Berkas Hasil (DOCX, PPTX, PDF, ZIP, dll)
                </label>
                <label className="flex flex-col items-center justify-center p-5 border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl cursor-pointer bg-slate-50">
                  <input
                    type="file"
                    required
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setResultFile(e.target.files[0]);
                      }
                    }}
                  />
                  {resultFile ? (
                    <div className="flex items-center gap-2 text-emerald-800 font-bold">
                      <FileCheck className="w-5 h-5 text-emerald-600" />
                      <span>{resultFile.name} ({(resultFile.size / 1024).toFixed(0)} KB)</span>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-1 text-slate-500">
                      <UploadCloud className="w-7 h-7 text-slate-400" />
                      <span className="font-bold text-slate-700">Klik untuk memilih berkas hasil</span>
                      <span className="text-[10px] text-slate-400">Berkas akan tersimpan di private storage</span>
                    </div>
                  )}
                </label>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Catatan untuk Mahasiswa
                </label>
                <textarea
                  rows={3}
                  value={resultNotes}
                  onChange={(e) => setResultNotes(e.target.value)}
                  placeholder="Contoh: Pekerjaan telah tuntas disesuaikan dengan instruksi. File PPT dan PDF sudah digabungkan. Silakan diperiksa..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 outline-none focus:border-emerald-500 resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setUploadResultOrder(null)}
                  className="px-4 py-2 font-bold text-slate-600 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isUploadingResult || !resultFile}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black rounded-xl shadow-xs flex items-center gap-1.5"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>{isUploadingResult ? 'Mengunggah...' : 'Upload & Tandai SELESAI'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: GENERATE NEW VOUCHER */}
      {/* ========================================================================= */}
      {isGeneratingVoucher && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-base font-black text-slate-900">
                Buat Kode Voucher Baru
              </h3>
              <button
                onClick={() => setIsGeneratingVoucher(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleGenerateVoucher} className="p-5 space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Kode Voucher (Kosongkan untuk acak)
                </label>
                <input
                  type="text"
                  value={newVoucherCode}
                  onChange={(e) => setNewVoucherCode(e.target.value.toUpperCase())}
                  placeholder="Contoh: BERESIN-PROMO30"
                  className="w-full px-3 py-2 font-mono uppercase bg-slate-50 border border-slate-300 rounded-xl outline-none focus:border-amber-500 font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Nilai Potongan (Rp)
                  </label>
                  <input
                    type="number"
                    step="1000"
                    required
                    value={newVoucherValue}
                    onChange={(e) => setNewVoucherValue(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:border-amber-500 font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Harga Jual Beli (Rp)
                  </label>
                  <input
                    type="number"
                    step="1000"
                    required
                    value={newVoucherCost}
                    onChange={(e) => setNewVoucherCost(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:border-amber-500 font-bold"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsGeneratingVoucher(false)}
                  className="px-4 py-2 font-bold text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-black rounded-xl"
                >
                  Buat Voucher
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: EDIT SERVICE BASE PRICE */}
      {/* ========================================================================= */}
      {editingService && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-base font-black text-slate-900">
                Ubah Harga Dasar: {editingService.name}
              </h3>
              <button
                onClick={() => setEditingService(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveService} className="p-5 space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Harga Dasar Mulai (Rp)
                </label>
                <input
                  type="number"
                  step="1000"
                  required
                  value={editPrice}
                  onChange={(e) => setEditPrice(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:border-amber-500 font-black text-sm"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Label Satuan / Estimasi
                </label>
                <input
                  type="text"
                  value={editUnitLabel}
                  onChange={(e) => setEditUnitLabel(e.target.value)}
                  placeholder="Contoh: mulai Rp25.000 / 10 slide"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:border-amber-500"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingService(null)}
                  className="px-4 py-2 font-bold text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl"
                >
                  Simpan Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

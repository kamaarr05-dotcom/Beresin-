import React from 'react';
import { ShieldCheck, MessageSquare, Heart } from 'lucide-react';
import { BeresinDataStore } from '../lib/supabase';

interface FooterProps {
  onOpenSupabaseModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenSupabaseModal }) => {
  const currentYear = new Date().getFullYear();
  const paymentConfig = BeresinDataStore.getPaymentConfig();

  return (
    <footer className="mt-16 border-t border-slate-200 bg-white text-slate-600 text-xs py-10 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        
        {/* Brand & Slogan */}
        <div className="space-y-1.5 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2">
            <span className="font-black text-lg tracking-tight text-slate-900 font-display">
              BERESIN
            </span>
            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
              JASA TUGAS & SKRIPSI
            </span>
          </div>
          <p className="text-slate-500 max-w-sm">
            Platform pengerjaan tugas akademik, presentasi, excel, dan digital terpercaya untuk mahasiswa dan siswa se-Indonesia.
          </p>
        </div>

        {/* Links & Quick Actions */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-semibold text-slate-700">
          <button
            onClick={onOpenSupabaseModal}
            className="hover:text-slate-900 hover:underline flex items-center gap-1 transition-colors"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Info Database & Keamanan</span>
          </button>
          <span className="text-slate-300">•</span>
          <a
            href={BeresinDataStore.getWhatsAppLink('Halo Admin BERESIN, saya ingin konsultasi pengerjaan tugas.')}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-slate-900 hover:underline flex items-center gap-1 transition-colors"
          >
            <MessageSquare className="w-4 h-4 text-emerald-600" />
            <span>Bantuan WhatsApp: {paymentConfig.whatsapp_number}</span>
          </a>
        </div>

      </div>

      <div className="max-w-7xl mx-auto mt-8 pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-400 text-[11px]">
        <p>© {currentYear} BERESIN. All rights reserved.</p>
        <p className="flex items-center gap-1">
          <span>Dibuat dengan</span>
          <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
          <span>untuk membantu perkuliahanmu lebih tenang.</span>
        </p>
      </div>
    </footer>
  );
};

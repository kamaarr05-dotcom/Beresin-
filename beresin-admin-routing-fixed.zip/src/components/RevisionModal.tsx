import React, { useState } from 'react';
import { OrderItem } from '../types';
import { BeresinDataStore } from '../lib/supabase';
import { RefreshCw, X, CheckCircle2, AlertCircle } from 'lucide-react';

interface RevisionModalProps {
  isOpen: boolean;
  order: OrderItem | null;
  onClose: () => void;
  onSuccess: () => void;
}

export const RevisionModal: React.FC<RevisionModalProps> = ({
  isOpen,
  order,
  onClose,
  onSuccess,
}) => {
  const [revisionNotes, setRevisionNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen || !order) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!revisionNotes.trim()) {
      setErrorMsg('Harap tuliskan instruksi bagian mana yang ingin diperbaiki.');
      return;
    }

    setIsSubmitting(true);
    BeresinDataStore.requestRevision(order.id, revisionNotes.trim());
    setIsSubmitting(false);
    setSuccessMsg('Permintaan revisi berhasil dikirim! Admin akan segera memperbaikinya.');
    setTimeout(() => {
      onSuccess();
      onClose();
      setSuccessMsg('');
      setRevisionNotes('');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in slide-in-from-bottom sm:zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Drag handle */}
        <div className="pt-2.5 pb-1 sm:hidden flex justify-center">
          <div className="w-12 h-1.5 bg-slate-300 rounded-full" />
        </div>

        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-white">
          <div>
            <h3 className="text-base font-black text-slate-900 flex items-center gap-1.5">
              <RefreshCw className="w-4 h-4 text-purple-600" />
              <span>Pengajuan Revisi Tugas</span>
            </h3>
            <p className="text-[11px] text-slate-500">
              #{order.order_number} • {order.service_name}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full active:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-5 text-center space-y-2 bg-emerald-50 rounded-2xl border border-emerald-200">
              <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
              <p className="text-sm font-bold text-emerald-950">{successMsg}</p>
            </div>
          )}

          {!successMsg && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-purple-50/80 border border-purple-200 text-xs text-purple-950 space-y-1">
                <p className="font-bold">Garansi Revisi Tuntas</p>
                <p className="text-[11px] text-slate-600">
                  Tuliskan poin-poin yang perlu diperbaiki secara detail agar admin dapat langsung mengeksekusi revisi secara presisi.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Poin Koreksi / Revisi
                </label>
                <textarea
                  rows={4}
                  required
                  value={revisionNotes}
                  onChange={(e) => setRevisionNotes(e.target.value)}
                  placeholder="Contoh: Pada slide 4 tolong tambahkan grafik perbandingan, dan warna latar slide 7 diubah ke biru navy..."
                  className="w-full text-xs p-3 rounded-2xl border border-slate-300 focus:border-purple-500 outline-none resize-none"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 min-h-[48px] bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-black rounded-2xl text-xs shadow-md active:scale-98 transition-all"
                >
                  {isSubmitting ? 'Mengirim...' : 'Kirim Permintaan Revisi ke Admin'}
                </button>
              </div>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};

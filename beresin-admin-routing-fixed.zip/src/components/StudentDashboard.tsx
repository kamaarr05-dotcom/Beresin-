import React, { useState } from 'react';
import { OrderItem, OrderStatus } from '../types';
import { 
  Package, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  QrCode, 
  RefreshCw, 
  Download, 
  ChevronRight, 
  Filter, 
  Plus, 
  Sparkles,
  Percent,
  FileText
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { BeresinStorage } from '../lib/fileStorage';

interface StudentDashboardProps {
  orders: OrderItem[];
  onOpenOrderModal: () => void;
  onSelectOrder: (order: OrderItem) => void;
  onOpenPayment: (order: OrderItem) => void;
  onOpenRevision: (order: OrderItem) => void;
  onClaimVoucherModal: () => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  orders,
  onOpenOrderModal,
  onSelectOrder,
  onOpenPayment,
  onOpenRevision,
  onClaimVoucherModal,
}) => {
  const { currentUser } = useAuth();
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  const filteredOrders = orders.filter((order) => {
    if (filterStatus === 'ALL') return true;
    if (filterStatus === 'ACTIVE') {
      return ['MENUNGGU_HARGA', 'MENUNGGU_PEMBAYARAN', 'ANTRIAN', 'DIKERJAKAN', 'REVISI'].includes(order.status);
    }
    if (filterStatus === 'COMPLETED') {
      return order.status === 'SELESAI';
    }
    return true;
  });

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'MENUNGGU_HARGA':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
            Menunggu Peninjauan Harga
          </span>
        );
      case 'MENUNGGU_PEMBAYARAN':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-orange-100 text-orange-900 border border-orange-300 animate-pulse">
            Menunggu Pembayaran QRIS
          </span>
        );
      case 'ANTRIAN':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-sky-100 text-sky-900 border border-sky-300">
            Antrian Pengerjaan
          </span>
        );
      case 'DIKERJAKAN':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 text-indigo-900 border border-indigo-300">
            Sedang Dikerjakan
          </span>
        );
      case 'REVISI':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-900 border border-purple-300">
            Sedang Direvisi
          </span>
        );
      case 'SELESAI':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
            Selesai
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner: Welcome & Voucher Balance */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-amber-100 text-amber-800 text-[11px] font-black uppercase">
              Dashboard Siswa
            </span>
            <span className="text-xs text-slate-500 font-medium">Beresin Official</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Hai, {currentUser?.full_name || 'Mahasiswa'}!
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-xl">
            Pantau status pengerjaan tugasmu secara langsung. Semua file dan hasil tugas diunduh dengan aman di sini.
          </p>
        </div>

        {/* Voucher Balance Card */}
        <div className="bg-slate-900 text-white rounded-2xl p-4 border border-slate-800 flex items-center justify-between gap-6 shrink-0 shadow-sm">
          <div>
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">
              Saldo Vouchermu
            </span>
            <span className="text-xl sm:text-2xl font-black text-amber-400">
              Rp{(currentUser?.voucher_balance || 0).toLocaleString('id-ID')}
            </span>
          </div>
          <button
            onClick={onClaimVoucherModal}
            className="px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl text-xs transition-colors shadow-xs"
          >
            {currentUser?.voucher_balance && currentUser.voucher_balance > 0 ? 'Klaim Kode Lain' : 'Klaim Voucher'}
          </button>
        </div>
      </div>

      {/* Action Header: Filter & New Order Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setFilterStatus('ALL')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
              filterStatus === 'ALL'
                ? 'bg-slate-900 text-white'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Semua ({orders.length})
          </button>
          <button
            onClick={() => setFilterStatus('ACTIVE')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
              filterStatus === 'ACTIVE'
                ? 'bg-slate-900 text-white'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Sedang Berjalan ({orders.filter(o => o.status !== 'SELESAI').length})
          </button>
          <button
            onClick={() => setFilterStatus('COMPLETED')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
              filterStatus === 'COMPLETED'
                ? 'bg-slate-900 text-white'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Selesai ({orders.filter(o => o.status === 'SELESAI').length})
          </button>
        </div>

        <button
          onClick={onOpenOrderModal}
          className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl text-xs font-black flex items-center justify-center gap-2 shadow-sm transition-transform active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Buat Pesanan Baru</span>
        </button>
      </div>

      {/* Order List */}
      {filteredOrders.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
            <Package className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-slate-900">Belum Ada Pesanan</h3>
            <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto">
              Kamu belum memiliki pesanan dengan filter ini. Mulai pesan jasa tugas sekarang dengan potongan voucher!
            </p>
          </div>
          <button
            onClick={onOpenOrderModal}
            className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold inline-flex items-center gap-2"
          >
            <span>Pesan Tugas Pertama</span>
            <Plus className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredOrders.map((order) => (
            <div
              key={order.id}
              className="bg-white rounded-2xl border border-slate-200 hover:border-amber-400/80 p-5 transition-all shadow-xs hover:shadow-md flex flex-col justify-between space-y-4"
            >
              {/* Header Card */}
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="font-mono text-xs font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                    {order.order_number}
                  </span>
                  {getStatusBadge(order.status)}
                </div>

                <h3 className="text-base font-black text-slate-900">
                  {order.service_name}
                </h3>
                
                <p className="text-xs text-slate-500 line-clamp-2 mt-1">
                  {order.instructions}
                </p>
              </div>

              {/* Deadline & Pricing Info */}
              <div className="bg-slate-50 rounded-xl p-3 space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-slate-600">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-amber-500" />
                    <span>Deadline:</span>
                  </span>
                  <span className="font-semibold text-slate-800">
                    {new Date(order.deadline).toLocaleDateString('id-ID', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>

                {/* Negotiation Badge if active */}
                {order.negotiation_requested && (
                  <div className="flex items-center justify-between text-amber-800 font-semibold pt-1 border-t border-slate-200">
                    <span className="flex items-center gap-1">
                      <Percent className="w-3 h-3 text-amber-600" />
                      <span>Negosiasi:</span>
                    </span>
                    <span>
                      {order.negotiation_status === 'ACCEPTED' ? 'Disetujui Admin' :
                       order.negotiation_status === 'ADJUSTED' ? 'Disesuaikan Admin' :
                       order.negotiation_status === 'REJECTED' ? 'Ditolak (Harga Tetap)' :
                       'Diajukan (Menunggu Admin)'}
                    </span>
                  </div>
                )}

                <div className="flex items-center justify-between pt-1 border-t border-slate-200">
                  <span className="text-slate-600">Total Biaya:</span>
                  <span className="font-extrabold text-slate-900">
                    {order.final_price !== null ? `Rp${order.final_price.toLocaleString('id-ID')}` : `Mulai Rp${order.base_price.toLocaleString('id-ID')}`}
                  </span>
                </div>

                <div className="flex items-center justify-between text-emerald-600 font-semibold">
                  <span>Potongan Saldo Voucher:</span>
                  <span>-Rp{order.voucher_deduction.toLocaleString('id-ID')}</span>
                </div>

                <div className="flex items-center justify-between text-slate-900 font-black pt-1 border-t border-slate-200">
                  <span>Bayar Selisih:</span>
                  <span className={order.amount_to_pay === 0 ? 'text-emerald-600' : 'text-amber-600'}>
                    {order.final_price === null ? 'Menunggu Peninjauan' : order.amount_to_pay === 0 ? 'Rp0 (Lunas)' : `Rp${order.amount_to_pay.toLocaleString('id-ID')}`}
                  </span>
                </div>
              </div>

              {/* Action Buttons based on status */}
              <div className="flex items-center gap-2 pt-1">
                
                {/* 1. If Waiting for Payment -> Show QRIS Button */}
                {order.status === 'MENUNGGU_PEMBAYARAN' && (
                  <button
                    onClick={() => onOpenPayment(order)}
                    className="flex-1 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                  >
                    <QrCode className="w-4 h-4" />
                    <span>Bayar QRIS Rp{order.amount_to_pay.toLocaleString('id-ID')}</span>
                  </button>
                )}

                {/* 2. If Completed -> Show Download and Revision Button */}
                {order.status === 'SELESAI' && (
                  <>
                    <button
                      onClick={() => BeresinStorage.triggerDownload(order.result_file_url, order.result_file_name || 'Hasil_Pekerjaan.docx')}
                      className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                    >
                      <Download className="w-4 h-4" />
                      <span>Unduh Hasil</span>
                    </button>
                    <button
                      onClick={() => onOpenRevision(order)}
                      className="px-3 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1"
                    >
                      <RefreshCw className="w-3.5 h-3.5 text-purple-600" />
                      <span>Revisi</span>
                    </button>
                  </>
                )}

                {/* Always show View Details */}
                <button
                  onClick={() => onSelectOrder(order)}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors"
                >
                  <span>Detail</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>

              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};

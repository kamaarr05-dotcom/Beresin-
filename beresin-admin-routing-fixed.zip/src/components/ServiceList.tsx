import React from 'react';
import { ServiceItem } from '../types';
import { 
  Presentation, 
  Sheet, 
  FileText, 
  FileSearch, 
  Film, 
  Palette, 
  Headphones, 
  Database,
  ArrowRight,
  Tag,
  Smartphone,
  Globe,
  Wrench
} from 'lucide-react';

interface ServiceListProps {
  services: ServiceItem[];
  onSelectService: (service: ServiceItem) => void;
}

export const ServiceList: React.FC<ServiceListProps> = ({
  services,
  onSelectService,
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Presentation':
        return <Presentation className="w-6 h-6 text-amber-600" />;
      case 'Sheet':
        return <Sheet className="w-6 h-6 text-emerald-600" />;
      case 'FileText':
        return <FileText className="w-6 h-6 text-blue-600" />;
      case 'FileSearch':
        return <FileSearch className="w-6 h-6 text-rose-600" />;
      case 'Film':
        return <Film className="w-6 h-6 text-purple-600" />;
      case 'Palette':
        return <Palette className="w-6 h-6 text-pink-600" />;
      case 'Headphones':
        return <Headphones className="w-6 h-6 text-indigo-600" />;
      case 'Database':
        return <Database className="w-6 h-6 text-cyan-600" />;
      case 'Smartphone':
        return <Smartphone className="w-6 h-6 text-violet-600" />;
      case 'Globe':
        return <Globe className="w-6 h-6 text-sky-600" />;
      case 'Wrench':
        return <Wrench className="w-6 h-6 text-amber-700" />;
      default:
        return <FileText className="w-6 h-6 text-slate-600" />;
    }
  };

  return (
    <section className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 border-b border-slate-200 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-amber-100 text-amber-800 text-xs font-bold">Layanan Kami</span>
            <span className="text-xs text-slate-500 font-medium">Bisa Negosiasi Harga</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-1">
            Pilihan Layanan & Harga Jasa
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-slate-500 max-w-sm">
          Harga dasar transparan. Kamu juga bisa ajukan tawaran negosiasi harga saat memesan.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
        {services.filter(s => s.is_active).map((service) => (
          <div
            key={service.id}
            id={`service-card-${service.id}`}
            onClick={() => onSelectService(service)}
            className="group relative bg-white border border-slate-200 hover:border-amber-400/80 rounded-2xl p-4 sm:p-5 transition-all duration-200 hover:shadow-md hover:-translate-y-0.5 cursor-pointer flex flex-col justify-between"
          >
            <div>
              {/* Header Icon + Category */}
              <div className="flex items-start justify-between mb-3">
                <div className="w-11 h-11 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center group-hover:scale-105 transition-transform">
                  {getIcon(service.icon)}
                </div>
                <span className="text-[11px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">
                  {service.category}
                </span>
              </div>

              {/* Title & Description */}
              <h3 className="text-base font-bold text-slate-900 group-hover:text-amber-700 transition-colors">
                {service.name}
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed">
                {service.description}
              </p>
            </div>

            {/* Price Badge & Order Action */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Harga Mulai
                </span>
                <span className="text-sm sm:text-base font-extrabold text-slate-900">
                  Rp{service.base_price.toLocaleString('id-ID')}
                </span>
              </div>
              <div className="flex items-center gap-1 text-xs font-bold text-slate-900 group-hover:text-amber-600 transition-colors bg-slate-50 group-hover:bg-amber-50 px-2.5 py-1.5 rounded-lg border border-slate-200/60 group-hover:border-amber-300">
                <span>Pesan</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

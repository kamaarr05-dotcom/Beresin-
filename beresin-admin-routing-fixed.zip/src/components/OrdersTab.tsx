import React, { useState, useRef } from 'react';
import { OrderItem, OrderStatus } from '../types';
import { useAuth } from '../context/AuthContext';
import { 
  Layers, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Percent, 
  ChevronRight, 
  Plus, 
  QrCode, 
  Search, 
  Filter,
  ArrowRight,
  Sparkles,
  RefreshCw,
  X,
  UploadCloud,
  FileCheck,
  Download,
  Eye,
  Check,
  FileText
} from 'lucide-react';
import { OrderDetailSheet } from './OrderDetailSheet';
import { BeresinDataStore } from '../lib/supabase';
import { BeresinStorage } from '../lib/fileStorage';

interface OrdersTabProps {
  orders: OrderItem[];
  onRefreshData: () => void;
  onOpenNewOrder: () => void;
  onOpenQRIS: (order: OrderItem) => void;
  onOpenRevision: (order: OrderItem) => void;
}

export const OrdersTab: React.FC<OrdersTabProps> = ({
  orders,
  onRefreshData,
  onOpenNewOrder,
  onOpenQRIS,
  onOpenRevision,
}) => {
  const { currentUser, role } = useAuth();
  // Selected order for detailed view
  const [selectedOrder, setSelectedOrder] = useState<OrderItem | null>(null);
  // Filters
  const [filter, setFilter] = useState<'ALL' | 'ACTION_NEEDED' | 'IN_PROGRESS' | 'DONE'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Admin Action Bottom Sheets
  const [priceModalOrder, setPriceModalOrder] = useState<OrderItem | null>(null);
  const [finalPriceInput, setFinalPriceInput] = useState<number>(20000);
  const [negoDecision, setNegoDecision] = useState<'ACCEPT' | 'ADJUST' | 'REJECT'>('ACCEPT');
  const [adminNoteInput, setAdminNoteInput] = useState('');

  // Result Upload Bottom Sheet
  const [uploadResultOrder, setUploadResultOrder] = useState<OrderItem | null>(null);
  const [resultFileName, setResultFileName] = useState('');
  const [resultNotes, setResultNotes] = useState('');
  const [resultFile, setResultFile] = useState<File | null>(null);
  const [isUploadingResult, setIsUploadingResult] = useState(false);
  const [resultFileError, setResultFileError] = useState('');
  const [isDraggingResult, setIsDraggingResult] = useState(false);
  const resultFileInputRef = useRef<HTMLInputElement>(null);

  // Payment Proof Modal
  const [proofModalOrder, setProofModalOrder] = useState<OrderItem | null>(null);

  // Download state
  const [downloadingName, setDownloadingName] = useState<string | null>(null);

  // Filter orders according to role
  const roleOrders = role === 'ADMIN' 
    ? orders 
    : orders.filter((o) => o.student_id === currentUser?.id || o.student_email === currentUser?.email);

  const filteredOrders = roleOrders.filter((o) => {
    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchNumber = o.order_number.toLowerCase().includes(q);
      const matchService = o.service_name.toLowerCase().includes(q);
      const matchStudent = o.student_name.toLowerCase().includes(q);
      if (!matchNumber && !matchService && !matchStudent) return false;
    }

    if (filter === 'ACTION_NEEDED') {
      return o.status === 'MENUNGGU_HARGA' || o.status === 'MENUNGGU_PEMBAYARAN' || o.status === 'REVISI';
    }
    if (filter === 'IN_PROGRESS') {
      return o.status === 'ANTRIAN' || o.status === 'DIKERJAKAN';
    }
    if (filter === 'DONE') {
      return o.status === 'SELESAI';
    }
    return true;
  });

  const handleDownload = async (e: React.MouseEvent, url?: string, fileName?: string) => {
    e.stopPropagation();
    const target = fileName || 'Berkas_Beresin.docx';
    setDownloadingName(target);
    try {
      await BeresinStorage.triggerDownload(url, target);
    } catch (err) {
      console.error(err);
    } finally {
      setTimeout(() => setDownloadingName(null), 800);
    }
  };

  // Admin Set Price Handler
  const handleOpenSetPrice = (order: OrderItem) => {
    setPriceModalOrder(order);
    setFinalPriceInput(order.negotiation_requested && order.negotiation_price ? order.negotiation_price : order.base_price);
    setNegoDecision('ACCEPT');
    setAdminNoteInput('');
  };

  const handleSavePrice = () => {
    if (!priceModalOrder) return;
    const negoStatus = priceModalOrder.negotiation_requested
      ? (negoDecision === 'ACCEPT' ? 'ACCEPTED' : negoDecision === 'ADJUST' ? 'ADJUSTED' : 'REJECTED')
      : undefined;

    BeresinDataStore.setFinalPriceAndVoucher(
      priceModalOrder.id,
      finalPriceInput,
      negoStatus,
      adminNoteInput || undefined
    );
    const updatedId = priceModalOrder.id;
    setPriceModalOrder(null);
    onRefreshData();
    // If currently viewing in detail, update selectedOrder
    if (selectedOrder && selectedOrder.id === updatedId) {
      const updated = BeresinDataStore.getOrderById(updatedId);
      if (updated) setSelectedOrder(updated);
    }
  };

  // Admin Confirm QRIS Payment Handler
  const handleConfirmQRIS = (orderId: string) => {
    BeresinDataStore.confirmPayment(orderId);
    onRefreshData();
    if (selectedOrder && selectedOrder.id === orderId) {
      const updated = BeresinDataStore.getOrderById(orderId);
      if (updated) setSelectedOrder(updated);
    }
    if (proofModalOrder && proofModalOrder.id === orderId) {
      setProofModalOrder(null);
    }
  };

  // Admin Start Working Handler
  const handleStartWorking = (orderId: string) => {
    BeresinDataStore.updateOrderStatus(orderId, 'DIKERJAKAN');
    onRefreshData();
    if (selectedOrder && selectedOrder.id === orderId) {
      const updated = BeresinDataStore.getOrderById(orderId);
      if (updated) setSelectedOrder(updated);
    }
  };

  // Admin Upload Result Handler
  const handleOpenUploadResult = (order: OrderItem) => {
    setUploadResultOrder(order);
    setResultFile(null);
    setResultFileError('');
    setResultFileName(`${order.service_name.replace(/\s+/g, '_')}_Final.docx`);
    setResultNotes('Tugas telah selesai dikerjakan sesuai petunjuk.');
  };

  const handleSaveResult = async () => {
    if (!uploadResultOrder) return;
    setIsUploadingResult(true);
    setResultFileError('');
    try {
      let uploadedUrl = '';
      let finalName = resultFileName || 'Hasil_Pekerjaan.docx';
      if (resultFile) {
        const uploaded = await BeresinStorage.uploadFile(resultFile);
        uploadedUrl = uploaded.fileUrl;
        finalName = resultFileName || uploaded.fileName;
      }

      BeresinDataStore.completeOrder(
        uploadResultOrder.id,
        finalName,
        resultNotes || undefined,
        uploadedUrl
      );
      const targetId = uploadResultOrder.id;
      setUploadResultOrder(null);
      setResultFile(null);
      setIsUploadingResult(false);
      onRefreshData();
      if (selectedOrder && selectedOrder.id === targetId) {
        const updated = BeresinDataStore.getOrderById(targetId);
        if (updated) setSelectedOrder(updated);
      }
    } catch (err) {
      console.error(err);
      setResultFileError('Gagal mengunggah berkas hasil. Silakan coba lagi.');
      setIsUploadingResult(false);
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-150">
      
      {/* If an order is selected, show detail sheet */}
      {selectedOrder ? (
        <OrderDetailSheet
          order={selectedOrder}
          onBack={() => {
            setSelectedOrder(null);
            onRefreshData();
          }}
          onOpenPayment={(o) => onOpenQRIS(o)}
          onOpenRevision={(o) => onOpenRevision(o)}
          onAdminSetPrice={handleOpenSetPrice}
          onAdminConfirmPayment={handleConfirmQRIS}
          onAdminStartWorking={handleStartWorking}
          onAdminUploadResult={handleOpenUploadResult}
          onViewProof={(o) => setProofModalOrder(o)}
        />
      ) : (
        /* Order List View */
        <>
          {/* HEADER SECTION WITH NEW ORDER CTA */}
          <div className="flex items-center justify-between px-1">
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                {role === 'ADMIN' ? 'Semua Pesanan Siswa' : 'Daftar Pesanan Saya'}
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                {role === 'ADMIN' 
                  ? `${filteredOrders.length} pesanan ditemukan`
                  : 'Pantau status dan unduh hasil tugasmu'}
              </p>
            </div>
            {role === 'STUDENT' && (
              <button
                onClick={onOpenNewOrder}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-2xl text-xs font-black shadow-xs active:scale-95 transition-transform"
              >
                <Plus className="w-4 h-4" />
                <span>Pesan Baru</span>
              </button>
            )}
          </div>

          {/* SEARCH BAR FOR ADMIN */}
          {role === 'ADMIN' && (
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari pesanan, siswa, atau layanan..."
                className="w-full pl-9 pr-3 py-2.5 bg-white text-xs rounded-2xl border border-slate-200 focus:border-amber-500 outline-none"
              />
            </div>
          )}

          {/* FILTER TABS */}
          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar text-xs">
            <button
              onClick={() => setFilter('ALL')}
              className={`px-3 py-1.5 rounded-full font-bold whitespace-nowrap transition-colors ${
                filter === 'ALL'
                  ? 'bg-slate-950 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              Semua ({roleOrders.length})
            </button>
            <button
              onClick={() => setFilter('ACTION_NEEDED')}
              className={`px-3 py-1.5 rounded-full font-bold whitespace-nowrap transition-colors ${
                filter === 'ACTION_NEEDED'
                  ? 'bg-amber-400 text-slate-950'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              Perlu Tindakan
            </button>
            <button
              onClick={() => setFilter('IN_PROGRESS')}
              className={`px-3 py-1.5 rounded-full font-bold whitespace-nowrap transition-colors ${
                filter === 'IN_PROGRESS'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              Diproses
            </button>
            <button
              onClick={() => setFilter('DONE')}
              className={`px-3 py-1.5 rounded-full font-bold whitespace-nowrap transition-colors ${
                filter === 'DONE'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              Selesai
            </button>
          </div>

          {/* EMPTY STATE */}
          {filteredOrders.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
                <Layers className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-black text-slate-900">Belum Ada Pesanan</h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                {role === 'ADMIN'
                  ? 'Tidak ada pesanan yang sesuai dengan filter atau kata kunci pencarian.'
                  : 'Gunakan saldo vouchermu untuk membuat pesanan tugas pertama sekarang juga.'}
              </p>
              {role === 'STUDENT' && (
                <button
                  onClick={onOpenNewOrder}
                  className="px-4 py-2 bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-xs"
                >
                  Buat Pesanan Pertama
                </button>
              )}
            </div>
          ) : (
            /* ORDERS LIST */
            <div className="space-y-3">
              {filteredOrders.map((order) => (
                <div
                  key={order.id}
                  onClick={() => setSelectedOrder(order)}
                  className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs hover:border-amber-300 transition-all cursor-pointer space-y-3 active:scale-99"
                >
                  {/* Card Header */}
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[11px] font-bold text-slate-400">
                      {order.order_number}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                      order.status === 'MENUNGGU_HARGA' ? 'bg-amber-100 text-amber-900 border border-amber-300' :
                      order.status === 'MENUNGGU_PEMBAYARAN' ? 'bg-orange-100 text-orange-900 border border-orange-300 animate-pulse' :
                      order.status === 'ANTRIAN' ? 'bg-sky-100 text-sky-900' :
                      order.status === 'DIKERJAKAN' ? 'bg-indigo-100 text-indigo-900' :
                      order.status === 'REVISI' ? 'bg-purple-100 text-purple-900' :
                      'bg-emerald-100 text-emerald-900'
                    }`}>
                      {order.status.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Service & Student info */}
                  <div>
                    <h3 className="text-sm font-black text-slate-900 tracking-tight">
                      {order.service_name}
                    </h3>
                    {role === 'ADMIN' && (
                      <p className="text-[11px] text-slate-500 font-semibold mt-0.5">
                        Pemesan: {order.student_name} ({order.student_whatsapp})
                      </p>
                    )}
                    <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>
                        Deadline: {new Date(order.deadline).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </p>
                  </div>

                  {/* Attached Student File Pill */}
                  {order.file_name && (
                    <div className="flex items-center justify-between p-2 bg-slate-50 rounded-xl border border-slate-200 text-[11px]">
                      <div className="flex items-center gap-1.5 overflow-hidden text-slate-700">
                        <FileText className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        <span className="truncate font-semibold">{order.file_name}</span>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => handleDownload(e, order.file_url, order.file_name)}
                        className="px-2 py-0.5 text-[10px] font-bold bg-white border border-slate-300 rounded-md text-slate-700 shrink-0 hover:bg-slate-100"
                      >
                        {downloadingName === order.file_name ? '...' : 'Unduh'}
                      </button>
                    </div>
                  )}

                  {/* Negotiation Alert Pill if pending */}
                  {order.negotiation_requested && (
                    <div className="p-2 bg-amber-50 rounded-xl border border-amber-200/80 text-[11px] text-amber-950 flex items-center justify-between">
                      <span className="flex items-center gap-1 font-semibold">
                        <Percent className="w-3 h-3 text-amber-600" />
                        <span>Nego Diajukan: Rp{order.negotiation_price?.toLocaleString('id-ID')}</span>
                      </span>
                      <span className="font-extrabold text-[10px] uppercase">
                        {order.negotiation_status}
                      </span>
                    </div>
                  )}

                  {/* Payment Proof Notification Pill */}
                  {order.payment_proof_name && (
                    <div className="p-2 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-950 flex items-center justify-between">
                      <span className="flex items-center gap-1 font-bold">
                        <FileCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Bukti Transfer Tersedia</span>
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setProofModalOrder(order);
                        }}
                        className="px-2 py-0.5 text-[10px] font-black bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
                      >
                        Lihat Bukti
                      </button>
                    </div>
                  )}

                  {/* Pricing & Footer Row */}
                  <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block leading-none">Biaya:</span>
                      <span className="text-xs font-black text-slate-900">
                        {order.final_price !== null 
                          ? (order.amount_to_pay === 0 ? 'Rp0 (LUNAS/VOUCHER)' : `Rp${order.amount_to_pay.toLocaleString('id-ID')}`)
                          : `Dasar Rp${order.base_price.toLocaleString('id-ID')}`}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-500">Detail</span>
                      <ChevronRight className="w-4 h-4 text-slate-400" />
                    </div>
                  </div>

                  {/* DIRECT ACTIONS ON CARD FOR STUDENT */}
                  {role === 'STUDENT' && (
                    <>
                      {order.status === 'MENUNGGU_PEMBAYARAN' && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenQRIS(order);
                          }}
                          className="w-full py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-xs"
                        >
                          <QrCode className="w-4 h-4" />
                          <span>Bayar QRIS Rp{order.amount_to_pay.toLocaleString('id-ID')}</span>
                        </button>
                      )}
                      {order.status === 'SELESAI' && (
                        <button
                          type="button"
                          onClick={(e) => handleDownload(e, order.result_file_url, order.result_file_name || 'Hasil_Pekerjaan.docx')}
                          disabled={downloadingName === (order.result_file_name || 'Hasil_Pekerjaan.docx')}
                          className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-xs"
                        >
                          <Download className="w-4 h-4" />
                          <span>
                            {downloadingName === (order.result_file_name || 'Hasil_Pekerjaan.docx')
                              ? 'Mengunduh...'
                              : `Unduh Berkas: ${order.result_file_name || 'Hasil Tugas'}`}
                          </span>
                        </button>
                      )}
                    </>
                  )}

                  {/* DIRECT ACTIONS ON CARD FOR ADMIN */}
                  {role === 'ADMIN' && (
                    <div className="pt-1 flex flex-col gap-1.5">
                      {order.status === 'MENUNGGU_HARGA' && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenSetPrice(order);
                          }}
                          className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-xs"
                        >
                          <span>Tentukan Harga & Respon Nego</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {order.status === 'MENUNGGU_PEMBAYARAN' && (
                        <div className="flex gap-2">
                          {order.payment_proof_name && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setProofModalOrder(order);
                              }}
                              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>Bukti</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleConfirmQRIS(order.id);
                            }}
                            className="flex-1 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-xs"
                          >
                            <Check className="w-4 h-4" />
                            <span>Konfirmasi QRIS Masuk</span>
                          </button>
                        </div>
                      )}
                      {order.status === 'ANTRIAN' && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleStartWorking(order.id);
                          }}
                          className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-xs"
                        >
                          <Sparkles className="w-4 h-4" />
                          <span>Mulai Kerjakan Tugas</span>
                        </button>
                      )}
                      {(order.status === 'DIKERJAKAN' || order.status === 'REVISI') && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenUploadResult(order);
                          }}
                          className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-xs"
                        >
                          <FileCheck className="w-4 h-4" />
                          <span>{order.status === 'REVISI' ? 'Upload Hasil Revisi & Selesaikan' : 'Upload Berkas Hasil & Selesaikan'}</span>
                        </button>
                      )}
                      {order.status === 'SELESAI' && (
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={(e) => handleDownload(e, order.result_file_url, order.result_file_name || 'Hasil_Pekerjaan.docx')}
                            disabled={downloadingName === (order.result_file_name || 'Hasil_Pekerjaan.docx')}
                            className="flex-1 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>{downloadingName === (order.result_file_name || 'Hasil_Pekerjaan.docx') ? 'Mengunduh...' : 'Unduh Berkas'}</span>
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenUploadResult(order);
                            }}
                            className="px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 rounded-xl text-xs font-bold"
                          >
                            Update
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* BOTTOM SHEET 1: ADMIN SET PRICE & NEGO */}
      {priceModalOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 space-y-4 animate-in slide-in-from-bottom duration-200">
            {/* Sheet Handle */}
            <div className="w-10 h-1 bg-slate-300 rounded-full mx-auto sm:hidden" />
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-slate-900">
                Tentukan Harga & Respon Nego
              </h3>
              <button
                type="button"
                onClick={() => setPriceModalOrder(null)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl text-xs space-y-1">
              <p className="font-bold text-slate-900">{priceModalOrder.service_name}</p>
              <p className="text-slate-500">Harga dasar: Rp{priceModalOrder.base_price.toLocaleString('id-ID')}</p>
              {priceModalOrder.negotiation_requested && (
                <p className="text-amber-900 font-bold">
                  Siswa Mengajukan: Rp{priceModalOrder.negotiation_price?.toLocaleString('id-ID')}
                  <br />
                  <span className="font-normal italic">"{priceModalOrder.negotiation_reason}"</span>
                </p>
              )}
            </div>

            {priceModalOrder.negotiation_requested && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Keputusan Negosiasi
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setNegoDecision('ACCEPT');
                      if (priceModalOrder.negotiation_price) {
                        setFinalPriceInput(priceModalOrder.negotiation_price);
                      }
                    }}
                    className={`py-2 rounded-xl text-xs font-bold ${
                      negoDecision === 'ACCEPT' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    Terima Nego
                  </button>
                  <button
                    type="button"
                    onClick={() => setNegoDecision('ADJUST')}
                    className={`py-2 rounded-xl text-xs font-bold ${
                      negoDecision === 'ADJUST' ? 'bg-amber-400 text-slate-950 font-black' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    Sesuaikan
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setNegoDecision('REJECT');
                      setFinalPriceInput(priceModalOrder.base_price);
                    }}
                    className={`py-2 rounded-xl text-xs font-bold ${
                      negoDecision === 'REJECT' ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    Tolak Nego
                  </button>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Harga Final (Rp)
              </label>
              <input
                type="number"
                value={finalPriceInput}
                onChange={(e) => setFinalPriceInput(Number(e.target.value))}
                step="5000"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-black outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Catatan untuk Siswa (Opsional)
              </label>
              <textarea
                value={adminNoteInput}
                onChange={(e) => setAdminNoteInput(e.target.value)}
                placeholder="Contoh: Harga disetujui karena pengerjaan standar."
                rows={2}
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs outline-none"
              />
            </div>

            <button
              type="button"
              onClick={handleSavePrice}
              className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-black rounded-2xl text-xs shadow-md"
            >
              Simpan & Terapkan Potongan Voucher
            </button>
          </div>
        </div>
      )}

      {/* BOTTOM SHEET 2: ADMIN UPLOAD RESULT */}
      {uploadResultOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 space-y-4 animate-in slide-in-from-bottom duration-200 max-h-[90vh] overflow-y-auto">
            <div className="w-10 h-1 bg-slate-300 rounded-full mx-auto sm:hidden" />
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-black text-slate-900">
                  {uploadResultOrder.status === 'REVISI' ? 'Upload Hasil Revisi' : 'Upload Berkas Hasil Jadi'}
                </h3>
                <p className="text-[11px] text-slate-500">#{uploadResultOrder.order_number} • {uploadResultOrder.service_name}</p>
              </div>
              <button
                type="button"
                onClick={() => setUploadResultOrder(null)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {resultFileError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{resultFileError}</span>
              </div>
            )}

            {/* Real File Upload Section */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Pilih Berkas Tugas (.docx, .pdf, .zip, .xlsx, dll)
              </label>
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDraggingResult(true);
                }}
                onDragLeave={() => setIsDraggingResult(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDraggingResult(false);
                  if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                    const dropped = e.dataTransfer.files[0];
                    setResultFile(dropped);
                    setResultFileName(dropped.name);
                  }
                }}
                onClick={() => resultFileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-4 text-center cursor-pointer transition-colors ${
                  isDraggingResult
                    ? 'border-emerald-500 bg-emerald-50/50'
                    : resultFile
                    ? 'border-emerald-500 bg-emerald-50/30'
                    : 'border-slate-300 hover:border-emerald-400 bg-slate-50/50'
                }`}
              >
                <input
                  ref={resultFileInputRef}
                  type="file"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      const selected = e.target.files[0];
                      setResultFile(selected);
                      setResultFileName(selected.name);
                    }
                  }}
                />

                {resultFile ? (
                  <div className="flex items-center justify-between p-2 bg-white rounded-xl border border-emerald-200">
                    <div className="flex items-center gap-2 text-emerald-900 text-xs font-semibold truncate">
                      <FileCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                      <span className="truncate">{resultFile.name}</span>
                      <span className="text-emerald-700 font-normal text-[10px] shrink-0">
                        ({(resultFile.size / 1024).toFixed(0)} KB)
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setResultFile(null);
                        if (resultFileInputRef.current) resultFileInputRef.current.value = '';
                      }}
                      className="p-1 text-rose-500 hover:text-rose-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <UploadCloud className="w-6 h-6 text-slate-400 mx-auto" />
                    <p className="text-xs font-bold text-slate-700">
                      Klik untuk memilih berkas atau seret ke sini
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Format bebas: Word, PDF, Excel, PPT, Zip arsip, dll.
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Judul / Label Berkas
              </label>
              <input
                type="text"
                value={resultFileName}
                onChange={(e) => setResultFileName(e.target.value)}
                placeholder="Hasil_Tugas.docx"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Pesan / Catatan Pengerjaan untuk Siswa
              </label>
              <textarea
                value={resultNotes}
                onChange={(e) => setResultNotes(e.target.value)}
                rows={2}
                placeholder="Tuliskan catatan format pengerjaan atau pesan ramah..."
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs outline-none"
              />
            </div>

            <button
              type="button"
              disabled={isUploadingResult}
              onClick={handleSaveResult}
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black rounded-2xl text-xs shadow-md flex items-center justify-center gap-2"
            >
              <FileCheck className="w-4 h-4" />
              <span>{isUploadingResult ? 'Mengunggah & Menyimpan Berkas...' : 'Kirim Hasil & Tandai Selesai'}</span>
            </button>
          </div>
        </div>
      )}

      {/* MODAL 3: PAYMENT PROOF PREVIEW */}
      {proofModalOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-sm rounded-3xl p-5 space-y-4 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div>
                <h3 className="text-sm font-black text-slate-900">Bukti Transfer Siswa</h3>
                <p className="text-[11px] text-slate-500">#{proofModalOrder.order_number} • {proofModalOrder.student_name}</p>
              </div>
              <button
                type="button"
                onClick={() => setProofModalOrder(null)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-2xl border border-slate-200 overflow-hidden bg-slate-50 flex items-center justify-center min-h-[160px] max-h-[300px]">
              {proofModalOrder.payment_proof_url && (proofModalOrder.payment_proof_url.startsWith('data:image') || proofModalOrder.payment_proof_url.startsWith('blob:') || proofModalOrder.payment_proof_url.startsWith('http')) ? (
                <img
                  src={proofModalOrder.payment_proof_url}
                  alt="Bukti Transfer"
                  className="w-full h-auto object-contain max-h-[280px]"
                />
              ) : (
                <div className="p-6 text-center space-y-2">
                  <FileCheck className="w-10 h-10 text-emerald-600 mx-auto" />
                  <p className="text-xs font-bold text-slate-800">{proofModalOrder.payment_proof_name || 'bukti_transfer.jpg'}</p>
                  <p className="text-[10px] text-slate-400">Bukti tersimpan aman di sistem</p>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={(e) => handleDownload(e, proofModalOrder.payment_proof_url, proofModalOrder.payment_proof_name || 'bukti_transfer.jpg')}
                className="px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 flex-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh Bukti</span>
              </button>
              {role === 'ADMIN' && proofModalOrder.status === 'MENUNGGU_PEMBAYARAN' && (
                <button
                  type="button"
                  onClick={() => handleConfirmQRIS(proofModalOrder.id)}
                  className="py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 flex-2 shadow-xs"
                >
                  <Check className="w-4 h-4" />
                  <span>Konfirmasi Pembayaran</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

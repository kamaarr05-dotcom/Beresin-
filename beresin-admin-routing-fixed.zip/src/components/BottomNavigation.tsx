import React from 'react';
import { Home, Layers, Ticket, User, ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export type MobileTab = 'beranda' | 'pesanan' | 'voucher' | 'profil';

interface BottomNavigationProps {
  activeTab: MobileTab;
  onChangeTab: (tab: MobileTab) => void;
  activeOrdersCount: number;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  activeTab,
  onChangeTab,
  activeOrdersCount,
}) => {
  const { currentUser, role } = useAuth();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-slate-200/90 shadow-[0_-4px_16px_rgba(0,0,0,0.04)]">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-around">
        
        {/* TAB 1: BERANDA */}
        <button
          id="mobile-tab-beranda"
          onClick={() => onChangeTab('beranda')}
          className={`flex flex-col items-center justify-center w-16 h-full gap-0.5 transition-all ${
            activeTab === 'beranda'
              ? 'text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <div className="relative">
            <Home className={`w-5 h-5 transition-transform ${activeTab === 'beranda' ? 'scale-110 text-amber-500' : ''}`} />
          </div>
          <span className="text-[11px] leading-tight">Beranda</span>
          {activeTab === 'beranda' && (
            <span className="w-1 h-1 rounded-full bg-amber-500 mt-0.5" />
          )}
        </button>

        {/* TAB 2: PESANAN */}
        <button
          id="mobile-tab-pesanan"
          onClick={() => onChangeTab('pesanan')}
          className={`flex flex-col items-center justify-center w-16 h-full gap-0.5 transition-all ${
            activeTab === 'pesanan'
              ? 'text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <div className="relative">
            <Layers className={`w-5 h-5 transition-transform ${activeTab === 'pesanan' ? 'scale-110 text-amber-500' : ''}`} />
            {activeOrdersCount > 0 && (
              <span className="absolute -top-1 -right-2 min-w-4 h-4 px-1 bg-amber-500 text-slate-950 text-[10px] font-black rounded-full flex items-center justify-center border border-white">
                {activeOrdersCount}
              </span>
            )}
          </div>
          <span className="text-[11px] leading-tight">
            {role === 'ADMIN' ? 'Pesanan' : 'Pesanan'}
          </span>
          {activeTab === 'pesanan' && (
            <span className="w-1 h-1 rounded-full bg-amber-500 mt-0.5" />
          )}
        </button>

        {/* TAB 3: VOUCHER */}
        <button
          id="mobile-tab-voucher"
          onClick={() => onChangeTab('voucher')}
          className={`flex flex-col items-center justify-center w-16 h-full gap-0.5 transition-all ${
            activeTab === 'voucher'
              ? 'text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <div className="relative">
            <Ticket className={`w-5 h-5 transition-transform ${activeTab === 'voucher' ? 'scale-110 text-amber-500' : ''}`} />
            {currentUser?.role === 'STUDENT' && (
              <span className="absolute -top-1 -right-3 px-1 py-0.2 bg-amber-100 text-amber-900 text-[8px] font-extrabold rounded-full border border-amber-300">
                {(currentUser.voucher_balance / 1000).toFixed(0)}k
              </span>
            )}
          </div>
          <span className="text-[11px] leading-tight">Voucher</span>
          {activeTab === 'voucher' && (
            <span className="w-1 h-1 rounded-full bg-amber-500 mt-0.5" />
          )}
        </button>

        {/* TAB 4: PROFIL */}
        <button
          id="mobile-tab-profil"
          onClick={() => onChangeTab('profil')}
          className={`flex flex-col items-center justify-center w-16 h-full gap-0.5 transition-all ${
            activeTab === 'profil'
              ? 'text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-600 font-medium'
          }`}
        >
          <div className="relative">
            {role === 'ADMIN' ? (
              <ShieldAlert className={`w-5 h-5 transition-transform ${activeTab === 'profil' ? 'scale-110 text-amber-500' : ''}`} />
            ) : (
              <User className={`w-5 h-5 transition-transform ${activeTab === 'profil' ? 'scale-110 text-amber-500' : ''}`} />
            )}
          </div>
          <span className="text-[11px] leading-tight">
            {role === 'ADMIN' ? 'Admin' : 'Profil'}
          </span>
          {activeTab === 'profil' && (
            <span className="w-1 h-1 rounded-full bg-amber-500 mt-0.5" />
          )}
        </button>

      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { 
  OrderItem, 
  OrderStatus 
} from '../types';
import { 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Download, 
  RefreshCw, 
  QrCode, 
  FileText, 
  ArrowLeft, 
  Percent,
  Check,
  ShieldCheck,
  MessageSquare,
  Sparkles,
  Eye,
  FileCheck
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { BeresinStorage } from '../lib/fileStorage';

interface OrderDetailSheetProps {
  order: OrderItem;
  onBack: () => void;
  onOpenPayment: (order: OrderItem) => void;
  onOpenRevision: (order: OrderItem) => void;
  onAdminSetPrice?: (order: OrderItem) => void;
  onAdminConfirmPayment?: (orderId: string) => void;
  onAdminStartWorking?: (orderId: string) => void;
  onAdminUploadResult?: (order: OrderItem) => void;
  onViewProof?: (order: OrderItem) => void;
}

export const OrderDetailSheet: React.FC<OrderDetailSheetProps> = ({
  order,
  onBack,
  onOpenPayment,
  onOpenRevision,
  onAdminSetPrice,
  onAdminConfirmPayment,
  onAdminStartWorking,
  onAdminUploadResult,
  onViewProof,
}) => {
  const { role } = useAuth();
  const [downloading, setDownloading] = useState<string | null>(null);

  const handleDownload = async (url?: string, filename?: string) => {
    const targetName = filename || 'Berkas_Beresin.docx';
    setDownloading(targetName);
    try {
      await BeresinStorage.triggerDownload(url, targetName);
    } catch (err) {
      console.error(err);
    } finally {
      setTimeout(() => setDownloading(null), 800);
    }
  };

  // Status Stepper definition
  const steps: { key: OrderStatus; label: string }[] = [
    { key: 'MENUNGGU_HARGA', label: 'Tinjau Harga' },
    { key: 'MENUNGGU_PEMBAYARAN', label: 'Pembayaran' },
    { key: 'ANTRIAN', label: 'Antrian' },
    { key: 'DIKERJAKAN', label: 'Dikerjakan' },
    { key: 'SELESAI', label: 'Selesai' },
  ];

  const getStepIndex = (status: OrderStatus) => {
    switch (status) {
      case 'MENUNGGU_HARGA': return 0;
      case 'MENUNGGU_PEMBAYARAN': return 1;
      case 'ANTRIAN': return 2;
      case 'DIKERJAKAN': return 3;
      case 'REVISI': return 3; // during revision, it's being worked on
      case 'SELESAI': return 4;
      default: return 0;
    }
  };

  const currentStepIdx = getStepIndex(order.status);

  return (
    <div className="space-y-4 pb-20 animate-in fade-in slide-in-from-right duration-200">
      
      {/* Top Header Card */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-mono text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-lg">
            {order.order_number}
          </span>
          <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
            order.status === 'MENUNGGU_HARGA' ? 'bg-amber-100 text-amber-900 border border-amber-300' :
            order.status === 'MENUNGGU_PEMBAYARAN' ? 'bg-orange-100 text-orange-900 border border-orange-300 animate-pulse' :
            order.status === 'ANTRIAN' ? 'bg-sky-100 text-sky-900 border border-sky-300' :
            order.status === 'DIKERJAKAN' ? 'bg-indigo-100 text-indigo-900 border border-indigo-300' :
            order.status === 'REVISI' ? 'bg-purple-100 text-purple-900 border border-purple-300' :
            'bg-emerald-100 text-emerald-900 border border-emerald-300'
          }`}>
            {order.status.replace('_', ' ')}
          </span>
        </div>

        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {order.service_name}
          </h2>
          <p className="text-xs text-slate-500 flex items-center gap-1 mt-1">
            <Clock className="w-3.5 h-3.5 text-amber-500" />
            <span>
              Deadline: {new Date(order.deadline).toLocaleDateString('id-ID', {
                weekday: 'long',
                day: 'numeric',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </span>
          </p>
        </div>

        {/* Mobile Stepper Progress Bar */}
        <div className="pt-3 border-t border-slate-100">
          <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 mb-1.5 px-0.5">
            {steps.map((s, idx) => (
              <span 
                key={s.key} 
                className={idx <= currentStepIdx ? 'text-amber-700 font-extrabold' : ''}
              >
                {s.label}
              </span>
            ))}
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden flex">
            <div 
              className="h-full bg-gradient-to-r from-amber-400 to-amber-500 rounded-full transition-all duration-300"
              style={{ width: `${((currentStepIdx + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* ADMIN VIEW: Student Info & Direct WhatsApp Chat */}
      {role === 'ADMIN' && (
        <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-950 font-black text-sm flex items-center justify-center shrink-0">
              {order.student_name ? order.student_name.charAt(0).toUpperCase() : 'S'}
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-black text-slate-900 truncate">
                {order.student_name}
              </p>
              <p className="text-[11px] text-slate-500 truncate">
                {order.student_whatsapp}
              </p>
            </div>
          </div>
          <a
            href={`https://wa.me/${order.student_whatsapp.replace(/[^0-9]/g, '')}?text=Halo%20${encodeURIComponent(order.student_name)},%20kami%20dari%20Admin%20BERESIN%20mengenai%20pesanan%20${order.order_number}%20(${encodeURIComponent(order.service_name)})`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 shadow-xs"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Chat WA</span>
          </a>
        </div>
      )}

      {/* Negotiation Card if applicable */}
      {order.negotiation_requested && (
        <div className="bg-amber-50/80 rounded-3xl p-4 border border-amber-200 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-amber-950 flex items-center gap-1.5">
              <Percent className="w-4 h-4 text-amber-600" />
              <span>Pengajuan Negosiasi Harga</span>
            </span>
            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-200/80 text-amber-950">
              {order.negotiation_status === 'ACCEPTED' ? '✓ DITERIMA' : 
               order.negotiation_status === 'ADJUSTED' ? '⚡ DISESUAIKAN' : 
               order.negotiation_status === 'REJECTED' ? '✕ DITOLAK' : 
               'MENUNGGU RESPON'}
            </span>
          </div>
          <p className="text-slate-700">
            Diajukan: <strong className="text-amber-900">Rp{order.negotiation_price?.toLocaleString('id-ID')}</strong>
            <br />
            Alasan: <em>"{order.negotiation_reason}"</em>
          </p>
          {order.admin_negotiation_note && (
            <p className="text-[11px] text-amber-900 bg-white/70 p-2 rounded-xl border border-amber-200">
              <strong>Catatan Admin:</strong> {order.admin_negotiation_note}
            </p>
          )}
        </div>
      )}

      {/* Instructions & Uploaded File Card */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
          Instruksi Pengerjaan
        </h3>
        <p className="text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
          {order.instructions}
        </p>
        {order.file_name && (
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2 overflow-hidden text-xs">
              <FileText className="w-4 h-4 text-slate-500 shrink-0" />
              <span className="truncate font-semibold text-slate-700">{order.file_name}</span>
            </div>
            <button
              type="button"
              onClick={() => handleDownload(order.file_url, order.file_name)}
              disabled={downloading === order.file_name}
              className="px-3 py-1.5 text-[11px] font-bold bg-white hover:bg-slate-50 border border-slate-300 rounded-xl text-slate-700 shrink-0 flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>{downloading === order.file_name ? 'Mengunduh...' : 'Unduh'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Pricing & Voucher Card */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
          Rincian Biaya & Voucher
        </h3>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between text-slate-600">
            <span>Harga Dasar Layanan:</span>
            <span>Rp{order.base_price.toLocaleString('id-ID')}</span>
          </div>
          <div className="flex justify-between text-slate-900 font-bold">
            <span>Harga Final Ditentukan:</span>
            <span>
              {order.final_price !== null ? `Rp${order.final_price.toLocaleString('id-ID')}` : 'Menunggu kalkulasi...'}
            </span>
          </div>
          <div className="flex justify-between text-emerald-600 font-bold">
            <span>Potongan Saldo Voucher:</span>
            <span>-Rp{order.voucher_deduction.toLocaleString('id-ID')}</span>
          </div>
          <div className="pt-3 border-t border-slate-100 flex justify-between items-center text-sm font-black">
            <span className="text-slate-900">Total Harus Dibayar:</span>
            <span className={`text-base ${order.amount_to_pay === 0 ? 'text-emerald-600' : 'text-amber-600'}`}>
              {order.final_price === null ? '-' : order.amount_to_pay === 0 ? 'Rp0 (LUNAS/GRATIS)' : `Rp${order.amount_to_pay.toLocaleString('id-ID')}`}
            </span>
          </div>
        </div>
        {order.payment_confirmed && (
          <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900 flex items-center gap-1.5 font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Pembayaran Terkonfirmasi Lunas</span>
          </div>
        )}
      </div>

      {/* Payment Proof Card if Uploaded */}
      {(order.payment_proof_name || order.payment_proof_url) && (
        <div className="bg-amber-50/70 rounded-3xl p-5 border border-amber-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-950 font-bold text-xs">
              <FileCheck className="w-4 h-4 text-amber-600" />
              <span>Bukti Transfer Pembayaran</span>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-200/70 text-amber-900">
              {order.payment_confirmed ? 'Sudah Diverifikasi' : 'Menunggu Verifikasi Admin'}
            </span>
          </div>
          <p className="text-[11px] text-slate-600 truncate">
            Berkas: <strong>{order.payment_proof_name || 'bukti_transfer.jpg'}</strong>
          </p>
          <div className="flex gap-2 pt-1">
            {onViewProof && (
              <button
                type="button"
                onClick={() => onViewProof(order)}
                className="flex-1 py-2 bg-white hover:bg-amber-100 text-amber-950 border border-amber-300 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Lihat Bukti Foto</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => handleDownload(order.payment_proof_url, order.payment_proof_name || 'bukti_transfer.jpg')}
              className="px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh</span>
            </button>
          </div>
        </div>
      )}

      {/* Result Card if Finished */}
      {order.status === 'SELESAI' && (
        <div className="bg-emerald-50/70 rounded-3xl p-5 border border-emerald-200 space-y-3">
          <div className="flex items-center gap-2 text-emerald-950 font-black">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span>Pekerjaan Telah Selesai!</span>
          </div>
          {order.result_notes && (
            <p className="text-xs text-slate-700 bg-white p-3 rounded-2xl border border-emerald-100">
              <strong>Catatan Admin:</strong> {order.result_notes}
            </p>
          )}
          <div className="flex flex-col gap-2 pt-1">
            <button
              type="button"
              onClick={() => handleDownload(order.result_file_url, order.result_file_name || 'Hasil_Pekerjaan.docx')}
              disabled={downloading === (order.result_file_name || 'Hasil_Pekerjaan.docx')}
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-black flex items-center justify-center gap-2 shadow-md active:scale-98 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>
                {downloading === (order.result_file_name || 'Hasil_Pekerjaan.docx')
                  ? 'Sedang Mengunduh...'
                  : `Unduh Berkas: ${order.result_file_name || 'Hasil Pekerjaan'}`}
              </span>
            </button>

            {role === 'STUDENT' && (
              <button
                onClick={() => onOpenRevision(order)}
                className="w-full py-2.5 bg-white border border-slate-300 text-slate-800 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5 text-purple-600" />
                <span>Ajukan Koreksi / Revisi</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Revision Active Card */}
      {order.status === 'REVISI' && (
        <div className="bg-purple-50 rounded-3xl p-4 border border-purple-200 text-xs text-purple-950 space-y-1.5">
          <p className="font-extrabold flex items-center gap-1.5">
            <RefreshCw className="w-4 h-4 text-purple-700 animate-spin" />
            <span>Sedang Diproses Revisi</span>
          </p>
          <p className="text-slate-700">
            Catatan revisimu: "{order.revision_notes}"
          </p>
        </div>
      )}

      {/* STUDENT ACTION: QRIS PAYMENT */}
      {role === 'STUDENT' && order.status === 'MENUNGGU_PEMBAYARAN' && (
        <div className="fixed bottom-18 left-0 right-0 max-w-md mx-auto px-4 z-30">
          <button
            onClick={() => onOpenPayment(order)}
            className="w-full py-3.5 bg-orange-500 hover:bg-orange-600 text-white font-black rounded-2xl text-sm shadow-xl flex items-center justify-center gap-2 active:scale-98 transition-all"
          >
            <QrCode className="w-5 h-5" />
            <span>Bayar Sisa Rp{order.amount_to_pay.toLocaleString('id-ID')} via QRIS</span>
          </button>
        </div>
      )}

      {/* ADMIN CONTROLS IN DETAIL SHEET */}
      {role === 'ADMIN' && (
        <div className="bg-slate-900 text-white rounded-3xl p-4 space-y-2.5 border border-slate-800">
          <span className="text-[10px] text-amber-400 uppercase font-black tracking-wider block">
            Aksi Cepat Admin
          </span>
          <div className="grid grid-cols-1 gap-2">
            <button
              onClick={() => onAdminSetPrice?.(order)}
              className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black rounded-xl transition-colors"
            >
              {order.final_price === null ? 'Tentukan Harga & Respon Negosiasi' : 'Ubah Harga Final'}
            </button>
            {order.status === 'MENUNGGU_PEMBAYARAN' && (
              <button
                onClick={() => onAdminConfirmPayment?.(order.id)}
                className="w-full py-2.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-black rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Konfirmasi Pembayaran QRIS Masuk</span>
              </button>
            )}
            {order.status === 'ANTRIAN' && (
              <button
                onClick={() => onAdminStartWorking?.(order.id)}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-4 h-4" />
                <span>Ubah Status: Mulai Dikerjakan</span>
              </button>
            )}
            {(order.status === 'DIKERJAKAN' || order.status === 'REVISI') && (
              <button
                onClick={() => onAdminUploadResult?.(order)}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <FileCheck className="w-4 h-4" />
                <span>Upload Berkas Hasil & Tandai Selesai</span>
              </button>
            )}
            {order.status === 'SELESAI' && (
              <button
                onClick={() => onAdminUploadResult?.(order)}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5 border border-slate-700"
              >
                <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
                <span>Perbarui / Upload Ulang Berkas Hasil</span>
              </button>
            )}
          </div>
        </div>
      )}

    </div>
  );
};

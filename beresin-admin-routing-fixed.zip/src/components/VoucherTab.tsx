import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { BeresinDataStore } from '../lib/supabase';
import { VoucherCode } from '../types';
import { 
  Ticket, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  Copy, 
  Check, 
  MessageSquare, 
  Plus, 
  Info,
  Shield,
  ArrowRight
} from 'lucide-react';

interface VoucherTabProps {
  vouchers: VoucherCode[];
  onRefreshData: () => void;
  onOpenOrder: () => void;
}

export const VoucherTab: React.FC<VoucherTabProps> = ({
  vouchers,
  onRefreshData,
  onOpenOrder,
}) => {
  const { currentUser, role, refreshProfile } = useAuth();
  
  // Student claim input
  const [claimCode, setClaimCode] = useState('');
  const [claimFeedback, setClaimFeedback] = useState<{ success?: boolean; message?: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Admin create voucher
  const [newCode, setNewCode] = useState('');
  const [newValue, setNewValue] = useState(30000);
  const [adminFeedback, setAdminFeedback] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Filter for admin voucher list
  const [voucherFilter, setVoucherFilter] = useState<'ALL' | 'AVAILABLE' | 'USED'>('ALL');

  const handleClaimVoucher = () => {
    if (!currentUser) return;
    if (!claimCode.trim()) {
      setClaimFeedback({ success: false, message: 'Masukkan kode voucher terlebih dahulu.' });
      return;
    }
    setIsSubmitting(true);
    const result = BeresinDataStore.redeemVoucherCode(currentUser.id, claimCode.trim());
    setIsSubmitting(false);

    if (result.success) {
      setClaimFeedback({ success: true, message: result.message });
      setClaimCode('');
      refreshProfile();
      onRefreshData();
    } else {
      setClaimFeedback({ success: false, message: result.message });
    }
  };

  const handleCreateVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    const codeToUse = newCode.trim() 
      ? newCode.trim().toUpperCase() 
      : 'BERESIN' + Math.floor(1000 + Math.random() * 9000);
    const created = BeresinDataStore.createVoucher(codeToUse, newValue, 10000);
    if (created.success && created.voucher) {
      setAdminFeedback(`Kode voucher ${created.voucher.code} berhasil diterbitkan!`);
      setNewCode('');
      onRefreshData();
      setTimeout(() => setAdminFeedback(null), 3000);
    } else {
      setAdminFeedback(created.message || 'Kode voucher tersebut sudah ada di database.');
    }
  };

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const filteredVouchers = vouchers.filter((v) => {
    if (voucherFilter === 'AVAILABLE') return !v.is_used;
    if (voucherFilter === 'USED') return v.is_used;
    return true;
  });

  return (
    <div className="space-y-5 pb-20 animate-in fade-in duration-150">
      
      {/* WALLET / PASS CARD */}
      <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white rounded-3xl p-6 shadow-xl border border-slate-700/50">
        
        {/* Background glow decoration */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-amber-400/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-28 h-28 bg-emerald-400/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-sm">
                B
              </div>
              <span className="text-xs font-mono tracking-wider text-slate-400 uppercase">
                DOMPET VOUCHER BERESIN
              </span>
            </div>
            <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
              {role === 'ADMIN' ? 'Admin Master' : 'Akun Siswa'}
            </span>
          </div>

          <div>
            <p className="text-xs text-slate-400">Saldo Voucher Jasa Aktif</p>
            <h2 className="text-3xl font-black tracking-tight text-white mt-0.5">
              Rp{(currentUser?.voucher_balance || 0).toLocaleString('id-ID')}
            </h2>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
            <span>Pemilik: {currentUser?.full_name || 'Tamu'}</span>
            <span className="text-amber-400 font-semibold">Bukan Uang Tunai</span>
          </div>
        </div>
      </div>

      {/* PROMO HIGHLIGHT CARD */}
      <div className="bg-gradient-to-r from-amber-500/10 via-amber-400/10 to-amber-500/5 rounded-3xl p-4 sm:p-5 border border-amber-200/80 space-y-2">
        <div className="flex items-center gap-1.5 text-amber-950 font-black text-xs sm:text-sm">
          <Sparkles className="w-4 h-4 text-amber-600" />
          <span>Promo Resmi: Bayar Rp10.000 → Voucher Rp30.000</span>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          Beli kode voucher resmi dari Admin dengan Rp10.000, langsung dapat nilai jasa pengerjaan sebesar Rp30.000 untuk segala jenis tugas!
        </p>
        <a
          href="https://wa.me/6281234567890?text=Halo%20Admin%20BERESIN,%20saya%20mau%20beli%20kode%20voucher%20promo%20Rp10.000%20(dapat%20Rp30.000)"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Beli Kode ke Admin via WhatsApp</span>
        </a>
      </div>

      {/* STUDENT: REDEEM VOUCHER CODE FORM */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
        <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
          <Ticket className="w-4 h-4 text-amber-500" />
          <span>Klaim Kode Voucher Baru</span>
        </h3>
        <p className="text-xs text-slate-500">
          Punya kode voucher baru dari Admin? Masukkan kodenya di bawah ini untuk menambah saldo voucher jasamu.
        </p>

        {claimFeedback && (
          <div className={`p-3 rounded-xl text-xs flex items-start gap-2 ${
            claimFeedback.success 
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-800' 
              : 'bg-rose-50 border border-rose-200 text-rose-800'
          }`}>
            {claimFeedback.success ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            )}
            <span>{claimFeedback.message}</span>
          </div>
        )}

        <div className="flex gap-2">
          <input
            type="text"
            value={claimCode}
            onChange={(e) => setClaimCode(e.target.value.toUpperCase())}
            placeholder="KODE VOUCHER"
            className="flex-1 px-3.5 py-3 text-xs font-mono font-black uppercase bg-slate-50 rounded-2xl border border-slate-200 focus:border-amber-500 outline-none"
          />
          <button
            onClick={handleClaimVoucher}
            disabled={isSubmitting || !claimCode.trim()}
            className="px-5 py-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold rounded-2xl text-xs shrink-0 transition-colors"
          >
            Klaim
          </button>
        </div>

        <div className="pt-2 flex items-center gap-1.5 text-[11px] text-slate-400">
          <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span>Satu kode hanya dapat diklaim 1 kali dan otomatis terekam di sistem.</span>
        </div>
      </div>

      {/* QUICK USE BUTTON */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex items-center justify-between">
        <div>
          <h4 className="text-xs font-bold text-slate-900">Gunakan Saldo Voucher</h4>
          <p className="text-[11px] text-slate-500">Pilih tugas dan potong biaya otomatis.</p>
        </div>
        <button
          onClick={onOpenOrder}
          className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl text-xs font-black shadow-xs flex items-center gap-1.5"
        >
          <span>Buat Pesanan</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* ADMIN CONTROLS: VOUCHER GENERATOR & LIST */}
      {role === 'ADMIN' && (
        <div className="space-y-4 pt-2 border-t border-slate-200">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-amber-600" />
              <span>Manajemen Voucher (Admin Only)</span>
            </h3>
            <span className="text-[11px] text-slate-500 font-mono">
              Total: {vouchers.length}
            </span>
          </div>

          {/* Form Buat Kode Voucher */}
          <form onSubmit={handleCreateVoucher} className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3">
            <h4 className="text-xs font-bold text-slate-700">Terbitkan Kode Baru</h4>
            {adminFeedback && (
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200">
                {adminFeedback}
              </div>
            )}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">
                  KODE (OPSIONAL)
                </label>
                <input
                  type="text"
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value.toUpperCase())}
                  placeholder="AUTO JIKA KOSONG"
                  className="w-full px-3 py-2 text-xs font-mono font-bold bg-slate-50 rounded-xl border border-slate-200 outline-none"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 font-bold mb-1">
                  NILAI VOUCHER (RP)
                </label>
                <input
                  type="number"
                  value={newValue}
                  onChange={(e) => setNewValue(Number(e.target.value))}
                  step="5000"
                  className="w-full px-3 py-2 text-xs font-bold bg-slate-50 rounded-xl border border-slate-200 outline-none"
                />
              </div>
            </div>
            <button
              type="submit"
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-black rounded-xl text-xs flex items-center justify-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Terbitkan Kode Voucher Baru</span>
            </button>
          </form>

          {/* Filter Chips */}
          <div className="flex gap-1.5">
            {(['ALL', 'AVAILABLE', 'USED'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setVoucherFilter(f)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold transition-colors ${
                  voucherFilter === f
                    ? 'bg-slate-900 text-white'
                    : 'bg-white text-slate-600 border border-slate-200'
                }`}
              >
                {f === 'ALL' ? 'Semua' : f === 'AVAILABLE' ? 'Belum Dipakai' : 'Sudah Terpakai'}
              </button>
            ))}
          </div>

          {/* List Voucher Mobile Cards (No wide table!) */}
          <div className="space-y-2">
            {filteredVouchers.map((v) => (
              <div
                key={v.id}
                className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-2xs flex items-center justify-between gap-2"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-black text-xs text-slate-900">
                      {v.code}
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      v.is_used 
                        ? 'bg-slate-100 text-slate-500' 
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {v.is_used ? 'Sudah Dipakai' : 'Tersedia'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Nilai: Rp{v.value.toLocaleString('id-ID')}
                    {v.used_by_email && ` • Siswa: ${v.used_by_email}`}
                  </p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handleCopy(v.code)}
                    className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 active:scale-95"
                    title="Salin Kode"
                  >
                    {copiedCode === v.code ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <a
                    href={`https://wa.me/?text=Halo!%20Berikut%20kode%20voucher%20jasa%20BERESIN%20kamu:%20*${v.code}*%20senilai%20Rp${v.value.toLocaleString('id-ID')}.%20Masukkan%20di%20aplikasi%20BERESIN%20untuk%20aktivasi.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl bg-emerald-100 hover:bg-emerald-200 text-emerald-800 active:scale-95"
                    title="Kirim ke WhatsApp Siswa"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};

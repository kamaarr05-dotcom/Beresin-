import React from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  ArrowLeft, 
  Database, 
  Ticket,
  User,
  ShieldAlert
} from 'lucide-react';

interface MobileHeaderProps {
  title?: string;
  onBack?: () => void;
  onOpenSupabaseModal: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
}

export const MobileHeader: React.FC<MobileHeaderProps> = ({
  title,
  onBack,
  onOpenSupabaseModal,
  onOpenAuth,
}) => {
  const { currentUser, role } = useAuth();

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-xs">
      <div className="max-w-md mx-auto px-4 h-14 flex items-center justify-between">
        
        {/* Left: Back button OR Brand */}
        {onBack ? (
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              id="mobile-back-btn"
              className="p-1.5 -ml-1 text-slate-700 hover:text-slate-950 active:bg-slate-100 rounded-full transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-base font-black text-slate-900 truncate">
              {title || 'Kembali'}
            </h1>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-slate-950 flex items-center justify-center text-amber-400 font-black text-sm shadow-xs">
              B
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="font-extrabold text-base tracking-tight text-slate-950 font-display">
                  BERESIN
                </span>
                <span className="text-[9px] font-bold px-1.5 py-0.2 bg-amber-100 text-amber-900 rounded border border-amber-300">
                  APP
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Right: User status & Database status */}
        <div className="flex items-center gap-1.5">
          {currentUser ? (
            <>
              {/* User Identity Pill (Without switcher) */}
              <div 
                className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1.5"
              >
                <User className="w-3 h-3 text-slate-500" />
                <span className="truncate max-w-[100px]">{currentUser.full_name}</span>
              </div>

              {/* Supabase Status Icon */}
              <button
                id="header-supabase-btn"
                onClick={onOpenSupabaseModal}
                className="p-1.5 text-slate-500 hover:text-emerald-600 active:bg-slate-100 rounded-full transition-colors"
                title="Supabase Database Status & SQL"
              >
                <Database className="w-4 h-4 text-emerald-600" />
              </button>
            </>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onOpenAuth('login')}
                className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg"
              >
                Masuk
              </button>
              <button
                onClick={() => onOpenAuth('register')}
                className="px-3 py-1 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-xs"
              >
                Daftar
              </button>
            </div>
          )}
        </div>

      </div>
    </header>
  );
};

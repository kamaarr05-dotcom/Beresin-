import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { BeresinDataStore } from '../lib/supabase';
import { 
  Lock, 
  Mail, 
  User, 
  Phone, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  Eye, 
  EyeOff,
  HelpCircle
} from 'lucide-react';

interface MobileAuthScreenProps {
  initialMode?: 'login' | 'register';
  onGuestBrowse?: () => void;
  onOpenSupabaseModal?: () => void;
}

export const MobileAuthScreen: React.FC<MobileAuthScreenProps> = ({
  initialMode = 'login',
  onGuestBrowse,
  onOpenSupabaseModal,
}) => {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);

  // Form states
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Feedback states
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Submit Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!email.trim() || !password) {
      setErrorMsg('Email dan password wajib diisi.');
      return;
    }

    setIsLoading(true);
    const res = await login(email, password);
    setIsLoading(false);

    if (res.success) {
      setSuccessMsg(res.message);
    } else {
      setErrorMsg(res.message);
    }
  };

  // Submit Register (Student only)
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!fullName.trim() || !email.trim() || !whatsapp.trim() || !password || !confirmPassword) {
      setErrorMsg('Semua kolom pendaftaran wajib diisi.');
      return;
    }

    if (password.length < 6) {
      setErrorMsg('Password minimal 6 karakter demi keamanan akun.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg('Konfirmasi password tidak cocok dengan password yang dimasukkan.');
      return;
    }

    setIsLoading(true);
    const res = await register({
      full_name: fullName,
      email,
      whatsapp,
      password,
    });
    setIsLoading(false);

    if (res.success) {
      setSuccessMsg(res.message);
    } else {
      setErrorMsg(res.message);
    }
  };

  return (
    <div className="w-full min-h-screen bg-slate-900 sm:bg-slate-200/70 flex justify-center selection:bg-amber-200 selection:text-amber-900">
      <div className="w-full max-w-md min-h-screen bg-white flex flex-col relative shadow-2xl sm:border-x sm:border-slate-200">
        
        {/* Mobile Header Banner */}
        <div className="bg-slate-950 text-white pt-8 pb-7 px-6 relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute -top-12 -right-12 w-40 h-40 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-36 h-36 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 flex flex-col items-center text-center space-y-2">
            <div className="w-13 h-13 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-2xl shadow-lg shadow-amber-400/20">
              B
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight text-white flex items-center justify-center gap-1.5">
                <span>BERESIN</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-bold border border-amber-400/30">
                  Mobile
                </span>
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Kirim pekerjaanmu. Kami yang bereskan.
              </p>
            </div>
          </div>

          {/* Mode Switch Tabs (Mobile Segmented Control) */}
          <div className="mt-5 p-1 bg-slate-900/90 rounded-2xl flex border border-slate-800">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                mode === 'login'
                  ? 'bg-amber-400 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Masuk
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                mode === 'register'
                  ? 'bg-amber-400 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Daftar Mahasiswa
            </button>
          </div>
        </div>

        {/* Form Body */}
        <div className="flex-1 p-5 sm:p-6 overflow-y-auto space-y-4">
          
          {/* Alerts */}
          {errorMsg && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{errorMsg}</div>
            </div>
          )}

          {successMsg && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-start gap-2.5 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{successMsg}</div>
            </div>
          )}

          {/* ============================================================== */}
          {/* LOGIN FORM (Mobile Android/iOS Style) */}
          {/* ============================================================== */}
          {mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-1">
                <h2 className="text-base font-black text-slate-900">
                  Selamat Datang Kembali
                </h2>
                <p className="text-xs text-slate-500">
                  Masuk dengan akun Mahasiswa atau Admin Utama BERESIN.
                </p>
              </div>

              {/* Email */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="nama@email.com"
                    className="w-full pl-10 pr-4 py-3 text-sm bg-slate-50 rounded-2xl border border-slate-200 focus:border-amber-500 focus:bg-white transition-colors outline-none"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-700">
                    Password
                  </label>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Masukkan password Anda"
                    className="w-full pl-10 pr-11 py-3 text-sm bg-slate-50 rounded-2xl border border-slate-200 focus:border-amber-500 focus:bg-white transition-colors outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="p-2 text-slate-400 hover:text-slate-600 absolute right-2.5 top-2"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Tombol Masuk */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 bg-slate-950 hover:bg-slate-900 disabled:opacity-50 text-white font-black rounded-2xl text-sm shadow-md active:scale-98 transition-all flex items-center justify-center gap-2 mt-2"
              >
                <span>{isLoading ? 'Memverifikasi...' : 'Masuk ke Akun'}</span>
                <ArrowRight className="w-4 h-4 text-amber-400" />
              </button>

              {/* Link Daftar sebagai Mahasiswa */}
              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setErrorMsg('');
                  }}
                  className="text-xs text-slate-600 font-medium hover:text-amber-600 transition-colors"
                >
                  Belum punya akun? <span className="text-amber-600 font-extrabold underline">Daftar sebagai Mahasiswa</span>
                </button>
              </div>
            </form>
          )}

          {/* ============================================================== */}
          {/* REGISTRASI MAHASISWA FORM */}
          {/* ============================================================== */}
          {mode === 'register' && (
            <form onSubmit={handleRegister} className="space-y-3.5">
              
              {/* Nama Lengkap */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">
                  Nama Lengkap
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Contoh: Hesty Kurnia"
                    className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:border-amber-500 focus:bg-white outline-none"
                  />
                </div>
              </div>

              {/* Email */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">
                  Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="nama@kampus.id"
                    className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:border-amber-500 focus:bg-white outline-none"
                  />
                </div>
              </div>

              {/* WhatsApp */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">
                  Nomor WhatsApp
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="tel"
                    required
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    placeholder="081234567890"
                    className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:border-amber-500 focus:bg-white outline-none"
                  />
                </div>
              </div>

              {/* Password & Confirm Password */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Min. 6 digit"
                      className="w-full pl-10 pr-3 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:border-amber-500 focus:bg-white outline-none"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    Konfirmasi Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Ulangi password"
                      className="w-full pl-10 pr-3 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:border-amber-500 focus:bg-white outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Tombol Pendaftaran */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-black rounded-2xl text-sm shadow-md active:scale-98 transition-all flex items-center justify-center gap-2 mt-4"
              >
                <span>{isLoading ? 'Mendaftarkan...' : 'Daftar Akun Mahasiswa'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Back to login */}
              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setErrorMsg('');
                  }}
                  className="text-xs text-slate-600 font-medium hover:text-slate-900"
                >
                  Sudah punya akun? <span className="text-slate-900 font-extrabold underline">Masuk ke Akun</span>
                </button>
              </div>
            </form>
          )}

          {/* Guest browse or architecture info */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
            {onGuestBrowse && (
              <button
                type="button"
                onClick={onGuestBrowse}
                className="hover:text-slate-700 font-medium"
              >
                Jelajahi Katalog Layanan →
              </button>
            )}
            {onOpenSupabaseModal && (
              <button
                type="button"
                onClick={onOpenSupabaseModal}
                className="hover:text-slate-700 font-medium flex items-center gap-1 ml-auto"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Supabase RLS</span>
              </button>
            )}
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 text-center">
          <p className="text-[11px] text-slate-400">
            BERESIN • Didukung Supabase Auth & PostgreSQL RLS
          </p>
        </div>

      </div>
    </div>
  );
};

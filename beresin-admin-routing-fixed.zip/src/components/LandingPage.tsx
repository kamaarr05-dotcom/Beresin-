import React, { useState } from 'react';
import { ServiceItem } from '../types';
import { 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  Phone, 
  MessageSquare, 
  Presentation, 
  Sheet, 
  FileText, 
  FileSearch, 
  Film, 
  Palette, 
  Headphones, 
  Database, 
  Smartphone, 
  Globe, 
  Wrench,
  UserPlus,
  LogIn,
  Layers,
  UploadCloud,
  Download,
  HelpCircle,
  ShieldCheck,
  Zap,
  Clock,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface LandingPageProps {
  services: ServiceItem[];
  onOpenAuth: (mode: 'login' | 'register') => void;
  onSelectService: (service: ServiceItem) => void;
  onNavigateService?: (slug: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  services,
  onOpenAuth,
  onSelectService,
  onNavigateService,
}) => {
  const WHATSAPP_NUMBER = '08136732365';
  const WHATSAPP_LINK = 'https://wa.me/628136732365?text=Halo%20Admin%20BERESIN,%20saya%20mau%20konsultasi%20jasa%20tugas%20dan%20voucher';

  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const getServiceSlug = (service: ServiceItem): string => {
    const id = service.id.toLowerCase();
    const name = service.name.toLowerCase();
    if (id.includes('ppt') || name.includes('ppt') || name.includes('presentasi')) return 'jasa-ppt';
    if (id.includes('excel') || name.includes('excel')) return 'jasa-excel';
    if (id.includes('word') || name.includes('word')) return 'jasa-word';
    if (id.includes('video') || name.includes('video')) return 'jasa-edit-video';
    if (id.includes('desain') || name.includes('desain')) return 'jasa-desain';
    if (id.includes('transkrip') || name.includes('transkrip')) return 'jasa-transkripsi';
    if (id.includes('data') || name.includes('data') || name.includes('rapikan') || name.includes('input')) return 'jasa-input-data';
    if (id.includes('pdf') || name.includes('pdf')) return 'jasa-pdf';
    if (id.includes('website') || name.includes('website')) return 'jasa-pembuatan-website';
    if (id.includes('aplikasi') || name.includes('aplikasi')) return 'jasa-pembuatan-aplikasi';
    return 'jasa-ppt';
  };

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Presentation': return <Presentation className="w-5 h-5 text-amber-600" />;
      case 'Sheet': return <Sheet className="w-5 h-5 text-emerald-600" />;
      case 'FileText': return <FileText className="w-5 h-5 text-blue-600" />;
      case 'FileSearch': return <FileSearch className="w-5 h-5 text-rose-600" />;
      case 'Film': return <Film className="w-5 h-5 text-purple-600" />;
      case 'Palette': return <Palette className="w-5 h-5 text-pink-600" />;
      case 'Headphones': return <Headphones className="w-5 h-5 text-indigo-600" />;
      case 'Database': return <Database className="w-5 h-5 text-cyan-600" />;
      case 'Smartphone': return <Smartphone className="w-5 h-5 text-violet-600" />;
      case 'Globe': return <Globe className="w-5 h-5 text-sky-600" />;
      case 'Wrench': return <Wrench className="w-5 h-5 text-amber-700" />;
      default: return <FileText className="w-5 h-5 text-slate-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950">
      
      {/* ========================================================================= */}
      {/* 1. PUBLIC NAVBAR */}
      {/* ========================================================================= */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          
          {/* Logo Brand */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-slate-950 flex items-center justify-center text-amber-400 font-extrabold text-xl shadow-md">
              B
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-black tracking-tight text-slate-900 font-display">
                  BERESIN
                </span>
                <span className="px-1.5 py-0.2 rounded text-[10px] font-black bg-amber-100 text-amber-900 border border-amber-300">
                  PRO
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium hidden sm:block">
                Kirim pekerjaanmu. Kami yang bereskan.
              </p>
            </div>
          </div>

          {/* Quick Anchor Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-bold text-slate-600">
            <a href="#layanan" className="hover:text-amber-600 transition-colors">Layanan</a>
            <a href="#cara-kerja" className="hover:text-amber-600 transition-colors">Cara Kerja</a>
            <a href="#promo" className="hover:text-amber-600 transition-colors">Promo Rp10.000</a>
            <a 
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>WA: {WHATSAPP_NUMBER}</span>
            </a>
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenAuth('login')}
              className="px-3.5 py-2 text-xs font-bold text-slate-700 hover:text-slate-950 rounded-xl hover:bg-slate-100 transition-colors"
            >
              Login
            </button>
            <button
              onClick={() => onOpenAuth('register')}
              className="px-4 py-2 text-xs font-black bg-slate-950 hover:bg-slate-800 text-white rounded-xl shadow-sm hover:shadow active:scale-98 transition-all flex items-center gap-1.5"
            >
              <UserPlus className="w-3.5 h-3.5 text-amber-400" />
              <span>Daftar Sekarang</span>
            </button>
          </div>

        </div>
      </header>

      {/* ========================================================================= */}
      {/* 2. HERO SECTION */}
      {/* ========================================================================= */}
      <section className="relative overflow-hidden pt-8 pb-12 sm:pt-14 sm:pb-16 bg-gradient-to-b from-white via-slate-50 to-slate-100 border-b border-slate-200">
        
        {/* Subtle Ambient Glow */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-[550px] h-[350px] bg-amber-400/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 text-center space-y-6">
          
          {/* Main Brand Title & Tagline */}
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-100 border border-amber-300 text-amber-900 text-xs font-extrabold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Solusi Tugas Digital Mahasiswa & Pelajar</span>
            </div>

            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-slate-950 tracking-tight font-display uppercase">
              BERESIN
            </h1>

            <p className="text-xl sm:text-2xl font-bold text-slate-700 max-w-2xl mx-auto">
              “Kirim pekerjaanmu. Kami yang bereskan.”
            </p>

            <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto leading-relaxed">
              Pusat pengerjaan tugas digital mahasiswa terpercaya: <strong>jasa PPT mahasiswa</strong>, <strong>jasa edit PPT</strong>, <strong>jasa Excel</strong>, <strong>jasa Word</strong> skripsi & makalah, <strong>jasa edit video</strong>, <strong>jasa desain</strong> grafis, <strong>jasa transkripsi</strong> wawancara, <strong>jasa rapikan data</strong>, dan <strong>jasa PDF</strong>. Dilengkapi harga transparan, voucher promo Rp30.000, serta fitur negosiasi harga ramah kantong.
            </p>
          </div>

          {/* Big Promo Highlight Card */}
          <div className="bg-gradient-to-br from-amber-400 via-amber-400 to-amber-500 text-slate-950 rounded-3xl p-6 sm:p-8 shadow-xl border-2 border-amber-300 max-w-2xl mx-auto space-y-4">
            <div className="inline-block px-3 py-1 rounded-full bg-slate-950 text-amber-300 text-xs font-black uppercase tracking-wider">
              🎉 PROMO SPESIAL TERBATAS
            </div>

            <div className="space-y-1">
              <div className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight uppercase leading-tight">
                BAYAR <span className="underline decoration-slate-950 decoration-wavy">Rp10.000</span>
                <br />
                DAPAT VOUCHER JASA <span className="text-white drop-shadow-md">Rp30.000</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-950/90 font-medium max-w-md mx-auto pt-1">
                Daftar sekarang, kamu otomatis dapat saldo voucher jasa Rp30.000 untuk memotong biaya tugas apapun!
              </p>
            </div>

            {/* Buttons: Daftar Sekarang & Login */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                onClick={() => onOpenAuth('register')}
                className="w-full sm:w-auto px-6 py-3.5 bg-slate-950 hover:bg-slate-900 text-white rounded-2xl text-sm font-black shadow-lg hover:shadow-xl active:scale-98 transition-all flex items-center justify-center gap-2"
              >
                <UserPlus className="w-4 h-4 text-amber-400" />
                <span>Daftar Sekarang</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onOpenAuth('login')}
                className="w-full sm:w-auto px-6 py-3.5 bg-white/90 hover:bg-white text-slate-900 rounded-2xl text-sm font-bold shadow-xs active:scale-98 transition-all flex items-center justify-center gap-2"
              >
                <LogIn className="w-4 h-4 text-slate-700" />
                <span>Login</span>
              </button>
            </div>
          </div>

          {/* WhatsApp CTA Pill */}
          <div className="pt-2">
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-300 text-xs font-bold hover:bg-emerald-100 transition-colors shadow-2xs"
            >
              <MessageSquare className="w-4 h-4 text-emerald-600" />
              <span>Butuh konsultasi langsung? Hubungi WhatsApp: <strong>{WHATSAPP_NUMBER}</strong></span>
            </a>
          </div>

        </div>
      </section>

      {/* ========================================================================= */}
      {/* 3. SECTION: LAYANAN */}
      {/* ========================================================================= */}
      <section id="layanan" className="py-12 sm:py-16 max-w-6xl mx-auto px-4 sm:px-6 space-y-6">
        
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
            <Layers className="w-3.5 h-3.5 text-amber-600" />
            <span>Katalog Tugas Digital</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-950 tracking-tight">
            Pilihan Layanan & Harga Jasa
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Pilih jenis pekerjaanmu. Harga transparan dan bisa langsung dipotong dengan voucher promo Rp30.000.
          </p>
          
          {/* Note Requirement: "Harga dapat dinegosiasikan untuk pekerjaan tertentu." */}
          <div className="inline-block mt-2 px-4 py-1.5 bg-amber-50 text-amber-900 rounded-xl border border-amber-200 text-xs font-bold shadow-2xs">
            💬 “Harga dapat dinegosiasikan untuk pekerjaan tertentu.”
          </div>
        </div>

        {/* Service Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4 pt-4">
          {services.filter(s => s.is_active).map((service) => (
            <div
              key={service.id}
              onClick={() => onSelectService(service)}
              className="group bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 hover:border-amber-400 shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center group-hover:scale-105 transition-transform">
                    {getServiceIcon(service.icon)}
                  </div>
                  <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                    {service.category}
                  </span>
                </div>

                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 group-hover:text-amber-700 transition-colors">
                    {service.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </div>

                <div className="pt-3 mt-3 border-t border-slate-100 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-400 block">Mulai</span>
                      <span className="text-sm font-black text-slate-950">
                        Rp{service.base_price.toLocaleString('id-ID')}
                      </span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectService(service);
                      }}
                      className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-lg text-xs font-bold border border-amber-200 flex items-center gap-1 transition-colors"
                    >
                      <span>Pesan</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>

                  {/* SEO Page Link */}
                  {onNavigateService && (
                    <a
                      href={`https://kamaarr05-dotcom.github.io/Beresin-/${getServiceSlug(service)}`}
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        onNavigateService(getServiceSlug(service));
                      }}
                      className="text-[11px] text-slate-400 hover:text-amber-700 font-medium transition-colors flex items-center gap-1 w-full pt-1 border-t border-slate-50 cursor-pointer"
                    >
                      <span>Detail layanan & FAQ</span>
                      <ArrowRight className="w-3 h-3" />
                    </a>
                  )}
                </div>
            </div>
          ))}
        </div>

      </section>

      {/* ========================================================================= */}
      {/* 4. SECTION: CARA KERJA (4 LANGKAH SEDERHANA) */}
      {/* ========================================================================= */}
      <section id="cara-kerja" className="py-12 sm:py-16 bg-white border-y border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-10">
          
          <div className="text-center max-w-xl mx-auto space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              <span>Alur Pengerjaan Praktis</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-950 tracking-tight">
              Cara Kerja
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Hanya 4 langkah mudah untuk menyelesaikan tugasmu tanpa ribet.
            </p>
          </div>

          {/* 4 Steps Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Step 1 */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 relative flex flex-col justify-between space-y-3">
              <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 font-black text-sm flex items-center justify-center shadow-xs">
                1
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-1">Daftar</h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Daftar akun dan dapatkan voucher potongan langsung Rp30.000 untuk tugas pertamamu.
                </p>
              </div>
              <span className="text-[11px] font-bold text-amber-700">Langkah Pertama</span>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 relative flex flex-col justify-between space-y-3">
              <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 font-black text-sm flex items-center justify-center shadow-xs">
                2
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-1">Pilih Jasa</h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Pilih layanan yang kamu butuhkan (jasa PPT mahasiswa, jasa Excel, Word, video, desain, dll).
                </p>
              </div>
              <span className="text-[11px] font-bold text-amber-700">Katalog Lengkap</span>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 relative flex flex-col justify-between space-y-3">
              <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 font-black text-sm flex items-center justify-center shadow-xs">
                3
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-1">Kirim File</h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Upload file tugasmu, instruksi dosen, deadline, dan ajukan fitur negosiasi harga jika diperlukan.
                </p>
              </div>
              <span className="text-[11px] font-bold text-amber-700">Upload Cepat</span>
            </div>

            {/* Step 4 */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 relative flex flex-col justify-between space-y-3">
              <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 font-black text-sm flex items-center justify-center shadow-xs">
                4
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-1">Terima Hasil</h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Pantau proses pengerjaan secara real-time dan download file akhir bergaransi revisi.
                </p>
              </div>
              <span className="text-[11px] font-bold text-emerald-700 font-black">Tugas Tuntas</span>
            </div>

          </div>

        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. SECTION: PROMO VOUCHER (H2 Requirement: Promo Voucher) */}
      {/* ========================================================================= */}
      <section id="promo" className="py-12 sm:py-16 max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-10 border border-slate-800 shadow-2xl space-y-6 relative overflow-hidden">
          
          <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="text-center space-y-2">
            <span className="px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold border border-amber-400/30 inline-block">
              🔥 KLAIM VOUCHER HARI INI
            </span>

            {/* H2 Requirement: Promo Voucher */}
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-amber-400 font-display uppercase">
              Promo Voucher
            </h2>

            <div className="text-3xl sm:text-5xl font-black tracking-tight text-white font-display uppercase">
              Daftar Cuma Rp10.000 <br />
              <span className="text-amber-400">Dapat Voucher Jasa Rp30.000</span>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto">
              Hemat biaya tugasmu sekarang juga. Voucher dapat langsung dipakai untuk pengerjaan tugas pertama!
            </p>
          </div>

          {/* Simulator Box */}
          <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-4 sm:p-5 max-w-lg mx-auto text-xs space-y-3">
            <div className="flex items-center gap-2 font-bold text-amber-400 text-xs uppercase">
              <HelpCircle className="w-4 h-4" />
              <span>Simulasi Potongan Saldo Voucher:</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-200">
              <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-700">
                <span className="text-emerald-400 font-bold block mb-1">Kasus 1: Bayar Rp0</span>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Tugas PPT Rp25.000 dipotong voucher Rp30.000 → <strong className="text-white">Kamu bayar Rp0</strong>, sisa voucher Rp5.000 disimpan.
                </p>
              </div>

              <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-700">
                <span className="text-amber-400 font-bold block mb-1">Kasus 2: Bayar Selisih</span>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Tugas Rp45.000 dipotong voucher Rp30.000 → <strong className="text-white">Kamu cuma bayar Rp15.000</strong>.
                </p>
              </div>
            </div>
          </div>

          {/* Button: Dapatkan Voucher */}
          <div className="text-center pt-2">
            <button
              onClick={() => onOpenAuth('register')}
              className="px-8 py-3.5 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-2xl text-sm font-black shadow-lg hover:shadow-amber-400/20 active:scale-98 transition-all inline-flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>Dapatkan Voucher</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      </section>

      {/* ========================================================================= */}
      {/* 6. SECTION: FAQ (H2 Requirement: Pertanyaan yang Sering Ditanyakan) */}
      {/* ========================================================================= */}
      <section id="faq" className="py-12 sm:py-16 max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
            <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
            <span>Pusat Bantuan & Tanya Jawab</span>
          </div>

          {/* H2 Requirement: Pertanyaan yang Sering Ditanyakan */}
          <h2 className="text-2xl sm:text-3xl font-black text-slate-950 tracking-tight">
            Pertanyaan yang Sering Ditanyakan
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Pertanyaan umum seputar layanan jasa PPT mahasiswa, jasa Excel, Word, video, desain, voucher, dan negosiasi harga.
          </p>
        </div>

        <div className="space-y-3 pt-2">
          {[
            {
              q: 'Apa saja jasa tugas digital yang dapat dikerjakan di BERESIN?',
              a: 'Kami melayani jasa PPT mahasiswa & jasa edit PPT, jasa Excel formula & spreadsheet, jasa Word skripsi/makalah, jasa edit video presentasi/tugas, jasa desain poster & infografis, jasa transkripsi wawancara, jasa rapikan data riset, dan jasa edit PDF dengan tarif transparan.'
            },
            {
              q: 'Bagaimana cara memanfaatkan promo voucher jasa Rp30.000?',
              a: 'Setelah mendaftarkan akun di BERESIN, saldo voucher potongan harga Rp30.000 akan otomatis aktif di akunmu. Saat membuat pesanan pertama, biaya jasa akan langsung dipotong oleh voucher tersebut.'
            },
            {
              q: 'Apakah harga jasa tugas di BERESIN bisa dinegosiasikan?',
              a: 'Bisa! Kami menyediakan fitur negosiasi harga untuk menyesuaikan estimasi biaya dengan tingkat kesulitan materi dan budget mahasiswa.'
            },
            {
              q: 'Bagaimana bila hasil pekerjaan membutuhkan perbaikan atau revisi?',
              a: 'Seluruh pesanan di BERESIN dilindungi oleh garansi revisi gratis sesuai dengan brief awal yang kamu berikan saat pemesanan.'
            },
            {
              q: 'Berapa lama waktu pengerjaan tugas?',
              a: 'Tergantung tingkat kerumitan tugas. Kami menyediakan opsi reguler (1-2 hari) dan opsi express kilat (mulai 3-6 jam) jika kamu memiliki deadline yang mendesak.'
            }
          ].map((faq, idx) => (
            <div 
              key={idx} 
              className="border border-slate-200 bg-white rounded-2xl overflow-hidden shadow-2xs transition-colors"
            >
              <button
                onClick={() => setOpenFaqIndex(openFaqIndex === idx ? null : idx)}
                className="w-full text-left p-4 sm:p-5 bg-white hover:bg-slate-50/80 flex items-center justify-between gap-3 text-xs sm:text-sm font-bold text-slate-800 transition-colors"
              >
                <span>{faq.q}</span>
                {openFaqIndex === idx ? (
                  <ChevronUp className="w-4 h-4 text-amber-600 shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                )}
              </button>
              {openFaqIndex === idx && (
                <div className="p-4 sm:p-5 pt-0 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 7. FOOTER */}
      {/* ========================================================================= */}
      <footer className="mt-auto bg-white border-t border-slate-200 py-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-8">
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-100">
            
            {/* Brand */}
            <div className="space-y-1 max-w-sm">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-slate-950 flex items-center justify-center text-amber-400 font-black text-sm">
                  B
                </div>
                <span className="text-lg font-black text-slate-900 tracking-tight font-display">
                  BERESIN
                </span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                “Kirim pekerjaanmu. Kami yang bereskan.” Platform pengerjaan tugas & jasa digital profesional bagi mahasiswa dan pelajar.
              </p>
            </div>

            {/* Footer Navigation Links: Layanan, Cara Kerja, Promo, FAQ, Login, Daftar */}
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs font-bold text-slate-600">
              <a href="#layanan" className="hover:text-amber-600 transition-colors">Layanan</a>
              <a href="#cara-kerja" className="hover:text-amber-600 transition-colors">Cara Kerja</a>
              <a href="#promo" className="hover:text-amber-600 transition-colors">Promo Voucher</a>
              <a href="#faq" className="hover:text-amber-600 transition-colors">FAQ</a>
              <button 
                onClick={() => onOpenAuth('login')}
                className="hover:text-amber-600 transition-colors"
              >
                Login
              </button>
              <button 
                onClick={() => onOpenAuth('register')}
                className="hover:text-amber-600 transition-colors text-amber-700 font-bold"
              >
                Daftar
              </button>
            </div>

            {/* Direct Contact CTA */}
            <div className="text-xs space-y-1">
              <span className="text-slate-400 block text-[10px] font-bold uppercase tracking-wider">Kontak & Bantuan:</span>
              <a 
                href={WHATSAPP_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp: {WHATSAPP_NUMBER}</span>
              </a>
            </div>

          </div>

          {/* Quick Service Links for High SEO Internal Authority */}
          <div className="pt-2">
            <span className="text-[11px] font-bold text-slate-400 block mb-2 uppercase tracking-wider">
              Layanan Utama Mahasiswa & Kantor:
            </span>
            <div className="flex flex-wrap gap-2 text-xs">
              {[
                { name: 'Jasa PPT Mahasiswa', slug: 'jasa-ppt' },
                { name: 'Jasa Excel & Formula', slug: 'jasa-excel' },
                { name: 'Jasa Word & Skripsi', slug: 'jasa-word' },
                { name: 'Jasa Edit Video', slug: 'jasa-edit-video' },
                { name: 'Jasa Desain Grafis', slug: 'jasa-desain' },
                { name: 'Jasa Transkripsi Wawancara', slug: 'jasa-transkripsi' },
                { name: 'Jasa Input Data', slug: 'jasa-input-data' },
                { name: 'Jasa Edit PDF', slug: 'jasa-pdf' },
                { name: 'Jasa Pembuatan Website', slug: 'jasa-pembuatan-website' },
                { name: 'Jasa Pembuatan Aplikasi', slug: 'jasa-pembuatan-aplikasi' },
              ].map(s => (
                <a
                  key={s.slug}
                  href={`https://kamaarr05-dotcom.github.io/Beresin-/${s.slug}`}
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigateService && onNavigateService(s.slug);
                  }}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-amber-900 rounded-lg transition-colors text-[11px] font-medium block cursor-pointer"
                >
                  {s.name}
                </a>
              ))}
            </div>
          </div>

          <div className="text-center text-[11px] text-slate-400 pt-4 border-t border-slate-100">
            &copy; {new Date().getFullYear()} BERESIN. All rights reserved. Kirim pekerjaanmu, kami yang bereskan.
          </div>

        </div>
      </footer>

    </div>
  );
};

export type UserRole = 'STUDENT' | 'ADMIN';

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  whatsapp: string;
  role: UserRole;
  password?: string;
  voucher_balance: number;
  voucher_code_used?: string;
  created_at: string;
}

export interface ServiceItem {
  id: string;
  name: string;
  category: string;
  base_price: number;
  unit_label: string;
  description: string;
  icon: string;
  is_active: boolean;
}

export interface VoucherCode {
  id: string;
  code: string;
  value: number; // e.g. 30000
  cost_price: number; // 10000
  is_used: boolean;
  used_by_email?: string;
  used_by_name?: string;
  used_at?: string;
  created_at: string;
}

export type OrderStatus =
  | 'MENUNGGU_HARGA'
  | 'MENUNGGU_PEMBAYARAN'
  | 'ANTRIAN'
  | 'DIKERJAKAN'
  | 'REVISI'
  | 'SELESAI'
  | 'DIBATALKAN';

export type NegotiationStatus = 'NONE' | 'PENDING' | 'ACCEPTED' | 'ADJUSTED' | 'REJECTED';

export interface OrderItem {
  id: string;
  order_number: string;
  student_id: string;
  student_name: string;
  student_email: string;
  student_whatsapp: string;
  service_id: string;
  service_name: string;
  base_price: number;
  final_price: number | null; // determined by Admin or agreed negotiation
  voucher_deduction: number; // potongan voucher yang dipakai
  amount_to_pay: number; // selisih yang harus dibayar siswa via QRIS
  status: OrderStatus;
  instructions: string;
  deadline: string; // ISO string
  file_name?: string;
  file_url?: string;
  file_size?: number;
  // Negotiation feature
  negotiation_requested: boolean;
  negotiation_price?: number;
  negotiation_reason?: string;
  negotiation_status?: NegotiationStatus;
  admin_negotiation_note?: string;
  admin_notes?: string;
  // Payment
  payment_method: 'VOUCHER_ONLY' | 'QRIS';
  payment_confirmed: boolean;
  payment_proof_name?: string;
  payment_proof_url?: string;
  payment_notes?: string;
  // Work Results
  result_file_name?: string;
  result_file_url?: string;
  result_notes?: string;
  completed_at?: string;
  // Revision
  revision_requested: boolean;
  revision_notes?: string;
  revision_requested_at?: string;
  created_at: string;
  updated_at: string;
}

export interface AdminPaymentConfig {
  whatsapp_number: string;
  whatsapp_greeting: string;
  bank_name: string;
  bank_account_number: string;
  bank_account_holder: string;
  qris_merchant_name: string;
  qris_nmid: string;
  payment_instructions?: string;
}

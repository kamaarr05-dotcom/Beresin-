import React, { useState } from 'react';
import { 
  X, 
  Database, 
  CheckCircle2, 
  Copy, 
  Check, 
  ShieldCheck, 
  ExternalLink,
  Lock,
  Layers,
  FileCode
} from 'lucide-react';
import { isSupabaseConfigured } from '../lib/supabase';

interface SupabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupabaseModal: React.FC<SupabaseModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'sql'>('info');

  if (!isOpen) return null;

  const sqlSchemaSnippet = `-- =========================================================================
-- BERESIN DATABASE SCHEMA & SECURITY RULES (PostgreSQL + Supabase RLS)
-- =========================================================================

-- Profiles Table (Tied to Supabase Auth)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT NOT NULL,
    whatsapp TEXT NOT NULL,
    role user_role DEFAULT 'STUDENT',
    voucher_balance NUMERIC(10, 2) DEFAULT 0.00,
    voucher_code_used TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Services Table with base prices
CREATE TABLE IF NOT EXISTS public.services (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    base_price NUMERIC(10, 2) NOT NULL DEFAULT 20000.00,
    unit_label TEXT NOT NULL DEFAULT 'mulai Rp20.000',
    description TEXT,
    icon TEXT,
    is_active BOOLEAN DEFAULT TRUE
);

-- Vouchers Table (Single use, non-cash)
CREATE TABLE IF NOT EXISTS public.vouchers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code TEXT UNIQUE NOT NULL,
    value NUMERIC(10, 2) NOT NULL DEFAULT 30000.00,
    cost_price NUMERIC(10, 2) NOT NULL DEFAULT 10000.00,
    is_used BOOLEAN DEFAULT FALSE,
    used_by_email TEXT,
    used_at TIMESTAMPTZ
);

-- Orders Table with RLS
CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_number TEXT UNIQUE NOT NULL,
    student_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    student_name TEXT NOT NULL,
    student_email TEXT NOT NULL,
    student_whatsapp TEXT NOT NULL,
    service_id TEXT NOT NULL REFERENCES public.services(id),
    service_name TEXT NOT NULL,
    base_price NUMERIC(10, 2) NOT NULL,
    final_price NUMERIC(10, 2),
    voucher_deduction NUMERIC(10, 2) DEFAULT 0.00,
    amount_to_pay NUMERIC(10, 2) DEFAULT 0.00,
    status order_status DEFAULT 'MENUNGGU_HARGA',
    instructions TEXT NOT NULL,
    deadline TIMESTAMPTZ NOT NULL,
    file_name TEXT,
    file_url TEXT,
    negotiation_requested BOOLEAN DEFAULT FALSE,
    negotiation_price NUMERIC(10, 2),
    negotiation_reason TEXT,
    payment_method TEXT DEFAULT 'QRIS',
    payment_confirmed BOOLEAN DEFAULT FALSE,
    result_file_name TEXT,
    result_file_url TEXT,
    result_notes TEXT,
    revision_requested BOOLEAN DEFAULT FALSE,
    revision_notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS Enforcement
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vouchers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students see only own orders" ON public.orders FOR SELECT USING (student_id = auth.uid() OR public.is_admin());
CREATE POLICY "Admin manages all" ON public.orders FOR ALL USING (public.is_admin());`;

  const handleCopySql = () => {
    navigator.clipboard.writeText(sqlSchemaSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">
                Arsitektur Supabase & PostgreSQL
              </h3>
              <p className="text-xs text-slate-500">
                Auth, PostgreSQL Database, Private Storage, dan RLS Security
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 px-5 pt-2 gap-4 text-xs font-bold bg-white">
          <button
            onClick={() => setActiveTab('info')}
            className={`pb-2.5 border-b-2 transition-colors ${
              activeTab === 'info'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Ringkasan Keamanan & Status
          </button>
          <button
            onClick={() => setActiveTab('sql')}
            className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'sql'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Skema SQL Supabase</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-700 flex-1">
          {activeTab === 'info' ? (
            <div className="space-y-4">
              
              {/* Status Banner */}
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-bold text-emerald-950 text-sm">
                    {isSupabaseConfigured 
                      ? 'Terkoneksi ke Supabase Live!' 
                      : 'Mode Operasional Aktif (Local Engine + Supabase Ready)'}
                  </p>
                  <p className="text-emerald-800 leading-relaxed text-xs">
                    {isSupabaseConfigured
                      ? 'Aplikasi berjalan terhubung langsung ke Supabase URL dan Anon Key kamu.'
                      : 'Aplikasi siap digunakan secara interaktif penuh (login, voucher balance, negosiasi harga, upload file, konfirmasi QRIS). Untuk menghubungkan ke Cloud Supabase langsung, cukup masukkan VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY ke file .env.'}
                  </p>
                </div>
              </div>

              {/* Security Mandates Checklist */}
              <div className="space-y-2">
                <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Kepatuhan Aturan Keamanan & RLS</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50">
                    <p className="font-bold text-slate-900">1. Supabase RLS (Row Level Security)</p>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Siswa hanya dapat mengakses pesanan dan data profil miliknya sendiri. Admin memiliki akses manajemen menyeluruh.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50">
                    <p className="font-bold text-slate-900">2. Validasi Server/Database</p>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Perhitungan potongan voucher divalidasi ketat di sisi server/database dengan fungsi atomic `apply_voucher_and_finalize_price`.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50">
                    <p className="font-bold text-slate-900">3. Single-Use Voucher Code</p>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Satu kode voucher hanya dapat digunakan satu kali. Kode divalidasi dan ditandai `is_used = true`.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50">
                    <p className="font-bold text-slate-900">4. Private Supabase Storage</p>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Berkas tugas tersimpan di bucket privat (hanya siswa pemesan dan admin pengerja yang dapat mengakses).
                    </p>
                  </div>
                </div>
              </div>

            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[11px] text-slate-500">
                  File: /supabase/schema.sql
                </span>
                <button
                  onClick={handleCopySql}
                  className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Tersalin!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Salin Semua SQL</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-3.5 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-2xl overflow-x-auto leading-relaxed max-h-96 border border-slate-800">
                {sqlSchemaSnippet}
              </pre>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-slate-100 bg-slate-50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 text-white font-bold rounded-xl text-xs"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};

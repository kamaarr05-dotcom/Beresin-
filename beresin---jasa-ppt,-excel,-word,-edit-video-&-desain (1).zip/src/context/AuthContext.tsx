import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile, UserRole } from '../types';
import { BeresinDataStore, getSupabase, isSupabaseConfigured } from '../lib/supabase';

interface AuthContextType {
  currentUser: UserProfile | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  login: (email: string, password?: string) => Promise<{ success: boolean; message: string }>;
  register: (data: {
    full_name: string;
    email: string;
    whatsapp: string;
    password: string;
    voucher_code?: string;
  }) => Promise<{ success: boolean; message: string; user?: UserProfile }>;
  logout: () => void;
  switchUser: (role: UserRole) => void;
  refreshUser: () => void;
  refreshProfile: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const stored = localStorage.getItem('beresin_current_user_v1');
      if (stored) return JSON.parse(stored);
      return null;
    } catch {
      return null;
    }
  });

  // Listen to Supabase auth state if configured
  useEffect(() => {
    const supabase = getSupabase();
    if (!supabase) return;

    // Check existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single()
          .then(({ data: profile }) => {
            if (profile) {
              const mappedUser: UserProfile = {
                id: profile.id,
                email: profile.email || session.user.email || '',
                full_name: profile.full_name || 'Mahasiswa BERESIN',
                whatsapp: profile.whatsapp || '',
                role: profile.role || 'STUDENT',
                voucher_balance: Number(profile.voucher_balance) || 0,
                voucher_code_used: profile.voucher_code_used,
                created_at: profile.created_at || new Date().toISOString(),
              };
              setCurrentUser(mappedUser);
            }
          });
      }
    });

    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_OUT' || !session) {
        // Only clear if we were using supabase auth
      } else if (session?.user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
        if (profile) {
          setCurrentUser({
            id: profile.id,
            email: profile.email || session.user.email || '',
            full_name: profile.full_name || 'Mahasiswa BERESIN',
            whatsapp: profile.whatsapp || '',
            role: profile.role || 'STUDENT',
            voucher_balance: Number(profile.voucher_balance) || 0,
            voucher_code_used: profile.voucher_code_used,
            created_at: profile.created_at || new Date().toISOString(),
          });
        }
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('beresin_current_user_v1', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('beresin_current_user_v1');
    }
  }, [currentUser]);

  const refreshUser = () => {
    if (!currentUser) return;
    const fresh = BeresinDataStore.getUserById(currentUser.id);
    if (fresh) {
      setCurrentUser({ ...fresh });
    }
  };

  const login = async (email: string, password?: string): Promise<{ success: boolean; message: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const supabase = getSupabase();

    if (supabase && isSupabaseConfigured) {
      try {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password: password || '',
        });

        if (error) {
          // Fall back to local store in case accounts like mdqputra@gmail.com are used
          const fallbackRes = BeresinDataStore.authenticate(cleanEmail, password);
          if (fallbackRes.success && fallbackRes.user) {
            setCurrentUser(fallbackRes.user);
            return { success: true, message: fallbackRes.message };
          }
          return { success: false, message: error.message || 'Email atau password salah.' };
        }

        if (data.user) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', data.user.id)
            .single();

          const isSoleAdmin = cleanEmail === 'mdqputra@gmail.com';
          const userProfile: UserProfile = profile ? {
            id: profile.id,
            email: profile.email || data.user.email || '',
            full_name: profile.full_name || (isSoleAdmin ? 'Admin Utama BERESIN' : 'Mahasiswa'),
            whatsapp: profile.whatsapp || '',
            role: isSoleAdmin ? 'ADMIN' : (profile.role === 'ADMIN' ? 'STUDENT' : (profile.role || 'STUDENT')),
            voucher_balance: Number(profile.voucher_balance) || 0,
            voucher_code_used: profile.voucher_code_used,
            created_at: profile.created_at || new Date().toISOString(),
          } : {
            id: data.user.id,
            email: data.user.email || cleanEmail,
            full_name: data.user.user_metadata?.full_name || (isSoleAdmin ? 'Admin Utama BERESIN' : 'Mahasiswa'),
            whatsapp: data.user.user_metadata?.whatsapp || '',
            role: isSoleAdmin ? 'ADMIN' : 'STUDENT',
            voucher_balance: 0,
            created_at: new Date().toISOString(),
          };

          setCurrentUser(userProfile);
          return {
            success: true,
            message: userProfile.role === 'ADMIN' ? 'Login berhasil sebagai Admin Utama!' : `Selamat datang kembali, ${userProfile.full_name}!`
          };
        }
      } catch (err: any) {
        console.warn('Supabase auth login error, checking local store:', err);
      }
    }

    // Local authentication
    const result = BeresinDataStore.authenticate(cleanEmail, password);
    if (result.success && result.user) {
      setCurrentUser(result.user);
      return { success: true, message: result.message };
    }
    return { success: false, message: result.message };
  };

  const register = async (data: {
    full_name: string;
    email: string;
    whatsapp: string;
    password: string;
    voucher_code?: string;
  }) => {
    const cleanEmail = data.email.trim().toLowerCase();
    const supabase = getSupabase();
    let voucherBal = 0;
    let codeUsed: string | undefined = undefined;

    // Optional voucher code validation if provided
    if (data.voucher_code && data.voucher_code.trim()) {
      const voucherCheck = BeresinDataStore.validateVoucher(data.voucher_code);
      if (voucherCheck.valid && voucherCheck.voucher) {
        voucherBal = voucherCheck.voucher.value;
        codeUsed = voucherCheck.voucher.code;
      }
    }

    // 2. If Supabase configured, attempt Supabase Auth registration
    if (supabase && isSupabaseConfigured) {
      try {
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email: cleanEmail,
          password: data.password,
          options: {
            data: {
              full_name: data.full_name.trim(),
              whatsapp: data.whatsapp.trim(),
              role: 'STUDENT',
            },
          },
        });

        if (authError) {
          if (authError.message.includes('already registered')) {
            return { success: false, message: 'Email sudah terdaftar. Silakan langsung masuk.' };
          }
        } else if (authData.user) {
          // Create profile in Supabase table
          await supabase.from('profiles').upsert({
            id: authData.user.id,
            email: cleanEmail,
            full_name: data.full_name.trim(),
            whatsapp: data.whatsapp.trim(),
            role: 'STUDENT',
            voucher_balance: voucherBal,
            voucher_code_used: codeUsed,
          });
        }
      } catch (err) {
        console.warn('Supabase signUp error, continuing with local store sync:', err);
      }
    }

    // 3. Register in resilient DataStore
    const result = BeresinDataStore.registerStudent({
      full_name: data.full_name,
      email: cleanEmail,
      whatsapp: data.whatsapp,
      password: data.password,
      voucher_code: data.voucher_code,
    });

    if (result.success && result.user) {
      setCurrentUser(result.user);
    }
    return result;
  };

  const logout = () => {
    const supabase = getSupabase();
    if (supabase) {
      supabase.auth.signOut().catch(() => {});
    }
    setCurrentUser(null);
    localStorage.removeItem('beresin_current_user_v1');
  };

  const switchUser = (targetRole: UserRole) => {
    const users = BeresinDataStore.getUsers();
    const target = users.find(u => u.role === targetRole);
    if (target) {
      setCurrentUser(target);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        role: currentUser?.role || null,
        isAuthenticated: Boolean(currentUser),
        login,
        register,
        logout,
        switchUser,
        refreshUser,
        refreshProfile: refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export interface SeoServiceDetail {
  slug: string; // e.g. "jasa-ppt"
  serviceCodeMatch?: string; // matches ServiceItem code
  title: string;
  metaTitle: string;
  metaDescription: string;
  h1: string;
  shortDesc: string;
  targetAudience: string;
  startingPrice: number;
  badge: string;
  keywords: string[];
  deliverables: string[];
  whyUs: string[];
  faqs: { question: string; answer: string }[];
}

export const SEO_SERVICES: Record<string, SeoServiceDetail> = {
  'jasa-ppt': {
    slug: 'jasa-ppt',
    serviceCodeMatch: 'PPT-PRO',
    title: 'Jasa PPT & Edit Slide Presentasi Mahasiswa',
    metaTitle: 'Jasa PPT Mahasiswa & Jasa Edit PPT Profesional - BERESIN',
    metaDescription: 'Layanan jasa PPT mahasiswa & jasa edit PPT berkualitas tinggi, rapi, cepat, dan modern. Harga mulai Rp25.000 dengan garansi revisi dan voucher diskon Rp30.000.',
    h1: 'Jasa PPT Mahasiswa & Edit Slide Presentasi',
    shortDesc: 'Pembuatan slide presentasi PowerPoint dan Google Slides memukau, terstruktur rapi, siap pakai untuk sidang skripsi, seminar, dan tugas kuliah.',
    targetAudience: 'Mahasiswa, Dosen, Pelajar, dan Profesional yang butuh slide presentasi persuasif.',
    startingPrice: 25000,
    badge: 'Paling Populer',
    keywords: ['jasa PPT mahasiswa', 'jasa edit PPT', 'jasa powerpoint', 'slide presentasi skripsi', 'pembuatan slide seminar'],
    deliverables: [
      'Desain slide modern, proporsional, dan tidak monoton',
      'Struktur materi jelas, visual infografis & animasi halus',
      'Format file .pptx & .pdf siap presentasi',
      'Garansi revisi konten dan tampilan tanpa ribet',
      'Bisa negosiasi harga untuk jumlah slide banyak'
    ],
    whyUs: [
      'Pengerjaan express kilat bisa selesai dalam beberapa jam',
      'Bisa langsung dipotong voucher diskon Rp30.000',
      'Didukung konsultan presentasi berpengalaman'
    ],
    faqs: [
      {
        question: 'Apakah bisa memesan jasa edit PPT dari materi yang sudah ada?',
        answer: 'Tentu bisa! Anda cukup upload file PPT atau draft materi Word/catatan tugas. Tim BERESIN akan merapikan tata letak, menambahkan tipografi yang pas, dan mendesain ulang visualnya.'
      },
      {
        question: 'Berapa lama waktu pengerjaan jasa PPT mahasiswa?',
        answer: 'Standar pengerjaan mulai dari 6 hingga 24 jam tergantung jumlah slide dan tingkat kompleksitas materi. Tersedia opsi pengerjaan express jika mendekati deadline.'
      },
      {
        question: 'Apakah harga jasa PPT bisa dinegosiasikan?',
        answer: 'Ya! Fitur negosiasi harga tersedia di BERESIN. Anda dapat mengajukan penawaran harga dan admin kami akan memberikan opsi terbaik sesuai anggaran Anda.'
      }
    ]
  },
  'jasa-excel': {
    slug: 'jasa-excel',
    serviceCodeMatch: 'EXCEL-DATA',
    title: 'Jasa Excel & Otomasi Formula Spreadsheet',
    metaTitle: 'Jasa Excel Mahasiswa & Olah Data Spreadsheet - BERESIN',
    metaDescription: 'Layanan jasa Excel untuk mahasiswa & kantor. Perhitungan rumus VLOOKUP/XLOOKUP, pivot table, dashboard interaktif, dan rapikan data mulai Rp35.000.',
    h1: 'Jasa Excel & Pengolahan Spreadsheet',
    shortDesc: 'Solusi tuntas pembuatan rumus kompleks, pembersihan data, tabel pivot, analisis statistik, dan perancangan template dashboard Excel otomatis.',
    targetAudience: 'Mahasiswa pengolah data riset, staf administrasi, keuangan, dan bisnis online.',
    startingPrice: 35000,
    badge: 'Formula & Pivot',
    keywords: ['jasa Excel', 'jasa rapikan data Excel', 'rumus spreadsheet', 'olah data tugas', 'dashboard excel'],
    deliverables: [
      'Penerapan rumus lanjutan (INDEX MATCH, XLOOKUP, IF nested)',
      'Pembuatan Pivot Table, Slicer, dan Visualisasi Chart Dinamis',
      'Pembersihan duplicate data, formatting otomatis, data validation',
      'Template spreadsheet rapi dan mudah dioperasikan',
      'Konsultasi formula dan cara membaca data'
    ],
    whyUs: [
      'Akurasi 100% dengan pengecekan ganda oleh ahli data',
      'Format file Excel (.xlsx) atau Google Sheets fleksibel',
      'Bisa menggunakan voucher Rp30.000'
    ],
    faqs: [
      {
        question: 'Apakah bisa bantu mengerjakan tugas Excel kuliah atau skripsi?',
        answer: 'Bisa sekali! Kami membantu mahasiswa merapikan tabel riset, membuat rumus otomatis, serta memvisualisasikan hasil penelitian ke dalam grafik.'
      },
      {
        question: 'Bagaimana jika ada error rumus setelah file diserahkan?',
        answer: 'Seluruh pesanan di BERESIN dilindungi garansi revisi. Jika ada rumus yang keliru atau butuh penyesuaian, tim kami langsung memperbaikinya gratis.'
      }
    ]
  },
  'jasa-word': {
    slug: 'jasa-word',
    serviceCodeMatch: 'WORD-DOC',
    title: 'Jasa Word, Format Makalah & Skripsi',
    metaTitle: 'Jasa Word & Formatting Dokumen Tugas Mahasiswa - BERESIN',
    metaDescription: 'Layanan jasa Word untuk perapian format makalah, proposal, laporan, dan skripsi. Daftar isi otomatis, sitasi APA, margin standar kampus mulai Rp20.000.',
    h1: 'Jasa Word & Format Dokumen Akademik',
    shortDesc: 'Perapian dokumen Microsoft Word profesional: nomor halaman romawi/angka berbeda, daftar isi otomatis, margin, spasi, tabel, dan daftar pustaka.',
    targetAudience: 'Mahasiswa yang sedang menyusun tugas akhir, makalah kelompok, jurnal, dan skripsi.',
    startingPrice: 20000,
    badge: 'Standar Kampus',
    keywords: ['jasa Word', 'jasa format makalah', 'format skripsi', 'daftar isi otomatis word', 'rapikan dokumen word'],
    deliverables: [
      'Pengaturan Page Setup, Margin, dan Spasi sesuai pedoman kampus',
      'Daftar Isi, Daftar Tabel, dan Daftar Gambar otomatis (Heading styles)',
      'Penomoran halaman terpisah (Cover tanpa nomor, Romawi, & Angka)',
      'Perapian tabel, caption, dan penulisan sitasi/daftar pustaka',
      'Export file .docx dan .pdf resolusi tinggi'
    ],
    whyUs: [
      'Kerapian terjamin sesuai panduan akademik universitas Anda',
      'Proses pengerjaan cepat dan terstruktur rapi',
      'Bisa dikombinasikan dengan voucher potongan harga'
    ],
    faqs: [
      {
        question: 'Apakah formatnya bisa disesuaikan dengan buku pedoman kampus saya?',
        answer: 'Tentu saja! Anda cukup melampirkan file panduan atau template skripsi kampus Anda saat mengunggah pesanan.'
      },
      {
        question: 'Apakah BERESIN melayani cek plagiarisme dan paraphrasing?',
        answer: 'Kami menyediakan perapian tata bahasa, formatting dokumen, dan perbaikan struktur kalimat agar tulisan lebih akademis dan rapi.'
      }
    ]
  },
  'jasa-edit-video': {
    slug: 'jasa-edit-video',
    serviceCodeMatch: 'VIDEO-EDIT',
    title: 'Jasa Edit Video Tugas, Presentasi & Medsos',
    metaTitle: 'Jasa Edit Video Tugas & Presentasi Mahasiswa - BERESIN',
    metaDescription: 'Layanan jasa edit video tugas kuliah, video edukasi, presentasi, vlog, dan konten Reels/TikTok mulai Rp45.000. Lengkap teks subtitle, transisi, dan audio jernih.',
    h1: 'Jasa Edit Video Tugas & Presentasi',
    shortDesc: 'Editing video tugas perkuliahan, podcast, vlog tugas kelompok, presentasi multimedia, dan video edukasi dengan visual menarik serta audio berkualitas.',
    targetAudience: 'Mahasiswa, content creator pemula, organisasi kampus, dan UMKM.',
    startingPrice: 45000,
    badge: 'Resolusi HD/4K',
    keywords: ['jasa edit video', 'edit video tugas kuliah', 'video presentasi', 'subtitle video', 'edit video tiktok reels'],
    deliverables: [
      'Cutting, trimming, dan penyusunan alur cerita video yang menarik',
      'Penambahan subtitle/caption otomatis dan teks penjelasan',
      'Sound design: latar musik bebas hak cipta & peredaman noise audio',
      'Color grading dasar & transisi visual halus',
      'Export resolusi Full HD (1080p) atau 4K'
    ],
    whyUs: [
      'Editor profesional dengan pengalaman di industri multimedia',
      'Revisi fleksibel sampai tugas siap dinilai oleh dosen',
      'Dukungan format rasio 16:9 (YouTube/Laptop) dan 9:16 (TikTok/Reels)'
    ],
    faqs: [
      {
        question: 'Berapa lama video yang bisa diedit?',
        answer: 'Kami melayani dari durasi singkat 1-3 menit hingga video dokumenter panjang atau rekaman wawancara. Harga dapat dinegosiasikan sesuai durasi bahan.'
      },
      {
        question: 'Bagaimana cara mengirim file video mentah yang berukuran besar?',
        answer: 'Anda dapat mengunggah link Google Drive / Dropbox di formulir pesanan atau berkonsultasi langsung via WhatsApp.'
      }
    ]
  },
  'jasa-desain': {
    slug: 'jasa-desain',
    serviceCodeMatch: 'DESAIN-GRAFIS',
    title: 'Jasa Desain Poster, Banner & Infografis',
    metaTitle: 'Jasa Desain Grafis, Poster & Infografis Tugas - BERESIN',
    metaDescription: 'Layanan jasa desain grafis profesional untuk mahasiswa. Pembuatan poster ilmiah, infografis seminar, banner kegiatan, dan feed Instagram mulai Rp30.000.',
    h1: 'Jasa Desain Grafis & Infografis Ilmiah',
    shortDesc: 'Desain visual kreatif dan estetis untuk kebutuhan akademik, promosi event kampus, organisasi mahasiswa, infografis data riset, dan presentasi visual.',
    targetAudience: 'Mahasiswa, kepanitiaan acara, organisasi kemahasiswaan, dan wirausaha muda.',
    startingPrice: 30000,
    badge: 'Desain Kreatif',
    keywords: ['jasa desain', 'jasa desain poster', 'desain infografis ilmiah', 'desain banner kampus', 'jasa feed instagram'],
    deliverables: [
      'Desain original berkualitas tinggi dengan estetika modern',
      'Format output PNG, JPEG, dan PDF siap cetak (CMYK/RGB)',
      'Penyusunan tata letak hierarki teks yang mudah dibaca juri/dosen',
      'Revisi warna, font, dan elemen grafis cepat',
      'Tersedia file sumber jika dibutuhkan'
    ],
    whyUs: [
      'Tipografi dan pemilihan warna berstandar desain modern',
      'Dukungan berbagai ukuran standar (A4, A3, A2, Roll Banner)',
      'Harga bersahabat untuk kantong mahasiswa'
    ],
    faqs: [
      {
        question: 'Apakah bisa membuat poster untuk lomba ilmiah atau konferensi?',
        answer: 'Bisa! Kami sudah sering mengerjakan poster ilmiah untuk lomba PKM, seminar nasional, dan konferensi internasional.'
      }
    ]
  },
  'jasa-transkripsi': {
    slug: 'jasa-transkripsi',
    serviceCodeMatch: 'TRANSKRIP',
    title: 'Jasa Transkripsi Audio/Video Wawancara Skripsi',
    metaTitle: 'Jasa Transkripsi Audio & Wawancara Penelitian - BERESIN',
    metaDescription: 'Layanan jasa transkripsi audio dan rekaman wawancara skripsi ke teks Word. Akurat, bertanda waktu (timestamp), rapi, dan cepat mulai Rp25.000.',
    h1: 'Jasa Transkripsi Audio & Wawancara Riset',
    shortDesc: 'Konversi rekaman audio/video wawancara penelitian kualitatif, FGD, seminar, dan rekaman kuliah menjadi dokumen teks tertulis yang akurat dan rapi.',
    targetAudience: 'Mahasiswa peneliti kualitatif, dosen, jurnalis, dan notulen rapat.',
    startingPrice: 25000,
    badge: 'Akurat 99%',
    keywords: ['jasa transkripsi', 'transkrip wawancara skripsi', 'transkrip audio ke teks', 'transkrip FGD', 'notulen wawancara'],
    deliverables: [
      'Pengetikan verbatim (kata demi kata) atau clean verbatim (tanpa kata pengisi)',
      'Pemisahan pembicara yang jelas (Pewawancara vs Informan)',
      'Pemberian timestamp jika diperlukan untuk analisis data',
      'Pemeriksaan ejaan kata baku sesuai KBBI',
      'File Word (.docx) siap olah ke software analisis seperti NVivo/Atlas.ti'
    ],
    whyUs: [
      'Dikerjakan dengan teliti tanpa hanya mengandalkan AI mentah',
      'Kerahasiaan data responden terjamin 100%',
      'Bisa negosiasi tarif per menit audio'
    ],
    faqs: [
      {
        question: 'Bagaimana dengan kerahasiaan isi rekaman wawancara saya?',
        answer: 'Kami menjamin kerahasiaan 100%. File rekaman dan transkrip hanya diakses oleh tim pengolah dan tidak akan pernah dibagikan kepada pihak mana pun.'
      }
    ]
  },
  'jasa-input-data': {
    slug: 'jasa-input-data',
    serviceCodeMatch: 'DATA-CLEAN',
    title: 'Jasa Input Data, Rapikan Data & Tabulasi Kuesioner',
    metaTitle: 'Jasa Input Data & Tabulasi Kuesioner Mahasiswa - BERESIN',
    metaDescription: 'Layanan jasa input data kuesioner, tabulasi Google Form ke Excel, data skripsi, dan pembersihan file spreadsheet kotor. Cepat, teliti, terstruktur mulai Rp25.000.',
    h1: 'Jasa Input Data & Tabulasi Kuesioner',
    shortDesc: 'Pembersihan data mentah hasil survei Google Form, standarisasi penulisan, pengkodean (coding) data, dan tabulasi siap olah SPSS/Excel.',
    targetAudience: 'Mahasiswa yang sedang olah data skripsi, peneliti survei, dan analis data.',
    startingPrice: 25000,
    badge: 'Cepat & Teliti',
    keywords: ['jasa input data', 'jasa rapikan data', 'input data kuesioner', 'tabulasi data excel', 'data cleaning', 'koding survei'],
    deliverables: [
      'Pembersihan spasi berlebih, huruf kapital tak beraturan, dan nilai ganda',
      'Konversi data respon teks kuesioner ke skala angka (coding)',
      'Tabulasi data ke format siap uji SPSS, SmartPLS, atau R',
      'Pengecekan kelengkapan data responden (missing values)',
      'File Excel terstruktur rapi dengan label variabel jelas'
    ],
    whyUs: [
      'Format langsung cocok untuk pengujian statistik',
      'Ketelitian tinggi meminimalisir salah input',
      'Diskon voucher Rp30.000 langsung memotong biaya'
    ],
    faqs: [
      {
        question: 'Apakah bisa membantu tabulasi kuesioner Google Form ke Excel?',
        answer: 'Sangat bisa. Kami membantu mengelompokkan variabel, memberi skor skala Likert, dan merapikan tabel agar siap dianalisis.'
      }
    ]
  },
  'jasa-rapikan-data': {
    slug: 'jasa-input-data',
    serviceCodeMatch: 'DATA-CLEAN',
    title: 'Jasa Input Data, Rapikan Data & Tabulasi Kuesioner',
    metaTitle: 'Jasa Input Data & Tabulasi Kuesioner Mahasiswa - BERESIN',
    metaDescription: 'Layanan jasa input data kuesioner, tabulasi Google Form ke Excel, data skripsi, dan pembersihan file spreadsheet kotor. Cepat, teliti, terstruktur mulai Rp25.000.',
    h1: 'Jasa Input Data & Tabulasi Kuesioner',
    shortDesc: 'Pembersihan data mentah hasil survei Google Form, standarisasi penulisan, pengkodean (coding) data, dan tabulasi siap olah SPSS/Excel.',
    targetAudience: 'Mahasiswa yang sedang olah data skripsi, peneliti survei, dan analis data.',
    startingPrice: 25000,
    badge: 'Cepat & Teliti',
    keywords: ['jasa input data', 'jasa rapikan data', 'input data kuesioner', 'tabulasi data excel', 'data cleaning', 'koding survei'],
    deliverables: [
      'Pembersihan spasi berlebih, huruf kapital tak beraturan, dan nilai ganda',
      'Konversi data respon teks kuesioner ke skala angka (coding)',
      'Tabulasi data ke format siap uji SPSS, SmartPLS, atau R',
      'Pengecekan kelengkapan data responden (missing values)',
      'File Excel terstruktur rapi dengan label variabel jelas'
    ],
    whyUs: [
      'Format langsung cocok untuk pengujian statistik',
      'Ketelitian tinggi meminimalisir salah input',
      'Diskon voucher Rp30.000 langsung memotong biaya'
    ],
    faqs: [
      {
        question: 'Apakah bisa membantu tabulasi kuesioner Google Form ke Excel?',
        answer: 'Sangat bisa. Kami membantu mengelompokkan variabel, memberi skor skala Likert, dan merapikan tabel agar siap dianalisis.'
      }
    ]
  },
  'jasa-pdf': {
    slug: 'jasa-pdf',
    serviceCodeMatch: 'PDF-EDIT',
    title: 'Jasa Edit PDF, Merge & Konversi Dokumen',
    metaTitle: 'Jasa Edit PDF, Merge & Convert Dokumen Resmi - BERESIN',
    metaDescription: 'Layanan jasa edit PDF, gabung file, perbaiki teks salah ketik, ganti halaman, dan kompresi ukuran PDF tugas mulai Rp15.000.',
    h1: 'Jasa Edit PDF & Tata Ulang Dokumen',
    shortDesc: 'Solusi cepat edit isi teks PDF, ganti halaman, tanda tangan digital, kompresi ukuran file, proteksi password, dan konversi ke Word tanpa merusak layout.',
    targetAudience: 'Mahasiswa yang mengirim berkas beasiswa, wisuda, registrasi kampus, dan tugas kuliah.',
    startingPrice: 15000,
    badge: 'Proses Instan',
    keywords: ['jasa PDF', 'jasa edit PDF', 'gabung file PDF', 'kompres PDF tugas', 'convert PDF ke Word'],
    deliverables: [
      'Pengeditan teks atau angka pada dokumen PDF asli tanpa pecah',
      'Penggabungan (merge) dan pemisahan (split) halaman sesuai urutan',
      'Kompresi ukuran file agar sesuai batas upload portal kampus/beasiswa',
      'Konversi akurat dari PDF ke Word (.docx) dengan layout rapi',
      'Penyisipan tanda tangan digital & materai resmi'
    ],
    whyUs: [
      'Hasil jernih tanpa merusak resolusi dokumen',
      'Pengerjaan super kilat dalam hitungan menit',
      'Tarif sangat terjangkau bagi pelajar & mahasiswa'
    ],
    faqs: [
      {
        question: 'Apakah dokumen PDF yang di-scan bisa diedit?',
        answer: 'Bisa! Kami menggunakan teknologi OCR canggih untuk mengenali teks pada hasil scan dan memperbaikinya secara rapi.'
      }
    ]
  }
};

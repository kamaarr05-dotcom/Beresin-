-- =========================================================================
-- BERESIN DATABASE SCHEMA & SECURITY RULES (PostgreSQL + Supabase RLS)
-- Tagline: "Kirim pekerjaanmu. Kami yang bereskan."
-- =========================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUM TYPES
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('STUDENT', 'ADMIN');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE order_status AS ENUM (
        'MENUNGGU_HARGA',
        'MENUNGGU_PEMBAYARAN',
        'ANTRIAN',
        'DIKERJAKAN',
        'REVISI',
        'SELESAI',
        'DIBATALKAN'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE negotiation_status AS ENUM (
        'NONE',
        'PENDING',
        'ACCEPTED',
        'ADJUSTED',
        'REJECTED'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 3. PROFILES TABLE (Tied to Supabase Auth)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT NOT NULL,
    whatsapp TEXT NOT NULL,
    role user_role DEFAULT 'STUDENT',
    voucher_balance NUMERIC(10, 2) DEFAULT 0.00,
    voucher_code_used TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. SERVICES TABLE
CREATE TABLE IF NOT EXISTS public.services (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    base_price NUMERIC(10, 2) NOT NULL DEFAULT 20000.00,
    unit_label TEXT NOT NULL DEFAULT 'mulai Rp20.000',
    description TEXT,
    icon TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. VOUCHERS TABLE
-- "Satu kode voucher hanya dapat digunakan satu kali"
-- "Voucher bukan uang tunai dan tidak bisa dicairkan"
CREATE TABLE IF NOT EXISTS public.vouchers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code TEXT UNIQUE NOT NULL,
    value NUMERIC(10, 2) NOT NULL DEFAULT 30000.00,
    cost_price NUMERIC(10, 2) NOT NULL DEFAULT 10000.00,
    is_used BOOLEAN DEFAULT FALSE,
    used_by_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    used_by_email TEXT,
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. ORDERS TABLE
CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_number TEXT UNIQUE NOT NULL,
    student_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    student_name TEXT NOT NULL,
    student_email TEXT NOT NULL,
    student_whatsapp TEXT NOT NULL,
    service_id TEXT NOT NULL REFERENCES public.services(id),
    service_name TEXT NOT NULL,
    base_price NUMERIC(10, 2) NOT NULL,
    final_price NUMERIC(10, 2),
    voucher_deduction NUMERIC(10, 2) DEFAULT 0.00,
    amount_to_pay NUMERIC(10, 2) DEFAULT 0.00,
    status order_status DEFAULT 'MENUNGGU_HARGA',
    instructions TEXT NOT NULL,
    deadline TIMESTAMPTZ NOT NULL,
    file_name TEXT,
    file_url TEXT,
    file_size BIGINT,
    
    -- Negotiation details
    negotiation_requested BOOLEAN DEFAULT FALSE,
    negotiation_price NUMERIC(10, 2),
    negotiation_reason TEXT,
    negotiation_status negotiation_status DEFAULT 'NONE',
    admin_negotiation_note TEXT,

    -- Payment & QRIS
    payment_method TEXT DEFAULT 'QRIS',
    payment_confirmed BOOLEAN DEFAULT FALSE,
    payment_proof_url TEXT,
    payment_notes TEXT,

    -- Results & Delivery
    result_file_name TEXT,
    result_file_url TEXT,
    result_notes TEXT,
    completed_at TIMESTAMPTZ,

    -- Revisions
    revision_requested BOOLEAN DEFAULT FALSE,
    revision_notes TEXT,
    revision_requested_at TIMESTAMPTZ,

    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. ATOMIC SERVER-SIDE FUNCTION TO REDEEM VOUCHER
CREATE OR REPLACE FUNCTION public.redeem_voucher_code(
    p_code TEXT,
    p_user_id UUID,
    p_user_email TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_voucher RECORD;
BEGIN
    -- Check if voucher exists and is unused
    SELECT * INTO v_voucher 
    FROM public.vouchers 
    WHERE UPPER(code) = UPPER(p_code) 
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tidak ditemukan.');
    END IF;

    IF v_voucher.is_used THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher sudah pernah digunakan.');
    END IF;

    -- Mark voucher as used
    UPDATE public.vouchers
    SET is_used = TRUE,
        used_by_user_id = p_user_id,
        used_by_email = p_user_email,
        used_at = NOW()
    WHERE id = v_voucher.id;

    -- Credit user balance with Rp30.000
    UPDATE public.profiles
    SET voucher_balance = voucher_balance + v_voucher.value,
        voucher_code_used = UPPER(p_code),
        updated_at = NOW()
    WHERE id = p_user_id;

    RETURN jsonb_build_object(
        'success', true, 
        'message', 'Voucher berhasil diklaim!', 
        'value', v_voucher.value
    );
END;
$$;

-- 8. FUNCTION TO CALCULATE AND DEDUCT VOUCHER FOR AN ORDER
CREATE OR REPLACE FUNCTION public.apply_voucher_and_finalize_price(
    p_order_id UUID,
    p_final_price NUMERIC(10, 2)
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_order RECORD;
    v_student RECORD;
    v_voucher_to_deduct NUMERIC(10, 2) := 0.00;
    v_amount_to_pay NUMERIC(10, 2) := 0.00;
    v_new_status order_status;
BEGIN
    SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Pesanan tidak ditemukan.');
    END IF;

    SELECT * INTO v_student FROM public.profiles WHERE id = v_order.student_id FOR UPDATE;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Profil siswa tidak ditemukan.');
    END IF;

    -- Example logic:
    -- If final_price = 25.000 and student voucher = 30.000:
    -- deduction = 25.000, amount_to_pay = 0, new student voucher = 5.000
    -- If final_price = 45.000 and student voucher = 30.000:
    -- deduction = 30.000, amount_to_pay = 15.000, new student voucher = 0
    IF v_student.voucher_balance >= p_final_price THEN
        v_voucher_to_deduct := p_final_price;
        v_amount_to_pay := 0.00;
        v_new_status := 'ANTRIAN'; -- Langsung masuk antrian karena bayar Rp0
    ELSE
        v_voucher_to_deduct := v_student.voucher_balance;
        v_amount_to_pay := p_final_price - v_student.voucher_balance;
        v_new_status := 'MENUNGGU_PEMBAYARAN';
    END IF;

    -- Update order
    UPDATE public.orders
    SET final_price = p_final_price,
        voucher_deduction = v_voucher_to_deduct,
        amount_to_pay = v_amount_to_pay,
        status = v_new_status,
        payment_confirmed = (v_amount_to_pay = 0.00),
        updated_at = NOW()
    WHERE id = p_order_id;

    -- Deduct student voucher balance
    UPDATE public.profiles
    SET voucher_balance = voucher_balance - v_voucher_to_deduct,
        updated_at = NOW()
    WHERE id = v_student.id;

    RETURN jsonb_build_object(
        'success', true,
        'final_price', p_final_price,
        'voucher_deduction', v_voucher_to_deduct,
        'amount_to_pay', v_amount_to_pay,
        'status', v_new_status
    );
END;
$$;

-- 9. ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vouchers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Helper function to check if auth user is ADMIN
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND role = 'ADMIN'
    );
$$;

-- PROFILES POLICIES
-- Students can read & update their own profile
CREATE POLICY "Users can view own profile" 
ON public.profiles FOR SELECT 
USING (auth.uid() = id OR public.is_admin());

CREATE POLICY "Users can update own profile" 
ON public.profiles FOR UPDATE 
USING (auth.uid() = id OR public.is_admin());

-- SERVICES POLICIES
-- Anyone can view services
CREATE POLICY "Anyone can view active services" 
ON public.services FOR SELECT 
USING (true);

-- Only admin can modify services
CREATE POLICY "Admin can manage services" 
ON public.services FOR ALL 
USING (public.is_admin());

-- VOUCHERS POLICIES
-- Only admin can view all vouchers and create vouchers
CREATE POLICY "Admin can manage vouchers" 
ON public.vouchers FOR ALL 
USING (public.is_admin());

-- ORDERS POLICIES
-- Students can view their own orders; admin can view all
CREATE POLICY "Students can view own orders" 
ON public.orders FOR SELECT 
USING (student_id = auth.uid() OR public.is_admin());

-- Students can insert orders
CREATE POLICY "Students can create orders" 
ON public.orders FOR INSERT 
WITH CHECK (student_id = auth.uid());

-- Students can update their own orders (e.g., upload payment proof, request revision)
CREATE POLICY "Students can update own orders" 
ON public.orders FOR UPDATE 
USING (student_id = auth.uid() OR public.is_admin());

-- Admin can delete or modify all orders
CREATE POLICY "Admin has full order access" 
ON public.orders FOR ALL 
USING (public.is_admin());

-- 10. STORAGE BUCKET POLICIES (Supabase Storage)
-- In Supabase, create two buckets: 'beresin-order-files' (private) and 'beresin-result-files' (private/authenticated)
-- Files are stored with folder naming: <order_id>/<file_name>

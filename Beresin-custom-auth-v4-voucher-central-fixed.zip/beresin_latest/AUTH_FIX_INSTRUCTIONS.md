# BERESIN Auth Fix v2

## Why the two symptoms happened

1. Login could say success while the public page remained visible when Supabase Auth succeeded but the matching `profiles` row was missing/not readable. The client now waits for a real profile and has an idempotent `ensure_my_profile()` fallback. Auth state changes are also deferred so profile queries do not run inside the Supabase auth callback.
2. `Database error saving new user` can be caused by the Auth trigger failing while inserting `profiles` (including older schemas without `updated_at` or optional voucher logic). The new migration adds `updated_at` if absent and makes the Auth trigger only create the profile; optional voucher processing is deliberately not executed inside the Auth trigger.

## Required Supabase step

Run **only** `supabase/auth_migration.sql` in Supabase SQL Editor after the normal `supabase/schema.sql` schema exists.

Then verify:

```sql
select id, email, role from public.profiles
where lower(email) = 'mdqputra@gmail.com';
```

The `id` must match the `id` of `mdqputra@gmail.com` under Authentication > Users.

Also verify orphan profiles:

```sql
select p.id, p.email
from public.profiles p
left join auth.users u on u.id = p.id
where u.id is null;
```

Existing orphaned legacy profiles are intentionally not deleted or remapped automatically because other tables may reference their IDs.

## Admin

The app recognizes `mdqputra@gmail.com` as the single master admin, but the database remains the source of truth. If the Auth user already exists, the migration links/promotes its profile automatically. The password remains only in Supabase Auth.

## Build

```bash
npm install
npm run build
```

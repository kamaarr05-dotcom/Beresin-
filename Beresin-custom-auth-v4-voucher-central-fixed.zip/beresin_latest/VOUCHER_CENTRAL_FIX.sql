-- BERESIN — FIX VOUCHER CENTRAL
-- Jalankan SEKALI di Supabase SQL Editor setelah custom auth aktif.
-- Fungsi ini membuat klaim voucher, saldo user, dan status voucher admin
-- tersimpan terpusat di database sehingga sinkron antar HP/browser.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.vouchers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT UNIQUE NOT NULL,
    value NUMERIC(10, 2) NOT NULL DEFAULT 30000.00,
    cost_price NUMERIC(10, 2) NOT NULL DEFAULT 10000.00,
    is_used BOOLEAN NOT NULL DEFAULT FALSE,
    used_by_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    used_by_email TEXT,
    used_by_name TEXT,
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.vouchers ADD COLUMN IF NOT EXISTS used_by_name TEXT;

CREATE OR REPLACE FUNCTION public.redeem_voucher_code(
    p_code TEXT,
    p_user_id UUID,
    p_user_email TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
    v_voucher public.vouchers%ROWTYPE;
    v_user public.profiles%ROWTYPE;
BEGIN
    SELECT * INTO v_user
    FROM public.profiles
    WHERE id = p_user_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Pengguna tidak ditemukan.');
    END IF;

    SELECT * INTO v_voucher
    FROM public.vouchers
    WHERE UPPER(code) = UPPER(TRIM(p_code))
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tidak ditemukan.');
    END IF;

    IF v_voucher.is_used THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher sudah pernah digunakan.');
    END IF;

    UPDATE public.vouchers
    SET is_used = TRUE,
        used_by_user_id = v_user.id,
        used_by_email = v_user.email,
        used_by_name = v_user.full_name,
        used_at = NOW()
    WHERE id = v_voucher.id;

    UPDATE public.profiles
    SET voucher_balance = COALESCE(voucher_balance, 0) + v_voucher.value,
        voucher_code_used = UPPER(TRIM(p_code)),
        updated_at = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'success', true,
        'message', format('Selamat! Kode %s berhasil diklaim. Saldo bertambah Rp%s.', v_voucher.code, to_char(v_voucher.value, 'FM999G999G999')),
        'value', v_voucher.value,
        'voucher_code', v_voucher.code
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.custom_get_vouchers(
    p_admin_user_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
    v_is_admin BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = p_admin_user_id AND role = 'ADMIN'
    ) INTO v_is_admin;

    IF NOT v_is_admin THEN
        RETURN '[]'::jsonb;
    END IF;

    RETURN COALESCE(
        (SELECT jsonb_agg(to_jsonb(v) ORDER BY v.created_at DESC) FROM public.vouchers v),
        '[]'::jsonb
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.custom_create_voucher(
    p_admin_user_id UUID,
    p_code TEXT,
    p_value NUMERIC,
    p_cost_price NUMERIC
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
    v_admin public.profiles%ROWTYPE;
    v_voucher public.vouchers%ROWTYPE;
    v_code TEXT := UPPER(TRIM(p_code));
BEGIN
    SELECT * INTO v_admin FROM public.profiles WHERE id = p_admin_user_id;
    IF NOT FOUND OR v_admin.role <> 'ADMIN' THEN
        RETURN jsonb_build_object('success', false, 'message', 'Akses admin diperlukan.');
    END IF;

    IF v_code = '' THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tidak boleh kosong.');
    END IF;
    IF COALESCE(p_value, 0) <= 0 THEN
        RETURN jsonb_build_object('success', false, 'message', 'Nilai voucher harus lebih dari 0.');
    END IF;
    IF COALESCE(p_cost_price, 0) < 0 THEN
        RETURN jsonb_build_object('success', false, 'message', 'Harga beli voucher tidak valid.');
    END IF;

    IF EXISTS (SELECT 1 FROM public.vouchers WHERE UPPER(code) = v_code) THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tersebut sudah ada di database.');
    END IF;

    INSERT INTO public.vouchers (code, value, cost_price, is_used)
    VALUES (v_code, p_value, p_cost_price, FALSE)
    RETURNING * INTO v_voucher;

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Voucher berhasil dibuat.',
        'voucher', to_jsonb(v_voucher)
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.redeem_voucher_code(TEXT, UUID, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_get_vouchers(UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_create_voucher(UUID, TEXT, NUMERIC, NUMERIC) TO anon, authenticated;

SELECT 'Voucher central fix aktif.' AS status;

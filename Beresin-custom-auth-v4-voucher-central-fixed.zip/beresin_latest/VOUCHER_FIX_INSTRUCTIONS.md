# FIX VOUCHER CENTRAL BERESIN

Perbaikan ini membuat voucher benar-benar tersimpan di Supabase, bukan hanya di localStorage browser.

## Yang sudah diperbaiki
- User claim voucher melalui RPC database.
- Saldo `profiles.voucher_balance` bertambah di database.
- `profiles.voucher_code_used` diperbarui.
- Kode pada `public.vouchers` berubah menjadi `is_used = true`.
- Email, nama, dan waktu pemakaian voucher dicatat.
- Admin membaca daftar voucher dari database pusat.
- Pembuatan voucher admin juga masuk ke database pusat.
- Admin melakukan refresh otomatis setiap 5 detik agar klaim dari HP lain terlihat.

## Wajib dilakukan setelah deploy
1. Buka Supabase → SQL Editor.
2. Jalankan seluruh isi `VOUCHER_CENTRAL_FIX.sql` satu kali.
3. Deploy/build aplikasi dari ZIP ini.
4. Login admin dan buat kode voucher baru dari menu Voucher.
5. Dari HP user, klaim kode tersebut.
6. Saldo user harus bertambah sesuai nilai voucher.
7. Di HP admin, kode yang sama akan berubah menjadi `Sudah Digunakan`.

Voucher lama yang hanya pernah dibuat di localStorage browser tidak otomatis masuk database. Buat ulang voucher tersebut dari menu Admin agar menjadi voucher pusat.

-- BERESIN AUTH FIX v2
-- Run once in Supabase SQL Editor.
-- auth.users is the only authentication/password store.

-- 1) Keep profiles compatible with both the original table and newer schema.
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 2) Safe, idempotent profile creation. IMPORTANT: no voucher redemption here;
-- a failing optional voucher must never make Supabase Auth sign-up fail.
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (
    id,
    email,
    full_name,
    whatsapp,
    role,
    voucher_balance,
    voucher_code_used,
    created_at,
    updated_at
  )
  VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data ->> 'full_name'), ''), 'Mahasiswa BERESIN'),
    COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data ->> 'whatsapp'), ''), ''),
    CASE
      WHEN lower(COALESCE(NEW.email, '')) = 'mdqputra@gmail.com'
        THEN 'ADMIN'::user_role
      ELSE 'STUDENT'::user_role
    END,
    0,
    NULL,
    COALESCE(NEW.created_at, NOW()),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = EXCLUDED.full_name,
    whatsapp = EXCLUDED.whatsapp,
    updated_at = NOW();

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.handle_new_auth_user();

-- 3) Idempotent fallback for an Auth user whose profile is missing.
-- Only the currently authenticated user's UUID can be used.
CREATE OR REPLACE FUNCTION public.ensure_my_profile()
RETURNS public.profiles
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user auth.users%ROWTYPE;
  v_profile public.profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_user FROM auth.users WHERE id = auth.uid();
  IF v_user.id IS NULL THEN
    RAISE EXCEPTION 'Authenticated user not found';
  END IF;

  INSERT INTO public.profiles (
    id, email, full_name, whatsapp, role, voucher_balance, voucher_code_used,
    created_at, updated_at
  )
  VALUES (
    v_user.id,
    COALESCE(v_user.email, ''),
    COALESCE(NULLIF(TRIM(v_user.raw_user_meta_data ->> 'full_name'), ''), 'Mahasiswa BERESIN'),
    COALESCE(NULLIF(TRIM(v_user.raw_user_meta_data ->> 'whatsapp'), ''), ''),
    CASE
      WHEN lower(COALESCE(v_user.email, '')) = 'mdqputra@gmail.com'
        THEN 'ADMIN'::user_role
      ELSE 'STUDENT'::user_role
    END,
    0,
    NULL,
    COALESCE(v_user.created_at, NOW()),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = CASE WHEN EXCLUDED.full_name <> 'Mahasiswa BERESIN' THEN EXCLUDED.full_name ELSE public.profiles.full_name END,
    whatsapp = CASE WHEN EXCLUDED.whatsapp <> '' THEN EXCLUDED.whatsapp ELSE public.profiles.whatsapp END,
    updated_at = NOW();

  SELECT * INTO v_profile FROM public.profiles WHERE id = v_user.id;
  RETURN v_profile;
END;
$$;

REVOKE ALL ON FUNCTION public.ensure_my_profile() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.ensure_my_profile() TO authenticated;

-- 4) Admin role is reserved for the single designated Auth email.
CREATE OR REPLACE FUNCTION public.enforce_single_master_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.role = 'ADMIN'::user_role
     AND lower(COALESCE(NEW.email, '')) <> 'mdqputra@gmail.com' THEN
    RAISE EXCEPTION 'Only the designated BERESIN master admin can have ADMIN role';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS enforce_single_master_admin ON public.profiles;
CREATE TRIGGER enforce_single_master_admin
BEFORE INSERT OR UPDATE OF role, email ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.enforce_single_master_admin();

-- 5) Replace profile policies without deleting profile data.
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;

CREATE POLICY "Users can view own profile"
ON public.profiles FOR SELECT
TO authenticated
USING (auth.uid() = id OR public.is_admin());

CREATE POLICY "Users can update own profile"
ON public.profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id OR public.is_admin())
WITH CHECK (auth.uid() = id OR public.is_admin());

-- 6) Repair/link the designated admin if the Auth user already exists.
-- This uses auth.users.id, so it never creates a fake local Auth identity.
INSERT INTO public.profiles (
  id, email, full_name, whatsapp, role, voucher_balance, voucher_code_used,
  created_at, updated_at
)
SELECT
  u.id,
  COALESCE(u.email, ''),
  COALESCE(NULLIF(TRIM(u.raw_user_meta_data ->> 'full_name'), ''), 'Admin Utama BERESIN'),
  COALESCE(NULLIF(TRIM(u.raw_user_meta_data ->> 'whatsapp'), ''), ''),
  'ADMIN'::user_role,
  0,
  NULL,
  COALESCE(u.created_at, NOW()),
  NOW()
FROM auth.users u
WHERE lower(COALESCE(u.email, '')) = 'mdqputra@gmail.com'
ON CONFLICT (id) DO UPDATE SET
  email = EXCLUDED.email,
  role = 'ADMIN'::user_role,
  updated_at = NOW();

UPDATE public.profiles
SET role = 'STUDENT'::user_role, updated_at = NOW()
WHERE role = 'ADMIN'::user_role
  AND lower(email) <> 'mdqputra@gmail.com';

-- 7) Make function search paths explicit.
ALTER FUNCTION public.handle_new_auth_user() SET search_path = public;
ALTER FUNCTION public.ensure_my_profile() SET search_path = public;
ALTER FUNCTION public.enforce_single_master_admin() SET search_path = public;
ALTER FUNCTION public.is_admin() SET search_path = public;
ALTER FUNCTION public.redeem_voucher_code(TEXT, UUID, TEXT) SET search_path = public;
ALTER FUNCTION public.apply_voucher_and_finalize_price(UUID, NUMERIC) SET search_path = public;

-- Verification:
-- A) This should return the designated admin if the Auth account exists:
-- SELECT id, email, role FROM public.profiles WHERE lower(email)='mdqputra@gmail.com';
-- B) This should be empty for profiles that are supposed to be Auth accounts:
-- SELECT p.id,p.email FROM public.profiles p LEFT JOIN auth.users u ON u.id=p.id WHERE u.id IS NULL;

-- BERESIN CUSTOM AUTH (NO SUPABASE AUTH)
-- Run this SQL in Supabase SQL Editor.
-- Accounts are stored centrally in public.profiles, so a user registered on HP A
-- can log in from HP B. Supabase Auth / email confirmation is NOT used.

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Detach profiles from Supabase Auth.
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS password_hash TEXT;

-- Allow custom-auth accounts to exist without an auth.users row.
ALTER TABLE public.profiles ALTER COLUMN id DROP NOT NULL;
ALTER TABLE public.profiles ALTER COLUMN password_hash DROP NOT NULL;

-- Registration: password is hashed server-side with pgcrypto crypt().
CREATE OR REPLACE FUNCTION public.custom_register(
  p_full_name TEXT,
  p_email TEXT,
  p_whatsapp TEXT,
  p_password TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  v_id UUID;
  v_email TEXT := lower(trim(p_email));
  v_name TEXT := trim(p_full_name);
  v_whatsapp TEXT := trim(p_whatsapp);
  v_row public.profiles%ROWTYPE;
BEGIN
  IF v_name = '' OR v_email = '' OR v_whatsapp = '' OR p_password IS NULL OR length(p_password) < 6 THEN
    RETURN jsonb_build_object('success', false, 'message', 'Data pendaftaran tidak lengkap atau password minimal 6 karakter.');
  END IF;

  IF v_email = 'mdqputra@gmail.com' THEN
    RETURN jsonb_build_object('success', false, 'message', 'Email Admin Utama tidak dapat digunakan untuk pendaftaran mahasiswa.');
  END IF;

  IF EXISTS (SELECT 1 FROM public.profiles WHERE lower(email) = v_email) THEN
    RETURN jsonb_build_object('success', false, 'message', 'Email sudah terdaftar. Silakan langsung masuk.');
  END IF;

  v_id := gen_random_uuid();

  INSERT INTO public.profiles (id, email, full_name, whatsapp, role, voucher_balance, password_hash)
  VALUES (v_id, v_email, v_name, v_whatsapp, 'STUDENT', 0, crypt(p_password, gen_salt('bf', 12)))
  RETURNING * INTO v_row;

  RETURN jsonb_build_object(
    'success', true,
    'message', 'Pendaftaran berhasil! Akun langsung aktif dan sudah masuk.',
    'user', jsonb_build_object(
      'id', v_row.id,
      'email', v_row.email,
      'full_name', v_row.full_name,
      'whatsapp', v_row.whatsapp,
      'role', v_row.role,
      'voucher_balance', v_row.voucher_balance,
      'voucher_code_used', v_row.voucher_code_used,
      'created_at', v_row.created_at
    )
  );
END;
$$;

-- Login: password is verified on the database server.
CREATE OR REPLACE FUNCTION public.custom_login(
  p_email TEXT,
  p_password TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  v_row public.profiles%ROWTYPE;
  v_email TEXT := lower(trim(p_email));
BEGIN
  SELECT * INTO v_row FROM public.profiles
  WHERE lower(email) = v_email
  LIMIT 1;

  IF NOT FOUND OR v_row.password_hash IS NULL OR crypt(p_password, v_row.password_hash) <> v_row.password_hash THEN
    RETURN jsonb_build_object('success', false, 'message', 'Email atau password salah.');
  END IF;

  RETURN jsonb_build_object(
    'success', true,
    'message', CASE WHEN lower(v_row.email) = 'mdqputra@gmail.com' THEN 'Login berhasil sebagai Admin Utama!' ELSE 'Login berhasil!' END,
    'user', jsonb_build_object(
      'id', v_row.id,
      'email', v_row.email,
      'full_name', v_row.full_name,
      'whatsapp', v_row.whatsapp,
      'role', v_row.role,
      'voucher_balance', v_row.voucher_balance,
      'voucher_code_used', v_row.voucher_code_used,
      'created_at', v_row.created_at
    )
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.custom_get_profile(p_user_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE v_row public.profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_row FROM public.profiles WHERE id = p_user_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'message', 'Profil tidak ditemukan.');
  END IF;
  RETURN jsonb_build_object(
    'success', true,
    'user', jsonb_build_object(
      'id', v_row.id,
      'email', v_row.email,
      'full_name', v_row.full_name,
      'whatsapp', v_row.whatsapp,
      'role', v_row.role,
      'voucher_balance', v_row.voucher_balance,
      'voucher_code_used', v_row.voucher_code_used,
      'created_at', v_row.created_at
    )
  );
END;
$$;

-- Create/repair the single designated admin account.
CREATE OR REPLACE FUNCTION public.custom_ensure_admin()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE v_row public.profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_row FROM public.profiles WHERE lower(email) = 'mdqputra@gmail.com' LIMIT 1;
  IF NOT FOUND THEN
    INSERT INTO public.profiles (id,email,full_name,whatsapp,role,voucher_balance,password_hash)
    VALUES (gen_random_uuid(),'mdqputra@gmail.com','Admin Utama BERESIN','081234567890','ADMIN',0,crypt('Beresin@2026!',gen_salt('bf',12)))
    RETURNING * INTO v_row;
  ELSE
    UPDATE public.profiles SET role='ADMIN', password_hash=COALESCE(password_hash, crypt('Beresin@2026!',gen_salt('bf',12)))
    WHERE id=v_row.id RETURNING * INTO v_row;
  END IF;
  RETURN jsonb_build_object('success',true,'user_id',v_row.id);
END;
$$;

REVOKE ALL ON FUNCTION public.custom_register(TEXT,TEXT,TEXT,TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.custom_login(TEXT,TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.custom_get_profile(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.custom_register(TEXT,TEXT,TEXT,TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_login(TEXT,TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_get_profile(UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_ensure_admin() TO anon, authenticated;

SELECT public.custom_ensure_admin();


-- =========================================================================
-- CENTRAL VOUCHER MANAGEMENT FOR CUSTOM AUTH
-- =========================================================================
-- Voucher data is stored in public.vouchers, not browser localStorage.
-- These SECURITY DEFINER RPCs are required because custom auth does not use
-- auth.uid(). Admin identity is checked against public.profiles.

CREATE TABLE IF NOT EXISTS public.vouchers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT UNIQUE NOT NULL,
    value NUMERIC(10, 2) NOT NULL DEFAULT 30000.00,
    cost_price NUMERIC(10, 2) NOT NULL DEFAULT 10000.00,
    is_used BOOLEAN NOT NULL DEFAULT FALSE,
    used_by_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    used_by_email TEXT,
    used_by_name TEXT,
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.vouchers ADD COLUMN IF NOT EXISTS used_by_name TEXT;

CREATE OR REPLACE FUNCTION public.redeem_voucher_code(
    p_code TEXT,
    p_user_id UUID,
    p_user_email TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
    v_voucher public.vouchers%ROWTYPE;
    v_user public.profiles%ROWTYPE;
BEGIN
    SELECT * INTO v_user
    FROM public.profiles
    WHERE id = p_user_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Pengguna tidak ditemukan.');
    END IF;

    SELECT * INTO v_voucher
    FROM public.vouchers
    WHERE UPPER(code) = UPPER(TRIM(p_code))
    FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tidak ditemukan.');
    END IF;

    IF v_voucher.is_used THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher sudah pernah digunakan.');
    END IF;

    UPDATE public.vouchers
    SET is_used = TRUE,
        used_by_user_id = v_user.id,
        used_by_email = v_user.email,
        used_by_name = v_user.full_name,
        used_at = NOW()
    WHERE id = v_voucher.id;

    UPDATE public.profiles
    SET voucher_balance = COALESCE(voucher_balance, 0) + v_voucher.value,
        voucher_code_used = UPPER(TRIM(p_code)),
        updated_at = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'success', true,
        'message', format('Selamat! Kode %s berhasil diklaim. Saldo bertambah Rp%s.', v_voucher.code, to_char(v_voucher.value, 'FM999G999G999')),
        'value', v_voucher.value,
        'voucher_code', v_voucher.code
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.custom_get_vouchers(
    p_admin_user_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
    v_is_admin BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = p_admin_user_id AND role = 'ADMIN'
    ) INTO v_is_admin;

    IF NOT v_is_admin THEN
        RETURN '[]'::jsonb;
    END IF;

    RETURN COALESCE(
        (SELECT jsonb_agg(to_jsonb(v) ORDER BY v.created_at DESC) FROM public.vouchers v),
        '[]'::jsonb
    );
END;
$$;

CREATE OR REPLACE FUNCTION public.custom_create_voucher(
    p_admin_user_id UUID,
    p_code TEXT,
    p_value NUMERIC,
    p_cost_price NUMERIC
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
    v_admin public.profiles%ROWTYPE;
    v_voucher public.vouchers%ROWTYPE;
    v_code TEXT := UPPER(TRIM(p_code));
BEGIN
    SELECT * INTO v_admin FROM public.profiles WHERE id = p_admin_user_id;
    IF NOT FOUND OR v_admin.role <> 'ADMIN' THEN
        RETURN jsonb_build_object('success', false, 'message', 'Akses admin diperlukan.');
    END IF;

    IF v_code = '' THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tidak boleh kosong.');
    END IF;
    IF COALESCE(p_value, 0) <= 0 THEN
        RETURN jsonb_build_object('success', false, 'message', 'Nilai voucher harus lebih dari 0.');
    END IF;
    IF COALESCE(p_cost_price, 0) < 0 THEN
        RETURN jsonb_build_object('success', false, 'message', 'Harga beli voucher tidak valid.');
    END IF;

    IF EXISTS (SELECT 1 FROM public.vouchers WHERE UPPER(code) = v_code) THEN
        RETURN jsonb_build_object('success', false, 'message', 'Kode voucher tersebut sudah ada di database.');
    END IF;

    INSERT INTO public.vouchers (code, value, cost_price, is_used)
    VALUES (v_code, p_value, p_cost_price, FALSE)
    RETURNING * INTO v_voucher;

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Voucher berhasil dibuat.',
        'voucher', to_jsonb(v_voucher)
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.redeem_voucher_code(TEXT, UUID, TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_get_vouchers(UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_create_voucher(UUID, TEXT, NUMERIC, NUMERIC) TO anon, authenticated;

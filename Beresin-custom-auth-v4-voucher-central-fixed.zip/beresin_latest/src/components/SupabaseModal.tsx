import React, { useState } from 'react';
import { 
  X, 
  Database, 
  CheckCircle2, 
  Copy, 
  Check, 
  ShieldCheck, 
  ExternalLink,
  Lock,
  Layers,
  FileCode
} from 'lucide-react';
import { isSupabaseConfigured } from '../lib/supabase';

interface SupabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupabaseModal: React.FC<SupabaseModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'sql'>('info');

  if (!isOpen) return null;

  const sqlSchemaSnippet = `-- BERESIN AUTH FIX v2
-- Jalankan file supabase/auth_migration.sql di SQL Editor.
-- Auth/password tetap sepenuhnya dikelola Supabase Auth.

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

CREATE OR REPLACE FUNCTION public.ensure_my_profile()
RETURNS public.profiles
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_user auth.users%ROWTYPE; v_profile public.profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_user FROM auth.users WHERE id = auth.uid();
  IF v_user.id IS NULL THEN RAISE EXCEPTION 'Authenticated user not found'; END IF;
  INSERT INTO public.profiles (id,email,full_name,whatsapp,role,voucher_balance,voucher_code_used,created_at,updated_at)
  VALUES (v_user.id,COALESCE(v_user.email,''),COALESCE(NULLIF(TRIM(v_user.raw_user_meta_data->>'full_name'),''),'Mahasiswa BERESIN'),COALESCE(NULLIF(TRIM(v_user.raw_user_meta_data->>'whatsapp'),''),''),CASE WHEN lower(COALESCE(v_user.email,''))='mdqputra@gmail.com' THEN 'ADMIN'::user_role ELSE 'STUDENT'::user_role END,0,NULL,COALESCE(v_user.created_at,NOW()),NOW())
  ON CONFLICT (id) DO UPDATE SET email=EXCLUDED.email,updated_at=NOW();
  SELECT * INTO v_profile FROM public.profiles WHERE id=v_user.id;
  RETURN v_profile;
END; $$;

GRANT EXECUTE ON FUNCTION public.ensure_my_profile() TO authenticated;

-- Trigger auth.users -> profiles dan RLS lengkap tersedia di:
-- supabase/auth_migration.sql`

  const handleCopySql = () => {
    navigator.clipboard.writeText(sqlSchemaSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">
                Arsitektur Supabase & PostgreSQL
              </h3>
              <p className="text-xs text-slate-500">
                Auth, PostgreSQL Database, Private Storage, dan RLS Security
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 px-5 pt-2 gap-4 text-xs font-bold bg-white">
          <button
            onClick={() => setActiveTab('info')}
            className={`pb-2.5 border-b-2 transition-colors ${
              activeTab === 'info'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Ringkasan Keamanan & Status
          </button>
          <button
            onClick={() => setActiveTab('sql')}
            className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'sql'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Skema SQL Supabase</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-700 flex-1">
          {activeTab === 'info' ? (
            <div className="space-y-4">
              
              {/* Status Banner */}
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-bold text-emerald-950 text-sm">
                    {isSupabaseConfigured 
                      ? 'Terkoneksi ke Supabase Live!' 
                      : 'Mode Operasional Aktif (Local Engine + Supabase Ready)'}
                  </p>
                  <p className="text-emerald-800 leading-relaxed text-xs">
                    {isSupabaseConfigured
                      ? 'Aplikasi berjalan terhubung langsung ke Supabase URL dan Anon Key kamu.'
                      : 'Aplikasi siap digunakan secara interaktif penuh (login, voucher balance, negosiasi harga, upload file, konfirmasi QRIS). Untuk menghubungkan ke Cloud Supabase langsung, cukup masukkan VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY ke file .env.'}
                  </p>
                </div>
              </div>

              {/* Security Mandates Checklist */}
              <div className="space-y-2">
                <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Kepatuhan Aturan Keamanan & RLS</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50">
                    <p className="font-bold text-slate-900">1. Supabase RLS (Row Level Security)</p>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Siswa hanya dapat mengakses pesanan dan data profil miliknya sendiri. Admin memiliki akses manajemen menyeluruh.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50">
                    <p className="font-bold text-slate-900">2. Validasi Server/Database</p>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Perhitungan potongan voucher divalidasi ketat di sisi server/database dengan fungsi atomic `apply_voucher_and_finalize_price`.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50">
                    <p className="font-bold text-slate-900">3. Single-Use Voucher Code</p>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Satu kode voucher hanya dapat digunakan satu kali. Kode divalidasi dan ditandai `is_used = true`.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50">
                    <p className="font-bold text-slate-900">4. Private Supabase Storage</p>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Berkas tugas tersimpan di bucket privat (hanya siswa pemesan dan admin pengerja yang dapat mengakses).
                    </p>
                  </div>
                </div>
              </div>

            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[11px] text-slate-500">
                  File: /supabase/schema.sql
                </span>
                <button
                  onClick={handleCopySql}
                  className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Tersalin!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Salin Semua SQL</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-3.5 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-2xl overflow-x-auto leading-relaxed max-h-96 border border-slate-800">
                {sqlSchemaSnippet}
              </pre>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-slate-100 bg-slate-50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 text-white font-bold rounded-xl text-xs"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};

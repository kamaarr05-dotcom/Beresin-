# BERESIN Custom Auth v2 — akun terpusat

Versi ini **tidak menggunakan Supabase Auth**.

Akun disimpan di `public.profiles` pada database Supabase melalui RPC PostgreSQL. Jadi akun yang dibuat di HP A dapat login di HP B dengan email dan password yang sama.

## Setup satu kali
1. Buka Supabase Dashboard → SQL Editor.
2. Jalankan **`CUSTOM_AUTH_DATABASE_SETUP.sql`**.
3. Pastikan `.env` berisi `VITE_SUPABASE_URL` dan `VITE_SUPABASE_ANON_KEY`.
4. Build/deploy aplikasi.

## Hasil
- Daftar tidak mengirim email.
- Tidak ada `supabase.auth.signUp()`.
- Login tidak memakai `supabase.auth.signInWithPassword()`.
- Password di-hash di PostgreSQL dengan `pgcrypto`.
- Session ID disimpan lokal hanya untuk mengingat akun pada perangkat tersebut; kredensial tetap berada di database pusat.
- Admin utama: `mdqputra@gmail.com` / `Beresin@2026!`

## Penting
Custom Auth ini adalah autentikasi aplikasi sendiri. Untuk produksi, sebaiknya tambahkan rate limiting/login-attempt logging di server dan mekanisme reset password yang aman.

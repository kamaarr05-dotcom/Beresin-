-- BERESIN CUSTOM AUTH (NO SUPABASE AUTH)
-- Run this SQL in Supabase SQL Editor.
-- Accounts are stored centrally in public.profiles, so a user registered on HP A
-- can log in from HP B. Supabase Auth / email confirmation is NOT used.

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Detach profiles from Supabase Auth.
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS password_hash TEXT;

-- Allow custom-auth accounts to exist without an auth.users row.
ALTER TABLE public.profiles ALTER COLUMN id DROP NOT NULL;
ALTER TABLE public.profiles ALTER COLUMN password_hash DROP NOT NULL;

-- Registration: password is hashed server-side with pgcrypto crypt().
CREATE OR REPLACE FUNCTION public.custom_register(
  p_full_name TEXT,
  p_email TEXT,
  p_whatsapp TEXT,
  p_password TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  v_id UUID;
  v_email TEXT := lower(trim(p_email));
  v_name TEXT := trim(p_full_name);
  v_whatsapp TEXT := trim(p_whatsapp);
  v_row public.profiles%ROWTYPE;
BEGIN
  IF v_name = '' OR v_email = '' OR v_whatsapp = '' OR p_password IS NULL OR length(p_password) < 6 THEN
    RETURN jsonb_build_object('success', false, 'message', 'Data pendaftaran tidak lengkap atau password minimal 6 karakter.');
  END IF;

  IF v_email = 'mdqputra@gmail.com' THEN
    RETURN jsonb_build_object('success', false, 'message', 'Email Admin Utama tidak dapat digunakan untuk pendaftaran mahasiswa.');
  END IF;

  IF EXISTS (SELECT 1 FROM public.profiles WHERE lower(email) = v_email) THEN
    RETURN jsonb_build_object('success', false, 'message', 'Email sudah terdaftar. Silakan langsung masuk.');
  END IF;

  v_id := gen_random_uuid();

  INSERT INTO public.profiles (id, email, full_name, whatsapp, role, voucher_balance, password_hash)
  VALUES (v_id, v_email, v_name, v_whatsapp, 'STUDENT', 0, crypt(p_password, gen_salt('bf', 12)))
  RETURNING * INTO v_row;

  RETURN jsonb_build_object(
    'success', true,
    'message', 'Pendaftaran berhasil! Akun langsung aktif dan sudah masuk.',
    'user', jsonb_build_object(
      'id', v_row.id,
      'email', v_row.email,
      'full_name', v_row.full_name,
      'whatsapp', v_row.whatsapp,
      'role', v_row.role,
      'voucher_balance', v_row.voucher_balance,
      'voucher_code_used', v_row.voucher_code_used,
      'created_at', v_row.created_at
    )
  );
END;
$$;

-- Login: password is verified on the database server.
CREATE OR REPLACE FUNCTION public.custom_login(
  p_email TEXT,
  p_password TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  v_row public.profiles%ROWTYPE;
  v_email TEXT := lower(trim(p_email));
BEGIN
  SELECT * INTO v_row FROM public.profiles
  WHERE lower(email) = v_email
  LIMIT 1;

  IF NOT FOUND OR v_row.password_hash IS NULL OR crypt(p_password, v_row.password_hash) <> v_row.password_hash THEN
    RETURN jsonb_build_object('success', false, 'message', 'Email atau password salah.');
  END IF;

  RETURN jsonb_build_object(
    'success', true,
    'message', CASE WHEN lower(v_row.email) = 'mdqputra@gmail.com' THEN 'Login berhasil sebagai Admin Utama!' ELSE 'Login berhasil!' END,
    'user', jsonb_build_object(
      'id', v_row.id,
      'email', v_row.email,
      'full_name', v_row.full_name,
      'whatsapp', v_row.whatsapp,
      'role', v_row.role,
      'voucher_balance', v_row.voucher_balance,
      'voucher_code_used', v_row.voucher_code_used,
      'created_at', v_row.created_at
    )
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.custom_get_profile(p_user_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE v_row public.profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_row FROM public.profiles WHERE id = p_user_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'message', 'Profil tidak ditemukan.');
  END IF;
  RETURN jsonb_build_object(
    'success', true,
    'user', jsonb_build_object(
      'id', v_row.id,
      'email', v_row.email,
      'full_name', v_row.full_name,
      'whatsapp', v_row.whatsapp,
      'role', v_row.role,
      'voucher_balance', v_row.voucher_balance,
      'voucher_code_used', v_row.voucher_code_used,
      'created_at', v_row.created_at
    )
  );
END;
$$;

-- Create/repair the single designated admin account.
CREATE OR REPLACE FUNCTION public.custom_ensure_admin()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE v_row public.profiles%ROWTYPE;
BEGIN
  SELECT * INTO v_row FROM public.profiles WHERE lower(email) = 'mdqputra@gmail.com' LIMIT 1;
  IF NOT FOUND THEN
    INSERT INTO public.profiles (id,email,full_name,whatsapp,role,voucher_balance,password_hash)
    VALUES (gen_random_uuid(),'mdqputra@gmail.com','Admin Utama BERESIN','081234567890','ADMIN',0,crypt('Beresin@2026!',gen_salt('bf',12)))
    RETURNING * INTO v_row;
  ELSE
    UPDATE public.profiles SET role='ADMIN', password_hash=COALESCE(password_hash, crypt('Beresin@2026!',gen_salt('bf',12)))
    WHERE id=v_row.id RETURNING * INTO v_row;
  END IF;
  RETURN jsonb_build_object('success',true,'user_id',v_row.id);
END;
$$;

REVOKE ALL ON FUNCTION public.custom_register(TEXT,TEXT,TEXT,TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.custom_login(TEXT,TEXT) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.custom_get_profile(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.custom_register(TEXT,TEXT,TEXT,TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_login(TEXT,TEXT) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_get_profile(UUID) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.custom_ensure_admin() TO anon, authenticated;

SELECT public.custom_ensure_admin();

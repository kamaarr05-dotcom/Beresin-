import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile, UserRole } from '../types';
import { BeresinDataStore } from '../lib/supabase';

interface AuthContextType {
  currentUser: UserProfile | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  login: (email: string, password?: string) => Promise<{ success: boolean; message: string }>;
  register: (data: {
    full_name: string;
    email: string;
    whatsapp: string;
    password: string;
    voucher_code?: string;
  }) => Promise<{ success: boolean; message: string; user?: UserProfile }>;
  logout: () => void;
  switchUser: (role: UserRole) => void;
  refreshUser: () => void;
  refreshProfile: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// ---------------------------------------------------------------------------
// BERESIN CUSTOM AUTH — CENTRAL DATABASE
// ---------------------------------------------------------------------------
// Supabase Auth is intentionally NOT used. Accounts are stored centrally in
// public.profiles through SECURITY DEFINER RPC functions. This means an account
// registered on HP A can log in from HP B, while passwords remain hashed in DB.
const SESSION_KEY = 'beresin_custom_session_v2';
const ADMIN_EMAIL = 'mdqputra@gmail.com';
const ADMIN_DEFAULT_PASSWORD = 'Beresin@2026!';

const asProfile = (value: any): UserProfile | null => {
  if (!value?.id || !value?.email) return null;
  return {
    id: String(value.id),
    email: String(value.email).trim().toLowerCase(),
    full_name: String(value.full_name || ''),
    whatsapp: String(value.whatsapp || ''),
    role: String(value.email).trim().toLowerCase() === ADMIN_EMAIL ? 'ADMIN' : 'STUDENT',
    voucher_balance: Number(value.voucher_balance) || 0,
    voucher_code_used: value.voucher_code_used || undefined,
    created_at: String(value.created_at || new Date().toISOString()),
  };
};

const getSessionUserId = () => {
  try { return localStorage.getItem(SESSION_KEY); } catch { return null; }
};
const setSessionUserId = (id: string) => {
  try { localStorage.setItem(SESSION_KEY, id); } catch { /* ignore */ }
};
const clearSession = () => {
  try { localStorage.removeItem(SESSION_KEY); } catch { /* ignore */ }
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);

  const hydrateUser = (user: UserProfile | null) => {
    if (!user) { setCurrentUser(null); return null; }
    // Keep a local copy only as an application cache. The source of truth for
    // authentication/account existence is the Supabase database RPC.
    BeresinDataStore.saveUsers([user, ...BeresinDataStore.getUsers().filter(u => u.id !== user.id)]);
    setCurrentUser(user);
    return user;
  };

  const loadRemoteProfile = async (userId: string) => {
    const supabase = getSupabase();
    if (!supabase) return null;
    const { data, error } = await supabase.rpc('custom_get_profile', { p_user_id: userId });
    if (error || !data?.success) return null;
    return asProfile(data.user);
  };

  useEffect(() => {
    // Remove sessions/credentials from the previous browser-only versions.
    try {
      localStorage.removeItem('beresin_custom_session_v1');
      localStorage.removeItem('beresin_custom_credentials_v1');
      localStorage.removeItem('beresin_current_user_v1');
      localStorage.removeItem('beresin:register-last-attempt');
    } catch { /* ignore */ }

    const supabase = getSupabase();
    if (!supabase) return;

    // Ensure the designated admin exists centrally.
    void supabase.rpc('custom_ensure_admin').catch(() => undefined);

    const sessionId = getSessionUserId();
    if (sessionId) {
      void loadRemoteProfile(sessionId).then(profile => {
        if (profile) hydrateUser(profile);
        else clearSession();
      });
    }
  }, []);

  const refreshUser = () => {
    if (!currentUser) return;
    void loadRemoteProfile(currentUser.id).then(profile => {
      if (profile) hydrateUser(profile);
    });
  };

  const login = async (email: string, password?: string) => {
    const cleanEmail = email.trim().toLowerCase();
    if (!password) return { success: false, message: 'Password wajib diisi.' };

    const supabase = getSupabase();
    if (!supabase) return { success: false, message: 'Database belum terhubung. Periksa VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY.' };

    try {
      const { data, error } = await supabase.rpc('custom_login', {
        p_email: cleanEmail,
        p_password: password,
      });
      if (error) return { success: false, message: error.message || 'Login gagal.' };
      if (!data?.success) return { success: false, message: data?.message || 'Email atau password salah.' };

      const profile = asProfile(data.user);
      if (!profile) return { success: false, message: 'Data akun tidak valid.' };
      setSessionUserId(profile.id);
      hydrateUser(profile);
      return { success: true, message: data.message || 'Login berhasil!' };
    } catch (error: any) {
      return { success: false, message: error?.message || 'Login gagal. Silakan coba lagi.' };
    }
  };

  const register = async (data: {
    full_name: string;
    email: string;
    whatsapp: string;
    password: string;
    voucher_code?: string;
  }) => {
    const cleanEmail = data.email.trim().toLowerCase();
    const fullName = data.full_name.trim();
    const whatsapp = data.whatsapp.trim();

    if (!fullName || !cleanEmail || !whatsapp || !data.password) {
      return { success: false, message: 'Semua data pendaftaran wajib diisi.' };
    }
    if (data.password.length < 6) return { success: false, message: 'Password minimal 6 karakter.' };
    if (cleanEmail === ADMIN_EMAIL) return { success: false, message: 'Email Admin Utama tidak dapat digunakan untuk pendaftaran mahasiswa.' };

    const supabase = getSupabase();
    if (!supabase) return { success: false, message: 'Database belum terhubung. Periksa konfigurasi Supabase.' };

    try {
      const { data: result, error } = await supabase.rpc('custom_register', {
        p_full_name: fullName,
        p_email: cleanEmail,
        p_whatsapp: whatsapp,
        p_password: data.password,
      });
      if (error) return { success: false, message: error.message || 'Pendaftaran gagal.' };
      if (!result?.success) return { success: false, message: result?.message || 'Pendaftaran gagal.' };

      const profile = asProfile(result.user);
      if (!profile) return { success: false, message: 'Akun dibuat tetapi data profil tidak dapat dibaca.' };
      setSessionUserId(profile.id);
      hydrateUser(profile);
      return { success: true, message: result.message || 'Pendaftaran berhasil! Akun langsung aktif dan sudah masuk.', user: profile };
    } catch (error: any) {
      return { success: false, message: error?.message || 'Pendaftaran gagal. Silakan coba lagi.' };
    }
  };

  const logout = () => {
    clearSession();
    setCurrentUser(null);
  };

  const switchUser = (_targetRole: UserRole) => {
    // Kept for backwards compatibility. Actual role comes from the database.
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        role: currentUser?.role || null,
        isAuthenticated: Boolean(currentUser),
        login,
        register,
        logout,
        switchUser,
        refreshUser,
        refreshProfile: refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

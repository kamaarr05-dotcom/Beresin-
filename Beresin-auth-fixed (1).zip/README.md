# BERESIN

Website BERESIN berbasis React/Vite dengan Supabase Auth.

## Menjalankan

1. `npm install`
2. Isi `VITE_SUPABASE_URL` dan `VITE_SUPABASE_ANON_KEY` di environment/Secrets.
3. Jalankan `supabase/schema.sql`, lalu `supabase/auth_migration.sql` di Supabase SQL Editor.
4. `npm run dev`
5. Build produksi: `npm run build`

## Autentikasi

- Register menggunakan `supabase.auth.signUp({ email, password })`.
- Login menggunakan `supabase.auth.signInWithPassword()`.
- Session dikelola oleh Supabase Auth; tidak ada password di `profiles`, localStorage, atau sessionStorage.
- Logout menggunakan `supabase.auth.signOut()`.
- Trigger database membuat `profiles.id` dari `auth.users.id`.
- Email `mdqputra@gmail.com` adalah satu-satunya email yang dapat memiliki role `ADMIN`.

### Master Admin

Password master admin **tidak disimpan di source code**.

Jika Auth user `mdqputra@gmail.com` belum ada, lakukan bootstrap satu kali dari mesin yang dipercaya:

```bash
SUPABASE_URL="https://PROJECT.supabase.co" SUPABASE_SERVICE_ROLE_KEY="SERVICE_ROLE_KEY" BERESIN_ADMIN_PASSWORD="PASSWORD_ADMIN" npm run bootstrap-admin
```

Gunakan password admin yang Anda tetapkan. Service-role key hanya untuk script bootstrap di sisi server/mesin admin dan **jangan pernah** dimasukkan ke frontend, `.env` yang dibundel, GitHub Pages, atau source code publik.

Setelah bootstrap, akun akan terlihat di Supabase → Authentication → Users dan profile-nya akan terhubung dengan UUID Auth yang sama. Login dari device/browser lain dilakukan dengan email + password tersebut.

## SQL

`supabase/auth_migration.sql`:
- memasang trigger `auth.users -> profiles`;
- memperbaiki linkage Auth/profile yang sudah ada tanpa menghapus row;
- menetapkan master admin;
- menghapus jalur INSERT/UPDATE profile langsung dari client;
- mempertahankan RLS.

## Catatan

Data layanan/order/voucher legacy pada `localStorage` tetap dipertahankan karena berada di luar scope audit Auth. Local storage tersebut **tidak digunakan sebagai sumber autentikasi atau penyimpan password**.

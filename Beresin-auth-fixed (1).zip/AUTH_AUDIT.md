# BERESIN Auth Audit

## Result
Auth flow has been consolidated on Supabase Auth.

### Register
`src/context/AuthContext.tsx` calls:
- `supabase.auth.signUp({ email, password, options.data })`
- Profile linkage is server-side through `auth.users` trigger using `NEW.id`.
- Password is never sent to `profiles`.

### Login
`src/context/AuthContext.tsx` calls:
- `supabase.auth.signInWithPassword({ email, password })`
- The authenticated UUID is used to load `public.profiles`.
- Supabase's persisted session is the only session source.

### Logout
Uses `supabase.auth.signOut()`.

### Legacy auth
No local login/register/password authentication path remains.
`localStorage` is still used by the existing non-auth application data store for services/orders/vouchers/payment configuration. It is not used to authenticate users and password fields are stripped from legacy user metadata.

### Database
`supabase/auth_migration.sql`:
- installs/replaces `auth.users` -> `profiles` trigger;
- guarantees `profiles.id = auth.users.id`;
- creates missing profiles for existing Auth users without deleting data;
- hardens profile RLS;
- prevents client profile changes through the browser;
- enforces `mdqputra@gmail.com` as the only ADMIN email.

### Master admin
The password is deliberately not embedded in source code. `scripts/bootstrap-admin.mjs` uses Supabase's server-side Admin API and reads the password only from `BERESIN_ADMIN_PASSWORD`.

## Verification limitation
Dependency installation (`npm ci`) was attempted but did not finish within the available execution window, so a full Vite production build could not be completed in this environment. Static source audit was completed and the changed TypeScript files were checked for compiler syntax; dependency/type-resolution errors are expected while dependencies are not installed.

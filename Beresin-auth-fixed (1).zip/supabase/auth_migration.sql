-- BERESIN AUTH MIGRATION
-- Run after supabase/schema.sql in the Supabase SQL Editor.
--
-- Authentication source of truth:
--   auth.users -> Supabase Auth
--   public.profiles.id -> auth.users.id
--
-- Passwords are NEVER stored in public.profiles or any application table.
-- New accounts are created by supabase.auth.signUp({ email, password }).
--
-- Master admin:
--   email: mdqputra@gmail.com
-- The password is intentionally NOT stored in this migration. Use the
-- scripts/bootstrap-admin.mjs one-time bootstrap with a Supabase service-role
-- key and an environment variable for the password, or create the user in
-- Supabase Dashboard > Authentication > Users.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Ensure the profile table is tied to Supabase Auth.
ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS profiles_id_fkey;

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_id_fkey
  FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- Security-definer helper. The function owner bypasses RLS and only exposes
-- the boolean needed by policies.
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = auth.uid()
      AND role = 'ADMIN'::user_role
      AND lower(email) = 'mdqputra@gmail.com'
  );
$$;

-- Only the designated email may have ADMIN role.
CREATE OR REPLACE FUNCTION public.enforce_single_master_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.role = 'ADMIN'::user_role
     AND lower(COALESCE(NEW.email, '')) <> 'mdqputra@gmail.com' THEN
    RAISE EXCEPTION 'Only the designated BERESIN master admin can have ADMIN role';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS enforce_single_master_admin ON public.profiles;
CREATE TRIGGER enforce_single_master_admin
BEFORE INSERT OR UPDATE OF role, email ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.enforce_single_master_admin();

-- Create/repair profile whenever Supabase Auth creates a user.
-- The Auth UUID is always used as profiles.id.
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_full_name TEXT;
  v_whatsapp TEXT;
  v_voucher_code TEXT;
  v_role user_role;
BEGIN
  v_full_name :=
    COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data ->> 'full_name'), ''),
             'Mahasiswa BERESIN');

  v_whatsapp :=
    COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data ->> 'whatsapp'), ''), '');

  v_voucher_code :=
    NULLIF(TRIM(NEW.raw_user_meta_data ->> 'voucher_code'), '');

  -- The master admin role is assigned only by this trusted server-side trigger.
  -- All other accounts are STUDENT regardless of client-supplied metadata.
  v_role :=
    CASE
      WHEN lower(COALESCE(NEW.email, '')) = 'mdqputra@gmail.com'
        THEN 'ADMIN'::user_role
      ELSE 'STUDENT'::user_role
    END;

  INSERT INTO public.profiles (
    id, email, full_name, whatsapp, role,
    voucher_balance, voucher_code_used, created_at, updated_at
  )
  VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    v_full_name,
    v_whatsapp,
    v_role,
    0,
    NULL,
    COALESCE(NEW.created_at, NOW()),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = EXCLUDED.full_name,
    whatsapp = EXCLUDED.whatsapp,
    role = EXCLUDED.role,
    updated_at = NOW();

  -- Voucher redemption is server-side and only for normal student accounts.
  IF v_voucher_code IS NOT NULL AND v_role = 'STUDENT'::user_role THEN
    PERFORM public.redeem_voucher_code(
      v_voucher_code,
      NEW.id,
      COALESCE(NEW.email, '')
    );
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.handle_new_auth_user();

ALTER FUNCTION public.redeem_voucher_code(TEXT, UUID, TEXT) SET search_path = public;
ALTER FUNCTION public.apply_voucher_and_finalize_price(UUID, NUMERIC) SET search_path = public;

-- -------------------------------------------------------------------------
-- RLS
-- -------------------------------------------------------------------------

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
-- No client INSERT policy: the Auth trigger is the only profile creation path.

DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
CREATE POLICY "Users can view own profile"
ON public.profiles FOR SELECT
TO authenticated
USING (auth.uid() = id OR public.is_admin());

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
-- The current application does not edit profiles directly. Removing this
-- client UPDATE policy prevents a student from changing role/email or other
-- protected profile fields through the browser. Server-side RPC/SQL remains
-- available for controlled profile changes.

-- -------------------------------------------------------------------------
-- Repair existing Auth/profile linkage without deleting existing data.
-- This only inserts a missing profile for an Auth user and promotes the
-- designated master admin. It never creates passwords.
-- -------------------------------------------------------------------------

INSERT INTO public.profiles (
  id, email, full_name, whatsapp, role,
  voucher_balance, voucher_code_used, created_at, updated_at
)
SELECT
  u.id,
  COALESCE(u.email, ''),
  COALESCE(NULLIF(TRIM(u.raw_user_meta_data ->> 'full_name'), ''),
           CASE WHEN lower(COALESCE(u.email, '')) = 'mdqputra@gmail.com'
                THEN 'Admin Utama BERESIN'
                ELSE 'Mahasiswa BERESIN'
           END),
  COALESCE(NULLIF(TRIM(u.raw_user_meta_data ->> 'whatsapp'), ''), ''),
  CASE WHEN lower(COALESCE(u.email, '')) = 'mdqputra@gmail.com'
       THEN 'ADMIN'::user_role
       ELSE 'STUDENT'::user_role
  END,
  0,
  NULL,
  COALESCE(u.created_at, NOW()),
  NOW()
FROM auth.users u
WHERE NOT EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.id = u.id
);

UPDATE public.profiles p
SET role = 'ADMIN'::user_role,
    updated_at = NOW()
WHERE lower(p.email) = 'mdqputra@gmail.com';

-- Any pre-existing profile claiming ADMIN under another email is demoted so
-- the designated account is the sole ADMIN. No row is deleted.
UPDATE public.profiles p
SET role = 'STUDENT'::user_role,
    updated_at = NOW()
WHERE p.role = 'ADMIN'::user_role
  AND lower(p.email) <> 'mdqputra@gmail.com';

-- Verification query (read-only):
-- SELECT u.id, u.email, p.id AS profile_id, p.role
-- FROM auth.users u
-- LEFT JOIN public.profiles p ON p.id = u.id
-- ORDER BY u.created_at DESC;

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile, UserRole } from '../types';
import { getSupabase, isSupabaseConfigured } from '../lib/supabase';

interface AuthContextType {
  currentUser: UserProfile | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  login: (email: string, password?: string) => Promise<{ success: boolean; message: string }>;
  register: (data: {
    full_name: string;
    email: string;
    whatsapp: string;
    password: string;
    voucher_code?: string;
  }) => Promise<{ success: boolean; message: string; user?: UserProfile }>;
  logout: () => Promise<void>;
  refreshUser: () => void;
  refreshProfile: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);

  const mapProfile = (profile: any, authUser: any): UserProfile => {
    const email = (profile?.email || authUser.email || '').trim().toLowerCase();
    // The designated master admin is identified by the Auth email. This keeps
    // the UI role correct even if an older profile still has STUDENT. Database
    // RLS is separately enforced by the migration, so this is not a security
    // bypass; it only prevents the admin from being routed to the student UI.
    const role: UserRole = email === 'mdqputra@gmail.com' ? 'ADMIN' : (profile?.role || 'STUDENT');

    return {
    id: authUser.id,
    email,
    full_name: profile?.full_name || authUser.user_metadata?.full_name || 'Mahasiswa BERESIN',
    whatsapp: profile?.whatsapp || authUser.user_metadata?.whatsapp || '',
    role,
    voucher_balance: Number(profile?.voucher_balance) || 0,
    voucher_code_used: profile?.voucher_code_used,
    created_at: profile?.created_at || authUser.created_at || new Date().toISOString(),
    };
  };

  const loadAuthenticatedUser = async (authUser: any): Promise<UserProfile | null> => {
    const supabase = getSupabase();
    if (!supabase || !authUser) {
      setCurrentUser(null);
      return null;
    }

    const { data: profile, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', authUser.id)
      .maybeSingle();

    if (error) {
      console.error('Gagal memuat profile Supabase:', error);
      setCurrentUser(null);
      return null;
    }

    if (profile) {
      const mappedUser = mapProfile(profile, authUser);
      setCurrentUser(mappedUser);
      return mappedUser;
    } else {
      // A profile should normally be created by the database trigger after signUp.
      // Do not create a local/fake authenticated user if it is missing.
      setCurrentUser(null);
      return null;
    }
  };

  useEffect(() => {
    // Remove the legacy local-auth identity cache. Supabase Auth is the only
    // source of truth for the authenticated user/session.
    try {
      localStorage.removeItem('beresin_current_user_v1');
    } catch {
      // Ignore storage errors.
    }

    const supabase = getSupabase();
    if (!supabase) {
      setCurrentUser(null);
      return;
    }

    let mounted = true;

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (mounted) {
        void loadAuthenticatedUser(session?.user ?? null);
      }
    });

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (!mounted) return;
      if (event === 'SIGNED_OUT' || !session?.user) {
        setCurrentUser(null);
        return;
      }
      void loadAuthenticatedUser(session.user);
    });

    return () => {
      mounted = false;
      authListener.subscription.unsubscribe();
    };
  }, []);

  const refreshUser = () => {
    const supabase = getSupabase();
    if (!supabase || !currentUser) return;
    void supabase.auth.getUser().then(({ data: { user } }) => {
      if (user) void loadAuthenticatedUser(user);
    });
  };

  const login = async (email: string, password?: string): Promise<{ success: boolean; message: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const supabase = getSupabase();

    if (!supabase || !isSupabaseConfigured) {
      return { success: false, message: 'Supabase belum dikonfigurasi. Login memerlukan Supabase Auth.' };
    }

    if (!password) {
      return { success: false, message: 'Password wajib diisi.' };
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email: cleanEmail,
      password,
    });

    if (error || !data.user) {
      return { success: false, message: error?.message || 'Email atau password salah.' };
    }

    await loadAuthenticatedUser(data.user);
    return {
      success: true,
      message: data.user.email === 'mdqputra@gmail.com'
        ? 'Login berhasil sebagai Admin Utama!'
        : `Selamat datang kembali, ${data.user.user_metadata?.full_name || 'di BERESIN'}!`,
    };
  };

  const register = async (data: {
    full_name: string;
    email: string;
    whatsapp: string;
    password: string;
    voucher_code?: string;
  }) => {
    const cleanEmail = data.email.trim().toLowerCase();
    const fullName = data.full_name.trim();
    const whatsapp = data.whatsapp.trim();
    const voucherCode = data.voucher_code?.trim().toUpperCase() || undefined;
    const supabase = getSupabase();

    if (!supabase || !isSupabaseConfigured) {
      return { success: false, message: 'Supabase belum dikonfigurasi. Registrasi memerlukan Supabase Auth.' };
    }

    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: cleanEmail,
      password: data.password,
      options: {
        data: {
          full_name: fullName,
          whatsapp,
          // The database trigger always assigns STUDENT; this metadata is only profile data.
          role: 'STUDENT',
          voucher_code: voucherCode,
        },
      },
    });

    if (authError) {
      if (authError.message.toLowerCase().includes('already registered')) {
        return { success: false, message: 'Email sudah terdaftar. Silakan langsung masuk.' };
      }
      return { success: false, message: authError.message || 'Registrasi gagal.' };
    }

    if (!authData.user) {
      return { success: false, message: 'Supabase Auth tidak mengembalikan user setelah registrasi.' };
    }

    // The profile is created server-side by the auth.users trigger, so this remains
    // correct even when email confirmation means signUp returns no active session.
    if (authData.session) {
      const profile = await loadAuthenticatedUser(authData.user);
      return {
        success: true,
        message: 'Registrasi berhasil! Akun Supabase Auth Anda sudah aktif.',
        user: profile || undefined,
      };
    }

    return {
      success: true,
      message: 'Registrasi berhasil! Silakan cek email untuk verifikasi, lalu masuk menggunakan email dan password yang sama.',
    };
  };

  const logout = async (): Promise<void> => {
    const supabase = getSupabase();
    if (!supabase) {
      setCurrentUser(null);
      return;
    }
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error('Gagal logout dari Supabase Auth:', error);
      return;
    }
    setCurrentUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        role: currentUser?.role || null,
        isAuthenticated: Boolean(currentUser),
        login,
        register,
        logout,
        refreshUser,
        refreshProfile: refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

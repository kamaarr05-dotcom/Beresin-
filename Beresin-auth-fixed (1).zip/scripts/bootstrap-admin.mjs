import { createClient } from '@supabase/supabase-js';

const url = process.env.SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const adminEmail = 'mdqputra@gmail.com';
const adminPassword = process.env.BERESIN_ADMIN_PASSWORD;

if (!url || !serviceRoleKey || !adminPassword) {
  console.error(
    'Missing SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, or BERESIN_ADMIN_PASSWORD.'
  );
  process.exit(1);
}

if (adminPassword.length < 6) {
  console.error('BERESIN_ADMIN_PASSWORD must contain at least 6 characters.');
  process.exit(1);
}

const supabase = createClient(url, serviceRoleKey, {
  auth: { autoRefreshToken: false, persistSession: false }
});

const { data: listData, error: listError } = await supabase.auth.admin.listUsers({
  page: 1,
  perPage: 1000
});

if (listError) {
  throw new Error(`Unable to list Auth users: ${listError.message}`);
}

const existing = listData.users.find(
  (user) => (user.email || '').toLowerCase() === adminEmail
);

let user;

if (existing) {
  const { data, error } = await supabase.auth.admin.updateUserById(existing.id, {
    password: adminPassword,
    email_confirm: true,
    user_metadata: {
      ...(existing.user_metadata || {}),
      full_name: 'Admin Utama BERESIN'
    }
  });

  if (error) throw new Error(`Unable to update admin Auth user: ${error.message}`);
  user = data.user;
} else {
  const { data, error } = await supabase.auth.admin.createUser({
    email: adminEmail,
    password: adminPassword,
    email_confirm: true,
    user_metadata: {
      full_name: 'Admin Utama BERESIN',
      whatsapp: ''
    }
  });

  if (error) throw new Error(`Unable to create admin Auth user: ${error.message}`);
  user = data.user;
}

if (!user?.id) {
  throw new Error('Supabase did not return the admin Auth UUID.');
}

const { error: profileError } = await supabase
  .from('profiles')
  .upsert({
    id: user.id,
    email: adminEmail,
    full_name: 'Admin Utama BERESIN',
    whatsapp: '',
    role: 'ADMIN',
    voucher_balance: 0
  }, { onConflict: 'id' });

if (profileError) {
  throw new Error(`Unable to ensure admin profile: ${profileError.message}`);
}

console.log(`Master admin ready: ${adminEmail}`);
console.log('Password is supplied only through BERESIN_ADMIN_PASSWORD and is not stored by this script.');

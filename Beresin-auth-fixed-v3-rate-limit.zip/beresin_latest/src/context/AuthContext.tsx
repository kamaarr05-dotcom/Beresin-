import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile, UserRole } from '../types';
import { BeresinDataStore, getSupabase, isSupabaseConfigured } from '../lib/supabase';

interface AuthContextType {
  currentUser: UserProfile | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  login: (email: string, password?: string) => Promise<{ success: boolean; message: string }>;
  register: (data: {
    full_name: string;
    email: string;
    whatsapp: string;
    password: string;
    voucher_code?: string;
  }) => Promise<{ success: boolean; message: string; user?: UserProfile }>;
  logout: () => void;
  switchUser: (role: UserRole) => void;
  refreshUser: () => void;
  refreshProfile: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Prevent duplicate/rapid Supabase Auth sign-up requests from multiple UI surfaces.
let registerInFlight = false;
const recentRegisterAttempts = new Map<string, number>();
const REGISTER_COOLDOWN_MS = 15000;

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);

  const mapProfile = (profile: any, authUser: any): UserProfile => {
    const email = (profile?.email || authUser.email || '').trim().toLowerCase();
    // The designated master admin is identified by the Auth email. This keeps
    // the UI role correct even if an older profile still has STUDENT. Database
    // RLS is separately enforced by the migration, so this is not a security
    // bypass; it only prevents the admin from being routed to the student UI.
    const role: UserRole = email === 'mdqputra@gmail.com' ? 'ADMIN' : (profile?.role || 'STUDENT');

    return {
    id: authUser.id,
    email,
    full_name: profile?.full_name || authUser.user_metadata?.full_name || 'Mahasiswa BERESIN',
    whatsapp: profile?.whatsapp || authUser.user_metadata?.whatsapp || '',
    role,
    voucher_balance: Number(profile?.voucher_balance) || 0,
    voucher_code_used: profile?.voucher_code_used,
    created_at: profile?.created_at || authUser.created_at || new Date().toISOString(),
    };
  };

  const loadAuthenticatedUser = async (authUser: any): Promise<UserProfile | null> => {
    const supabase = getSupabase();
    if (!supabase || !authUser) {
      setCurrentUser(null);
      return null;
    }

    // The database trigger normally creates this row. The RPC is a safe,
    // idempotent fallback for older projects or a race immediately after sign-up.
    let { data: profile, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', authUser.id)
      .maybeSingle();

    if (!profile) {
      const { error: ensureError } = await supabase.rpc('ensure_my_profile');
      if (!ensureError) {
        const result = await supabase
          .from('profiles')
          .select('*')
          .eq('id', authUser.id)
          .maybeSingle();
        profile = result.data;
        error = result.error;
      }
    }

    if (error) {
      console.error('Gagal memuat profile Supabase:', error);
      setCurrentUser(null);
      return null;
    }

    if (!profile) {
      console.error('Profile Auth tidak ditemukan untuk UUID:', authUser.id);
      setCurrentUser(null);
      return null;
    }

    const mappedUser = mapProfile(profile, authUser);
    setCurrentUser(mappedUser);
    return mappedUser;
  };

  useEffect(() => {
    // Remove the legacy local-auth identity cache. Supabase Auth is the only
    // source of truth for the authenticated user/session.
    try {
      localStorage.removeItem('beresin_current_user_v1');
    } catch {
      // Ignore storage errors.
    }

    const supabase = getSupabase();
    if (!supabase) {
      setCurrentUser(null);
      return;
    }

    let mounted = true;

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (mounted) {
        void loadAuthenticatedUser(session?.user ?? null);
      }
    });

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (!mounted) return;
      if (event === 'SIGNED_OUT' || !session?.user) {
        setCurrentUser(null);
        return;
      }
      // Do not perform Supabase queries synchronously inside the auth callback;
      // defer profile loading to avoid auth callback lock/deadlock issues.
      window.setTimeout(() => {
        if (mounted) void loadAuthenticatedUser(session.user);
      }, 0);
    });

    return () => {
      mounted = false;
      authListener.subscription.unsubscribe();
    };
  }, []);

  const refreshUser = () => {
    const supabase = getSupabase();
    if (!supabase || !currentUser) return;
    void supabase.auth.getUser().then(({ data: { user } }) => {
      if (user) void loadAuthenticatedUser(user);
    });
  };

  const login = async (email: string, password?: string): Promise<{ success: boolean; message: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const supabase = getSupabase();

    if (!supabase || !isSupabaseConfigured) {
      return { success: false, message: 'Supabase belum dikonfigurasi. Login memerlukan Supabase Auth.' };
    }

    if (!password) {
      return { success: false, message: 'Password wajib diisi.' };
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email: cleanEmail,
      password,
    });

    if (error || !data.user) {
      return { success: false, message: error?.message || 'Email atau password salah.' };
    }

    const profile = await loadAuthenticatedUser(data.user);
    if (!profile) {
      return {
        success: false,
        message: 'Login Auth berhasil, tetapi profile akun belum siap. Jalankan migration Auth BERESIN lalu coba lagi.',
      };
    }

    return {
      success: true,
      message: profile.role === 'ADMIN'
        ? 'Login berhasil sebagai Admin Utama!'
        : `Selamat datang kembali, ${profile.full_name || 'di BERESIN'}!`,
    };
  };

  const register = async (data: {
    full_name: string;
    email: string;
    whatsapp: string;
    password: string;
    voucher_code?: string;
  }) => {
    const cleanEmail = data.email.trim().toLowerCase();
    const fullName = data.full_name.trim();
    const whatsapp = data.whatsapp.trim();
    const voucherCode = data.voucher_code?.trim().toUpperCase() || undefined;
    const supabase = getSupabase();

    if (!supabase || !isSupabaseConfigured) {
      return { success: false, message: 'Supabase belum dikonfigurasi. Registrasi memerlukan Supabase Auth.' };
    }

    const lastAttempt = recentRegisterAttempts.get(cleanEmail) || 0;
    if (registerInFlight) {
      return { success: false, message: 'Pendaftaran sedang diproses. Mohon tunggu sebentar.' };
    }
    if (Date.now() - lastAttempt < REGISTER_COOLDOWN_MS) {
      return { success: false, message: 'Pendaftaran baru saja dicoba. Tunggu beberapa detik sebelum mencoba lagi.' };
    }

    registerInFlight = true;
    recentRegisterAttempts.set(cleanEmail, Date.now());

    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
      email: cleanEmail,
      password: data.password,
      options: {
        data: {
          full_name: fullName,
          whatsapp,
          // The database trigger always assigns STUDENT; this metadata is only profile data.
          role: 'STUDENT',
          voucher_code: voucherCode,
        },
      },
    });

    if (authError) {
      if (authError.message.toLowerCase().includes('already registered')) {
        return { success: false, message: 'Email sudah terdaftar. Silakan langsung masuk.' };
      }
      return { success: false, message: authError.message || 'Registrasi gagal.' };
    }

    if (!authData.user) {
      return { success: false, message: 'Supabase Auth tidak mengembalikan user setelah registrasi.' };
    }

    // The trigger creates the profile. When email confirmation is disabled,
    // signUp returns a session and we can immediately hydrate the app. When
    // confirmation is enabled, Auth still owns the account and the user can
    // sign in after verifying the email.
    if (authData.session) {
      const profile = await loadAuthenticatedUser(authData.user);
      if (!profile) {
        return { success: false, message: 'Akun Auth berhasil dibuat, tetapi profile belum siap. Coba masuk kembali setelah migration Auth diperbarui.' };
      }
      return {
        success: true,
        message: 'Registrasi berhasil! Akun Supabase Auth Anda sudah aktif.',
        user: profile,
      };
    }

    return {
      success: true,
      message: 'Registrasi berhasil! Silakan cek email untuk verifikasi, lalu masuk menggunakan email dan password yang sama.',
    };
    } catch (error: any) {
      const message = String(error?.message || '').toLowerCase();
      if (message.includes('rate limit')) {
        return { success: false, message: 'Terlalu banyak percobaan. Tunggu beberapa menit sebelum mendaftar lagi.' };
      }
      return { success: false, message: error?.message || 'Registrasi gagal. Silakan coba lagi nanti.' };
    } finally {
      registerInFlight = false;
    }
  };

  const logout = () => {
    const supabase = getSupabase();
    if (!supabase) {
      setCurrentUser(null);
      return;
    }
    void supabase.auth.signOut();
  };

  const switchUser = (_targetRole: UserRole) => {
    // Authentication is intentionally controlled only by Supabase Auth.
    // This method remains for backwards compatibility with the existing UI.
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        role: currentUser?.role || null,
        isAuthenticated: Boolean(currentUser),
        login,
        register,
        logout,
        switchUser,
        refreshUser,
        refreshProfile: refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
